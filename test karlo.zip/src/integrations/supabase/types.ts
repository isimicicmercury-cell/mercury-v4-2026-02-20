export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      candidate_assignments: {
        Row: {
          assigned_at: string
          candidate_id: string
          client_id: string
          id: string
          status: string | null
        }
        Insert: {
          assigned_at?: string
          candidate_id: string
          client_id: string
          id?: string
          status?: string | null
        }
        Update: {
          assigned_at?: string
          candidate_id?: string
          client_id?: string
          id?: string
          status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "candidate_assignments_candidate_id_fkey"
            columns: ["candidate_id"]
            isOneToOne: false
            referencedRelation: "candidates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "candidate_assignments_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      candidate_documents: {
        Row: {
          candidate_id: string
          file_name: string
          file_path: string
          file_size: number | null
          file_type: string | null
          id: string
          uploaded_at: string
          uploaded_by: string | null
        }
        Insert: {
          candidate_id: string
          file_name: string
          file_path: string
          file_size?: number | null
          file_type?: string | null
          id?: string
          uploaded_at?: string
          uploaded_by?: string | null
        }
        Update: {
          candidate_id?: string
          file_name?: string
          file_path?: string
          file_size?: number | null
          file_type?: string | null
          id?: string
          uploaded_at?: string
          uploaded_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "candidate_documents_candidate_id_fkey"
            columns: ["candidate_id"]
            isOneToOne: false
            referencedRelation: "candidates"
            referencedColumns: ["id"]
          },
        ]
      }
      candidate_pipeline_state: {
        Row: {
          candidate_id: string
          current_stage_id: string
          entered_stage_at: string
          id: string
          pipeline_template_id: string
          status: string
          updated_at: string
        }
        Insert: {
          candidate_id: string
          current_stage_id: string
          entered_stage_at?: string
          id?: string
          pipeline_template_id: string
          status?: string
          updated_at?: string
        }
        Update: {
          candidate_id?: string
          current_stage_id?: string
          entered_stage_at?: string
          id?: string
          pipeline_template_id?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "candidate_pipeline_state_candidate_id_fkey"
            columns: ["candidate_id"]
            isOneToOne: true
            referencedRelation: "candidates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "candidate_pipeline_state_current_stage_id_fkey"
            columns: ["current_stage_id"]
            isOneToOne: false
            referencedRelation: "pipeline_stages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "candidate_pipeline_state_pipeline_template_id_fkey"
            columns: ["pipeline_template_id"]
            isOneToOne: false
            referencedRelation: "pipeline_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      candidate_stage_history: {
        Row: {
          candidate_id: string
          changed_at: string
          changed_by_user_id: string | null
          from_stage_id: string | null
          id: string
          note: string | null
          to_stage_id: string
        }
        Insert: {
          candidate_id: string
          changed_at?: string
          changed_by_user_id?: string | null
          from_stage_id?: string | null
          id?: string
          note?: string | null
          to_stage_id: string
        }
        Update: {
          candidate_id?: string
          changed_at?: string
          changed_by_user_id?: string | null
          from_stage_id?: string | null
          id?: string
          note?: string | null
          to_stage_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "candidate_stage_history_candidate_id_fkey"
            columns: ["candidate_id"]
            isOneToOne: false
            referencedRelation: "candidates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "candidate_stage_history_from_stage_id_fkey"
            columns: ["from_stage_id"]
            isOneToOne: false
            referencedRelation: "pipeline_stages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "candidate_stage_history_to_stage_id_fkey"
            columns: ["to_stage_id"]
            isOneToOne: false
            referencedRelation: "pipeline_stages"
            referencedColumns: ["id"]
          },
        ]
      }
      candidates: {
        Row: {
          candidate_code: string
          claimed_at: string | null
          claimed_by_client_id: string | null
          created_at: string
          datum_i_mjesto_ulaska_u_rh: string | null
          datum_odjave_16a: string | null
          datum_prijave_16a: string | null
          datum_rodenja: string | null
          drzavljanstvo: string | null
          email: string | null
          experience_years: number | null
          full_name: string
          ginekolog: string | null
          gsm: Json | null
          iban: string | null
          id: string
          ime: string | null
          ime_majke: string | null
          ime_oca: string | null
          mjesto_i_drzava_rodenja: string | null
          mjesto_izdavanja_putovnice: string | null
          notes: string | null
          novi_smjestaj_boraviste: string | null
          odjava_hzmo: string | null
          oib: string | null
          ordinacija_opce_medicine: string | null
          phone: string | null
          plane_ticket: string | null
          prethodni_smjestaj: string | null
          prezime: string | null
          prijava_drb: string | null
          prijava_hzmo: string | null
          profile_picture_url: string | null
          radno_mjesto: string | null
          resume_url: string | null
          rok_odobrenja_boravka: string | null
          rok_vazenja_vize: string | null
          skills: string[] | null
          skolska_sprema: string | null
          status: string | null
          terapija_komentar: string | null
          termin_lijecnickog: string | null
          updated_at: string
          viza_d_form_ref_no: string | null
          viza_d_status: string | null
          vrijedi_od_do: string | null
          vrsta_i_broj_putovnice: string | null
          vrsta_i_broj_vize_mjesto_izdavanja: string | null
          zanimanje: string | null
          zubar: string | null
        }
        Insert: {
          candidate_code: string
          claimed_at?: string | null
          claimed_by_client_id?: string | null
          created_at?: string
          datum_i_mjesto_ulaska_u_rh?: string | null
          datum_odjave_16a?: string | null
          datum_prijave_16a?: string | null
          datum_rodenja?: string | null
          drzavljanstvo?: string | null
          email?: string | null
          experience_years?: number | null
          full_name: string
          ginekolog?: string | null
          gsm?: Json | null
          iban?: string | null
          id?: string
          ime?: string | null
          ime_majke?: string | null
          ime_oca?: string | null
          mjesto_i_drzava_rodenja?: string | null
          mjesto_izdavanja_putovnice?: string | null
          notes?: string | null
          novi_smjestaj_boraviste?: string | null
          odjava_hzmo?: string | null
          oib?: string | null
          ordinacija_opce_medicine?: string | null
          phone?: string | null
          plane_ticket?: string | null
          prethodni_smjestaj?: string | null
          prezime?: string | null
          prijava_drb?: string | null
          prijava_hzmo?: string | null
          profile_picture_url?: string | null
          radno_mjesto?: string | null
          resume_url?: string | null
          rok_odobrenja_boravka?: string | null
          rok_vazenja_vize?: string | null
          skills?: string[] | null
          skolska_sprema?: string | null
          status?: string | null
          terapija_komentar?: string | null
          termin_lijecnickog?: string | null
          updated_at?: string
          viza_d_form_ref_no?: string | null
          viza_d_status?: string | null
          vrijedi_od_do?: string | null
          vrsta_i_broj_putovnice?: string | null
          vrsta_i_broj_vize_mjesto_izdavanja?: string | null
          zanimanje?: string | null
          zubar?: string | null
        }
        Update: {
          candidate_code?: string
          claimed_at?: string | null
          claimed_by_client_id?: string | null
          created_at?: string
          datum_i_mjesto_ulaska_u_rh?: string | null
          datum_odjave_16a?: string | null
          datum_prijave_16a?: string | null
          datum_rodenja?: string | null
          drzavljanstvo?: string | null
          email?: string | null
          experience_years?: number | null
          full_name?: string
          ginekolog?: string | null
          gsm?: Json | null
          iban?: string | null
          id?: string
          ime?: string | null
          ime_majke?: string | null
          ime_oca?: string | null
          mjesto_i_drzava_rodenja?: string | null
          mjesto_izdavanja_putovnice?: string | null
          notes?: string | null
          novi_smjestaj_boraviste?: string | null
          odjava_hzmo?: string | null
          oib?: string | null
          ordinacija_opce_medicine?: string | null
          phone?: string | null
          plane_ticket?: string | null
          prethodni_smjestaj?: string | null
          prezime?: string | null
          prijava_drb?: string | null
          prijava_hzmo?: string | null
          profile_picture_url?: string | null
          radno_mjesto?: string | null
          resume_url?: string | null
          rok_odobrenja_boravka?: string | null
          rok_vazenja_vize?: string | null
          skills?: string[] | null
          skolska_sprema?: string | null
          status?: string | null
          terapija_komentar?: string | null
          termin_lijecnickog?: string | null
          updated_at?: string
          viza_d_form_ref_no?: string | null
          viza_d_status?: string | null
          vrijedi_od_do?: string | null
          vrsta_i_broj_putovnice?: string | null
          vrsta_i_broj_vize_mjesto_izdavanja?: string | null
          zanimanje?: string | null
          zubar?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "candidates_claimed_by_client_id_fkey"
            columns: ["claimed_by_client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      client_pending_changes: {
        Row: {
          client_id: string
          created_at: string
          id: string
          proposed_changes: Json
          reviewed_at: string | null
          reviewed_by: string | null
          reviewer_notes: string | null
          status: string
          submitted_at: string
          updated_at: string
        }
        Insert: {
          client_id: string
          created_at?: string
          id?: string
          proposed_changes: Json
          reviewed_at?: string | null
          reviewed_by?: string | null
          reviewer_notes?: string | null
          status?: string
          submitted_at?: string
          updated_at?: string
        }
        Update: {
          client_id?: string
          created_at?: string
          id?: string
          proposed_changes?: Json
          reviewed_at?: string | null
          reviewed_by?: string | null
          reviewer_notes?: string | null
          status?: string
          submitted_at?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_pending_changes_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      client_pipeline_assignment: {
        Row: {
          client_id: string
          created_at: string
          id: string
          pipeline_template_id: string
        }
        Insert: {
          client_id: string
          created_at?: string
          id?: string
          pipeline_template_id: string
        }
        Update: {
          client_id?: string
          created_at?: string
          id?: string
          pipeline_template_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_pipeline_assignment_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: true
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "client_pipeline_assignment_pipeline_template_id_fkey"
            columns: ["pipeline_template_id"]
            isOneToOne: false
            referencedRelation: "pipeline_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      clients: {
        Row: {
          accent_color: string | null
          address_line: string | null
          city: string | null
          company_name: string
          contact_email: string | null
          contact_name: string | null
          country: string | null
          created_at: string
          founders_members: string | null
          fraud_match_data: Json | null
          fraud_review_status: string | null
          id: string
          is_banned: boolean | null
          login_password: string
          login_username: string
          logo_url: string | null
          notes: string | null
          pending_logo_url: string | null
          phone: string | null
          postal_code: string | null
          representatives: Json | null
          state: string | null
          tax_id: string | null
          updated_at: string
          user_id: string
          website: string | null
        }
        Insert: {
          accent_color?: string | null
          address_line?: string | null
          city?: string | null
          company_name: string
          contact_email?: string | null
          contact_name?: string | null
          country?: string | null
          created_at?: string
          founders_members?: string | null
          fraud_match_data?: Json | null
          fraud_review_status?: string | null
          id?: string
          is_banned?: boolean | null
          login_password: string
          login_username: string
          logo_url?: string | null
          notes?: string | null
          pending_logo_url?: string | null
          phone?: string | null
          postal_code?: string | null
          representatives?: Json | null
          state?: string | null
          tax_id?: string | null
          updated_at?: string
          user_id: string
          website?: string | null
        }
        Update: {
          accent_color?: string | null
          address_line?: string | null
          city?: string | null
          company_name?: string
          contact_email?: string | null
          contact_name?: string | null
          country?: string | null
          created_at?: string
          founders_members?: string | null
          fraud_match_data?: Json | null
          fraud_review_status?: string | null
          id?: string
          is_banned?: boolean | null
          login_password?: string
          login_username?: string
          logo_url?: string | null
          notes?: string | null
          pending_logo_url?: string | null
          phone?: string | null
          postal_code?: string | null
          representatives?: Json | null
          state?: string | null
          tax_id?: string | null
          updated_at?: string
          user_id?: string
          website?: string | null
        }
        Relationships: []
      }
      pipeline_stages: {
        Row: {
          can_client_advance: boolean
          created_at: string
          id: string
          is_required: boolean
          name: string
          pipeline_template_id: string
          position: number
          stage_type: string
        }
        Insert: {
          can_client_advance?: boolean
          created_at?: string
          id?: string
          is_required?: boolean
          name: string
          pipeline_template_id: string
          position: number
          stage_type?: string
        }
        Update: {
          can_client_advance?: boolean
          created_at?: string
          id?: string
          is_required?: boolean
          name?: string
          pipeline_template_id?: string
          position?: number
          stage_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "pipeline_stages_pipeline_template_id_fkey"
            columns: ["pipeline_template_id"]
            isOneToOne: false
            referencedRelation: "pipeline_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      pipeline_templates: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          name: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          company_name: string | null
          created_at: string
          email: string
          full_name: string | null
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          company_name?: string | null
          created_at?: string
          email: string
          full_name?: string | null
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          company_name?: string | null
          created_at?: string
          email?: string
          full_name?: string | null
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      advance_candidate_stage: {
        Args: { p_candidate_id: string; p_note?: string; p_skip?: boolean }
        Returns: Json
      }
      claim_candidate: {
        Args: { p_candidate_id: string; p_client_id: string }
        Returns: boolean
      }
      generate_candidate_code: { Args: never; Returns: string }
      get_client_id: { Args: { _user_id: string }; Returns: string }
      get_email_by_username: { Args: { p_username: string }; Returns: string }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      update_candidate_pipeline_status: {
        Args: { p_candidate_id: string; p_note?: string; p_status: string }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "superuser" | "client"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["superuser", "client"],
    },
  },
} as const
