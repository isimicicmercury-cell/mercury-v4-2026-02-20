import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

type AppRole = 'superuser' | 'client';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  role: AppRole | null;
  clientId: string | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [role, setRole] = useState<AppRole | null>(null);
  const [clientId, setClientId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchUserRole = async (userId: string) => {
    try {
      const { data: roleData, error: roleError } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', userId)
        .maybeSingle();

      if (roleError) {
        console.error('Error fetching role:', roleError);
        return;
      }

      if (roleData) {
        setRole(roleData.role as AppRole);
      }

      // If client, fetch client_id
      if (roleData?.role === 'client') {
        const { data: clientData, error: clientError } = await supabase
          .from('clients')
          .select('id')
          .eq('user_id', userId)
          .maybeSingle();

        if (clientError) {
          console.error('Error fetching client:', clientError);
          return;
        }

        if (clientData) {
          setClientId(clientData.id);
        }
      }
    } catch (error) {
      console.error('Error in fetchUserRole:', error);
    }
  };

  useEffect(() => {
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);

        if (session?.user) {
          // Use setTimeout to avoid blocking the auth state change
          setTimeout(() => fetchUserRole(session.user.id), 0);
        } else {
          setRole(null);
          setClientId(null);
        }
        setLoading(false);
      }
    );

    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchUserRole(session.user.id);
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const signIn = async (emailOrUsername: string, password: string) => {
    let email = emailOrUsername.trim();
    
    // Check if input looks like a username (no @ symbol)
    if (!emailOrUsername.includes('@')) {
      // Use RPC function to look up email by username (case-insensitive)
      // Pass username in lowercase for case-insensitive matching
      const { data: resolvedEmail, error: lookupError } = await supabase
        .rpc('get_email_by_username', { p_username: emailOrUsername.toLowerCase().trim() });
      
      if (lookupError || !resolvedEmail) {
        return { error: new Error('Incorrect or incomplete login information') };
      }
      
      email = resolvedEmail;
    } else {
      // Email login - normalize to lowercase
      email = email.toLowerCase();
    }
    
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    
    // Return generic error message for any login failure
    if (error) {
      return { error: new Error('Incorrect or incomplete login information') };
    }
    
    return { error: null };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setRole(null);
    setClientId(null);
  };

  return (
    <AuthContext.Provider value={{ user, session, role, clientId, loading, signIn, signOut }}>
      {children}
    </AuthContext.Provider>
  );
};
