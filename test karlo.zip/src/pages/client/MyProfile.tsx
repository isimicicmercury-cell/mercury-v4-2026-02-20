import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useClients, Representative } from '@/hooks/useClients';
import { useClientPendingChanges } from '@/hooks/usePendingChanges';
import { Button } from '@/components/ui/button';
import { PendingChangesList } from '@/components/client/PendingChangesList';
import { 
  Building2, 
  Globe, 
  MapPin, 
  FileText, 
  Users, 
  Briefcase, 
  Pencil,
  Clock,
  Image as ImageIcon
} from 'lucide-react';

/** Helper to get display name from representative (supports legacy full_name) */
const getRepName = (rep: any): string => {
  if (rep.first_name || rep.last_name) {
    return `${rep.first_name || ''} ${rep.last_name || ''}`.trim();
  }
  return rep.full_name || '—';
};

const MyProfile = () => {
  const navigate = useNavigate();
  const { clientId } = useAuth();
  const { data: clients = [], isLoading } = useClients();
  const { data: pendingChanges = [] } = useClientPendingChanges(clientId);

  const client = clients.find(c => c.id === clientId);
  const hasPendingChanges = pendingChanges.some(c => c.status === 'pending');

  if (isLoading) {
    return <div className="py-12 text-center text-muted-foreground">Loading profile...</div>;
  }

  if (!client) {
    return (
      <div className="py-12 text-center">
        <h3 className="font-semibold text-foreground mb-2">Profile not found</h3>
        <p className="text-muted-foreground">Unable to load your company profile.</p>
      </div>
    );
  }

  const representatives = (client.representatives || []) as Representative[];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-header flex items-center gap-2"><Building2 className="w-6 h-6" />{client.company_name}</h1>
          <p className="page-subheader">Your company profile</p>
        </div>
        <Button onClick={() => navigate('/my-profile/edit')} className="btn-primary-gradient"><Pencil className="w-4 h-4 mr-2" />Edit Profile</Button>
      </div>

      {hasPendingChanges && (
        <div className="bg-warning/10 border border-warning/20 rounded-xl p-4 flex items-start gap-3">
          <div className="w-10 h-10 rounded-lg bg-warning/20 flex items-center justify-center shrink-0"><Clock className="w-5 h-5 text-warning" /></div>
          <div>
            <p className="font-medium text-foreground">Changes Pending Approval</p>
            <p className="text-sm text-muted-foreground">You have submitted profile changes that are awaiting review.</p>
          </div>
        </div>
      )}

      {pendingChanges.length > 0 && <PendingChangesList changes={pendingChanges} />}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-6">
          <div className="card-elevated p-6">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 flex items-center gap-2"><Building2 className="w-4 h-4" />Basic Information</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-4">
              {client.logo_url ? (
                  <div className="w-16 h-16 rounded-xl border bg-muted overflow-hidden shrink-0"><img src={client.logo_url} alt={`${client.company_name} logo`} className="w-full h-full object-contain p-1" /></div>
                ) : (
                  <div className="w-16 h-16 rounded-xl border bg-muted/50 flex items-center justify-center shrink-0"><ImageIcon className="w-6 h-6 text-muted-foreground" /></div>
                )}
                <div>
                  <label className="input-label">Company Name</label>
                  <p className="text-foreground font-medium">{client.company_name}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="input-label">Contact Name</label><p className="text-foreground">{client.contact_name || '—'}</p></div>
                <div><label className="input-label">Contact Email</label><p className="text-foreground">{client.contact_email || '—'}</p></div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="input-label">Phone</label><p className="text-foreground">{client.phone || '—'}</p></div>
                <div><label className="input-label flex items-center gap-1"><Globe className="w-3 h-3" />Website</label><p className="text-foreground">{client.website ? <a href={client.website} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">{client.website}</a> : '—'}</p></div>
              </div>
              <div><label className="input-label flex items-center gap-1"><FileText className="w-3 h-3" />Tax ID (OIB)</label><p className="text-foreground">{client.tax_id || '—'}</p></div>
            </div>
          </div>

          <div className="card-elevated p-6">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 flex items-center gap-2"><MapPin className="w-4 h-4" />Address</h3>
            <div className="space-y-4">
              <div><label className="input-label">Address Line</label><p className="text-foreground">{client.address_line || '—'}</p></div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="input-label">City</label><p className="text-foreground">{client.city || '—'}</p></div>
                <div><label className="input-label">Postal Code</label><p className="text-foreground">{client.postal_code || '—'}</p></div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="input-label">State</label><p className="text-foreground">{client.state || '—'}</p></div>
                <div><label className="input-label">Country</label><p className="text-foreground">{client.country || '—'}</p></div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="card-elevated p-6">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 flex items-center gap-2"><Users className="w-4 h-4" />Osnivači / Članovi</h3>
            <p className="text-foreground whitespace-pre-wrap">{client.founders_members || '—'}</p>
          </div>

          <div className="card-elevated p-6">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 flex items-center gap-2"><Briefcase className="w-4 h-4" />Zastupnici</h3>
            {representatives.length === 0 ? (
              <p className="text-muted-foreground text-sm">No representatives added</p>
            ) : (
              <div className="space-y-3">
                {representatives.map((rep, index) => (
                  <div key={index} className="p-4 border border-border rounded-lg bg-muted/30">
                    <p className="font-medium text-foreground">{getRepName(rep)}</p>
                    <p className="text-sm text-muted-foreground">{rep.work_title || '—'}</p>
                    <div className="mt-2 flex flex-wrap gap-4 text-sm text-muted-foreground">
                      {rep.email && <span>{rep.email}</span>}
                      {rep.phone && <span>{rep.phone}</span>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="card-elevated p-6">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 flex items-center gap-2"><FileText className="w-4 h-4" />Notes</h3>
            <p className="text-foreground whitespace-pre-wrap">{client.notes || '—'}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MyProfile;
