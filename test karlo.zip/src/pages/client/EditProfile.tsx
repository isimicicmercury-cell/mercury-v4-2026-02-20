import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useClients, Client, Representative } from '@/hooks/useClients';
import { useSubmitProfileChanges } from '@/hooks/usePendingChanges';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { LogoUploader } from '@/components/clients/LogoUploader';
import { 
  Plus, 
  Trash2, 
  Building2, 
  Globe, 
  MapPin, 
  FileText, 
  Users, 
  Briefcase, 
  Save, 
  X, 
  ArrowLeft,
  AlertCircle,
  Image as ImageIcon
} from 'lucide-react';

const EditProfile = () => {
  const navigate = useNavigate();
  const { clientId } = useAuth();
  const { data: clients = [], isLoading } = useClients();
  const submitChanges = useSubmitProfileChanges();
  
  const [form, setForm] = useState<Partial<Client>>({});
  const [hasChanges, setHasChanges] = useState(false);
  const [pendingLogoUrl, setPendingLogoUrl] = useState<string | null>(null);

  const client = clients.find(c => c.id === clientId);

  useEffect(() => {
    if (client) {
      setForm({
        company_name: client.company_name,
        contact_name: client.contact_name,
        contact_email: client.contact_email,
        phone: client.phone,
        notes: client.notes,
        founders_members: client.founders_members,
        representatives: client.representatives || [],
        website: client.website,
        tax_id: client.tax_id,
        country: client.country,
        state: client.state,
        city: client.city,
        postal_code: client.postal_code,
        address_line: client.address_line,
        logo_url: client.logo_url,
      });
      setPendingLogoUrl((client as any).pending_logo_url || null);
    }
  }, [client]);

  const updateForm = (updates: Partial<Client>) => {
    setForm({ ...form, ...updates });
    setHasChanges(true);
  };

  const addRepresentative = () => {
    const reps = (form.representatives || []) as Representative[];
    updateForm({
      representatives: [...reps, { first_name: '', last_name: '', email: '', phone: '', work_title: '' }],
    });
  };

  const updateRepresentative = (index: number, field: keyof Representative, value: string) => {
    const reps = [...((form.representatives || []) as Representative[])];
    reps[index] = { ...reps[index], [field]: value };
    updateForm({ representatives: reps });
  };

  const removeRepresentative = (index: number) => {
    const reps = [...((form.representatives || []) as Representative[])];
    reps.splice(index, 1);
    updateForm({ representatives: reps });
  };

  const handleSubmit = async () => {
    if (!clientId || !hasChanges) return;

    const changes: Record<string, unknown> = {};
    
    if (client) {
      const fieldsToCheck: (keyof Client)[] = [
        'company_name', 'contact_name', 'contact_email', 'phone', 'notes',
        'founders_members', 'website', 'tax_id', 'country', 'state',
        'city', 'postal_code', 'address_line', 'logo_url'
      ];

      fieldsToCheck.forEach(field => {
        if (form[field] !== client[field]) {
          changes[field] = form[field];
        }
      });

      const formReps = JSON.stringify(form.representatives || []);
      const clientReps = JSON.stringify(client.representatives || []);
      if (formReps !== clientReps) {
        changes.representatives = form.representatives;
      }
    }

    if (Object.keys(changes).length === 0) return;

    await submitChanges.mutateAsync({
      clientId,
      proposedChanges: changes,
    });

    navigate('/my-profile');
  };

  if (isLoading) {
    return <div className="py-12 text-center text-muted-foreground">Loading profile...</div>;
  }

  if (!client) {
    return (
      <div className="py-12 text-center">
        <h3 className="font-semibold text-foreground mb-2">Profile not found</h3>
        <p className="text-muted-foreground mb-4">Unable to load your company profile.</p>
        <Button variant="outline" onClick={() => navigate('/my-profile')}><ArrowLeft className="w-4 h-4 mr-2" />Back to Profile</Button>
      </div>
    );
  }

  const representatives = (form.representatives || []) as Representative[];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate('/my-profile')}><ArrowLeft className="w-5 h-5" /></Button>
          <div>
            <h1 className="page-header flex items-center gap-2"><Building2 className="w-6 h-6" />Edit Profile</h1>
            <p className="page-subheader">Update your company information</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => navigate('/my-profile')}><X className="w-4 h-4 mr-2" />Cancel</Button>
          <Button onClick={handleSubmit} disabled={!hasChanges || submitChanges.isPending} className="btn-primary-gradient">
            <Save className="w-4 h-4 mr-2" />{submitChanges.isPending ? 'Submitting...' : 'Submit for Approval'}
          </Button>
        </div>
      </div>

      <div className="bg-accent/10 border border-accent/20 rounded-xl p-4 flex items-start gap-3">
        <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center shrink-0">
          <AlertCircle className="w-5 h-5 text-accent" />
        </div>
        <div>
          <p className="font-medium text-foreground">Changes Require Approval</p>
          <p className="text-sm text-muted-foreground">Any changes you make will be submitted for review by an administrator before they take effect.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-6">
          <div className="card-elevated p-6">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 flex items-center gap-2"><Building2 className="w-4 h-4" />Basic Information</h3>
            <div className="space-y-4">
              <div>
                <label className="input-label flex items-center gap-1"><ImageIcon className="w-3 h-3" />Company Logo</label>
                <LogoUploader currentLogoUrl={form.logo_url} pendingLogoUrl={pendingLogoUrl} onLogoChange={(url) => setForm(prev => ({ ...prev, logo_url: url }))} onPendingLogoChange={(url) => setPendingLogoUrl(url)} clientId={clientId || ''} requiresApproval={true} />
                <p className="text-xs text-muted-foreground mt-2">Logo changes require administrator approval.</p>
              </div>
              <div><label className="input-label">Company Name</label><Input value={form.company_name || ''} onChange={(e) => updateForm({ company_name: e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="input-label">Contact Name</label><Input value={form.contact_name || ''} onChange={(e) => updateForm({ contact_name: e.target.value })} /></div>
                <div><label className="input-label">Contact Email</label><Input type="email" value={form.contact_email || ''} onChange={(e) => updateForm({ contact_email: e.target.value })} /></div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="input-label">Phone</label><Input value={form.phone || ''} onChange={(e) => updateForm({ phone: e.target.value })} /></div>
                <div><label className="input-label flex items-center gap-1"><Globe className="w-3 h-3" />Website</label><Input value={form.website || ''} onChange={(e) => updateForm({ website: e.target.value })} placeholder="https://example.com" /></div>
              </div>
              <div><label className="input-label flex items-center gap-1"><FileText className="w-3 h-3" />Tax ID (OIB)</label><Input value={form.tax_id || ''} onChange={(e) => updateForm({ tax_id: e.target.value })} /></div>
            </div>
          </div>

          <div className="card-elevated p-6">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 flex items-center gap-2"><MapPin className="w-4 h-4" />Address</h3>
            <div className="space-y-4">
              <div><label className="input-label">Address Line</label><Input value={form.address_line || ''} onChange={(e) => updateForm({ address_line: e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="input-label">City</label><Input value={form.city || ''} onChange={(e) => updateForm({ city: e.target.value })} /></div>
                <div><label className="input-label">Postal Code</label><Input value={form.postal_code || ''} onChange={(e) => updateForm({ postal_code: e.target.value })} /></div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="input-label">State</label><Input value={form.state || ''} onChange={(e) => updateForm({ state: e.target.value })} /></div>
                <div><label className="input-label">Country</label><Input value={form.country || ''} onChange={(e) => updateForm({ country: e.target.value })} /></div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="card-elevated p-6">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 flex items-center gap-2"><Users className="w-4 h-4" />Osnivači / Članovi</h3>
            <Textarea value={form.founders_members || ''} onChange={(e) => updateForm({ founders_members: e.target.value })} placeholder="List founders and members..." rows={4} />
          </div>

          <div className="card-elevated p-6">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 flex items-center gap-2"><Briefcase className="w-4 h-4" />Zastupnici</h3>
            <div className="space-y-3">
              {representatives.map((rep, index) => (
                <div key={index} className="p-4 border border-border rounded-lg bg-muted/30 space-y-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium text-muted-foreground">Representative {index + 1}</span>
                    <Button type="button" variant="ghost" size="icon" className="h-6 w-6 text-destructive hover:text-destructive" onClick={() => removeRepresentative(index)}><Trash2 className="w-3 h-3" /></Button>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Input placeholder="First Name" value={rep.first_name || (rep as any).full_name || ''} onChange={(e) => updateRepresentative(index, 'first_name', e.target.value)} />
                    <Input placeholder="Last Name" value={rep.last_name || ''} onChange={(e) => updateRepresentative(index, 'last_name', e.target.value)} />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Input placeholder="Email" type="email" value={rep.email} onChange={(e) => updateRepresentative(index, 'email', e.target.value)} />
                    <Input placeholder="Phone" value={rep.phone} onChange={(e) => updateRepresentative(index, 'phone', e.target.value)} />
                  </div>
                  <Input placeholder="Work Title" value={rep.work_title} onChange={(e) => updateRepresentative(index, 'work_title', e.target.value)} />
                </div>
              ))}
              <Button type="button" variant="outline" className="w-full" onClick={addRepresentative}><Plus className="w-4 h-4 mr-2" />Add Representative</Button>
            </div>
          </div>

          <div className="card-elevated p-6">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 flex items-center gap-2"><FileText className="w-4 h-4" />Notes</h3>
            <Textarea value={form.notes || ''} onChange={(e) => updateForm({ notes: e.target.value })} placeholder="Additional notes..." rows={4} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditProfile;
