import { useState, useMemo } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useClientClaimedCandidates } from '@/hooks/useAssignments';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Users, Briefcase, Mail, Phone, CheckCircle, Search, ArrowUpDown } from 'lucide-react';
import { formatDate } from '@/lib/dateUtils';

const MyHires = () => {
  const { clientId } = useAuth();
  const { data: candidates = [], isLoading } = useClientClaimedCandidates(clientId);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortValue, setSortValue] = useState('name-asc');

  const filteredAndSorted = useMemo(() => {
    let result = candidates.filter(c => {
      const term = searchTerm.toLowerCase();
      return (
        c.full_name.toLowerCase().includes(term) ||
        (c as any).candidate_code?.toLowerCase().includes(term) ||
        c.email?.toLowerCase().includes(term) ||
        c.skills?.some((s: string) => s.toLowerCase().includes(term))
      );
    });

    const [field, dir] = sortValue.split('-');
    result.sort((a, b) => {
      const d = dir === 'asc' ? 1 : -1;
      if (field === 'name') return a.full_name.localeCompare(b.full_name) * d;
      if (field === 'experience') return ((a.experience_years || 0) - (b.experience_years || 0)) * d;
      if (field === 'date') return (new Date(a.claimed_at || 0).getTime() - new Date(b.claimed_at || 0).getTime()) * d;
      return 0;
    });

    return result;
  }, [candidates, searchTerm, sortValue]);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="page-header">My Hires</h1>
        <p className="page-subheader">Candidates claimed for your company's hiring pipeline</p>
      </div>

      {candidates.length > 0 && (
        <div className="flex items-center gap-4">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search by name or ID..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10" />
          </div>
          <Select value={sortValue} onValueChange={setSortValue}>
            <SelectTrigger className="w-[180px]">
              <ArrowUpDown className="w-3.5 h-3.5 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="name-asc">Name A-Z</SelectItem>
              <SelectItem value="name-desc">Name Z-A</SelectItem>
              <SelectItem value="experience-desc">Most Experience</SelectItem>
              <SelectItem value="date-desc">Recently Claimed</SelectItem>
              <SelectItem value="date-asc">Oldest Claimed</SelectItem>
            </SelectContent>
          </Select>
          <span className="text-sm text-muted-foreground">{filteredAndSorted.length} hires</span>
        </div>
      )}

      {isLoading ? (
        <div className="py-12 text-center text-muted-foreground">Loading candidates...</div>
      ) : filteredAndSorted.length === 0 ? (
        <div className="py-16 text-center">
          <div className="w-20 h-20 rounded-2xl bg-muted flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10 text-muted-foreground" />
          </div>
          <h3 className="text-xl font-semibold text-foreground mb-2">
            {searchTerm ? 'No matching hires' : 'No claimed candidates yet'}
          </h3>
          <p className="text-muted-foreground max-w-sm mx-auto">
            {searchTerm ? 'Try adjusting your search.' : 'When you claim a candidate from your available pool, they\'ll appear here.'}
          </p>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredAndSorted.map((candidate) => {
            const initials = candidate.full_name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
            return (
              <Card key={candidate.id} className="card-elevated animate-scale-in overflow-hidden">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <Avatar className="h-14 w-14 border-2 border-border">
                      {(candidate as any).profile_picture_url ? (
                        <AvatarImage src={(candidate as any).profile_picture_url} alt={candidate.full_name} className="object-cover" />
                      ) : null}
                      <AvatarFallback className="text-sm font-bold bg-primary/10 text-primary">{initials}</AvatarFallback>
                    </Avatar>
                    <div className="flex flex-col items-end gap-1">
                      <span className="status-badge status-claimed">Claimed</span>
                      {(candidate as any).candidate_code && (
                        <span className="text-xs font-mono text-muted-foreground bg-muted px-1.5 py-0.5 rounded">{(candidate as any).candidate_code}</span>
                      )}
                    </div>
                  </div>
                  <CardTitle className="text-lg mt-3">{candidate.full_name}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    {candidate.email && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground"><Mail className="w-4 h-4" /><span>{candidate.email}</span></div>
                    )}
                    {candidate.phone && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground"><Phone className="w-4 h-4" /><span>{candidate.phone}</span></div>
                    )}
                    {candidate.experience_years && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground"><Briefcase className="w-4 h-4" /><span>{candidate.experience_years} years experience</span></div>
                    )}
                  </div>

                  {candidate.skills && candidate.skills.length > 0 && (
                    <div className="flex flex-wrap gap-1.5">
                      {candidate.skills.slice(0, 4).map((skill: string) => (
                        <span key={skill} className="px-2 py-1 bg-secondary text-secondary-foreground text-xs rounded-md">{skill}</span>
                      ))}
                      {candidate.skills.length > 4 && (
                        <span className="px-2 py-1 text-xs text-muted-foreground">+{candidate.skills.length - 4} more</span>
                      )}
                    </div>
                  )}

                  {candidate.claimed_at && (
                    <p className="text-xs text-muted-foreground pt-2 border-t border-border">
                      Claimed on {formatDate(candidate.claimed_at)}
                    </p>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default MyHires;
