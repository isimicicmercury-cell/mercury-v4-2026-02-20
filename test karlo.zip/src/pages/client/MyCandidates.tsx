import { useState, useMemo } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useClientAssignments, useClaimCandidate, useRejectCandidate } from '@/hooks/useAssignments';
import { useClients } from '@/hooks/useClients';
import { useCompanyPipelineAssignments } from '@/hooks/usePipelines';
import { Candidate } from '@/hooks/useCandidates';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Check, X, Users, Briefcase, Mail, Phone, Clock, Eye, Search, ArrowUpDown, GitBranch } from 'lucide-react';
import ClientCandidateProfileSheet from '@/components/candidates/ClientCandidateProfileSheet';

type SortField = 'name' | 'experience';
type SortDirection = 'asc' | 'desc';

const MyCandidates = () => {
  const { clientId } = useAuth();
  const { data: assignments = [], isLoading } = useClientAssignments(clientId);
  const { data: clients = [] } = useClients();
  const claimCandidate = useClaimCandidate();
  const rejectCandidate = useRejectCandidate();
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(null);
  const [profileOpen, setProfileOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<SortField>('name');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');

  // Pipeline selection dialog state
  const [pipelineDialogOpen, setPipelineDialogOpen] = useState(false);
  const [claimCandidateId, setClaimCandidateId] = useState<string | null>(null);
  const [selectedPipelineId, setSelectedPipelineId] = useState<string>('');

  // Get company name for this client
  const myClient = clients.find(c => c.id === clientId);
  const companyName = myClient?.company_name || null;

  // Get available pipelines for this company
  const { data: companyPipelines = [] } = useCompanyPipelineAssignments(companyName);

  const handleClaimClick = (candidateId: string) => {
    if (companyPipelines.length > 1) {
      // Multiple pipelines - show selection dialog
      setClaimCandidateId(candidateId);
      setSelectedPipelineId('');
      setPipelineDialogOpen(true);
    } else if (companyPipelines.length === 1) {
      // Only one pipeline - auto-select it
      handleClaim(candidateId, companyPipelines[0].pipeline_template_id);
    } else {
      // No pipelines - claim without pipeline
      handleClaim(candidateId);
    }
  };

  const handleClaim = async (candidateId: string, pipelineTemplateId?: string) => {
    if (!clientId) return;
    await claimCandidate.mutateAsync({ candidateId, clientId, pipelineTemplateId });
  };

  const handleConfirmClaimWithPipeline = async () => {
    if (!claimCandidateId || !selectedPipelineId) return;
    await handleClaim(claimCandidateId, selectedPipelineId);
    setPipelineDialogOpen(false);
    setClaimCandidateId(null);
    setSelectedPipelineId('');
  };

  const handleReject = async (assignmentId: string) => {
    await rejectCandidate.mutateAsync({ assignmentId });
  };

  const handleViewProfile = (candidate: Candidate) => {
    setSelectedCandidate(candidate);
    setProfileOpen(true);
  };

  const isCandidateHired = (candidate: Candidate | undefined) => {
    if (!candidate || !clientId) return false;
    return candidate.status === 'claimed' && candidate.claimed_by_client_id === clientId;
  };

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(d => d === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const filteredAndSorted = useMemo(() => {
    let result = assignments.filter(a => {
      const c = a.candidate;
      if (!c) return false;
      const term = searchTerm.toLowerCase();
      return (
        c.full_name.toLowerCase().includes(term) ||
        (c as any).candidate_code?.toLowerCase().includes(term) ||
        c.email?.toLowerCase().includes(term) ||
        c.skills?.some(s => s.toLowerCase().includes(term))
      );
    });

    result.sort((a, b) => {
      const dir = sortDirection === 'asc' ? 1 : -1;
      if (sortField === 'name') return (a.candidate?.full_name || '').localeCompare(b.candidate?.full_name || '') * dir;
      if (sortField === 'experience') return ((a.candidate?.experience_years || 0) - (b.candidate?.experience_years || 0)) * dir;
      return 0;
    });

    return result;
  }, [assignments, searchTerm, sortField, sortDirection]);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="page-header">Available Candidates</h1>
        <p className="page-subheader">Review and claim candidates for your hiring pipeline</p>
      </div>

      <div className="bg-accent/10 border border-accent/20 rounded-xl p-4 flex items-start gap-3">
        <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center shrink-0">
          <Clock className="w-5 h-5 text-accent" />
        </div>
        <div>
          <p className="font-medium text-foreground">Real-time Updates</p>
          <p className="text-sm text-muted-foreground">Candidate availability updates in real-time. When any representative in your company claims or passes on a candidate, all representatives see the change instantly.</p>
        </div>
      </div>

      {assignments.length > 0 && (
        <div className="flex items-center gap-4">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search by name or ID..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10" />
          </div>
          <Select value={`${sortField}-${sortDirection}`} onValueChange={(v) => {
            const [f, d] = v.split('-') as [SortField, SortDirection];
            setSortField(f);
            setSortDirection(d);
          }}>
            <SelectTrigger className="w-[180px]">
              <ArrowUpDown className="w-3.5 h-3.5 mr-2" />
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="name-asc">Name A-Z</SelectItem>
              <SelectItem value="name-desc">Name Z-A</SelectItem>
              <SelectItem value="experience-desc">Most Experience</SelectItem>
              <SelectItem value="experience-asc">Least Experience</SelectItem>
            </SelectContent>
          </Select>
          <span className="text-sm text-muted-foreground">{filteredAndSorted.length} candidates</span>
        </div>
      )}

      {isLoading ? (
        <div className="py-12 text-center text-muted-foreground">Loading candidates...</div>
      ) : filteredAndSorted.length === 0 ? (
        <div className="py-16 text-center">
          <div className="w-20 h-20 rounded-2xl bg-muted flex items-center justify-center mx-auto mb-6">
            <Users className="w-10 h-10 text-muted-foreground" />
          </div>
          <h3 className="text-xl font-semibold text-foreground mb-2">
            {searchTerm ? 'No matching candidates' : 'No candidates available'}
          </h3>
          <p className="text-muted-foreground max-w-sm mx-auto">
            {searchTerm ? 'Try adjusting your search.' : 'New candidates will appear here once your recruitment partner assigns them to you.'}
          </p>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredAndSorted.map((assignment) => {
            const c = assignment.candidate as any;
            const initials = c?.full_name?.split(' ').map((n: string) => n[0]).join('').toUpperCase().slice(0, 2) || '?';
            return (
              <Card key={assignment.id} className="card-elevated animate-scale-in overflow-hidden">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <Avatar className="h-14 w-14 border-2 border-border">
                      {c?.profile_picture_url ? (
                        <AvatarImage src={c.profile_picture_url} alt={c?.full_name} className="object-cover" />
                      ) : null}
                      <AvatarFallback className="text-sm font-bold bg-primary/10 text-primary">{initials}</AvatarFallback>
                    </Avatar>
                    <div className="flex flex-col items-end gap-1">
                      <span className="status-badge status-available">Available</span>
                      {c?.candidate_code && (
                        <span className="text-xs font-mono text-muted-foreground bg-muted px-1.5 py-0.5 rounded">{c.candidate_code}</span>
                      )}
                    </div>
                  </div>
                  <CardTitle className="text-lg mt-3">{assignment.candidate?.full_name}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    {assignment.candidate?.email && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground"><Mail className="w-4 h-4" /><span>{assignment.candidate.email}</span></div>
                    )}
                    {assignment.candidate?.phone && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground"><Phone className="w-4 h-4" /><span>{assignment.candidate.phone}</span></div>
                    )}
                    {assignment.candidate?.experience_years && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground"><Briefcase className="w-4 h-4" /><span>{assignment.candidate.experience_years} years experience</span></div>
                    )}
                  </div>

                  {assignment.candidate?.skills && assignment.candidate.skills.length > 0 && (
                    <div className="flex flex-wrap gap-1.5">
                      {assignment.candidate.skills.slice(0, 4).map((skill) => (
                        <span key={skill} className="px-2 py-1 bg-secondary text-secondary-foreground text-xs rounded-md">{skill}</span>
                      ))}
                      {assignment.candidate.skills.length > 4 && (
                        <span className="px-2 py-1 text-xs text-muted-foreground">+{assignment.candidate.skills.length - 4} more</span>
                      )}
                    </div>
                  )}

                  <div className="flex flex-col gap-2 pt-2">
                    <Button variant="outline" className="w-full" onClick={() => assignment.candidate && handleViewProfile(assignment.candidate as Candidate)}>
                      <Eye className="w-4 h-4 mr-1" />View Full Profile
                    </Button>
                    <div className="flex gap-3">
                      <Button className="flex-1 btn-primary-gradient" onClick={() => handleClaimClick(assignment.candidate_id)} disabled={claimCandidate.isPending}>
                        <Check className="w-4 h-4 mr-1" />Claim
                      </Button>
                      <Button variant="outline" className="flex-1" onClick={() => handleReject(assignment.id)} disabled={rejectCandidate.isPending}>
                        <X className="w-4 h-4 mr-1" />Pass
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <ClientCandidateProfileSheet
        candidate={selectedCandidate}
        open={profileOpen}
        onOpenChange={setProfileOpen}
        isHired={isCandidateHired(selectedCandidate as Candidate | undefined)}
      />

      {/* Pipeline Selection Dialog */}
      <Dialog open={pipelineDialogOpen} onOpenChange={setPipelineDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <GitBranch className="w-5 h-5" />Select Hiring Pipeline
            </DialogTitle>
            <DialogDescription>
              Your company has multiple hiring pipelines. Choose which pipeline this candidate should go through.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-3">
            {companyPipelines.map((p) => (
              <label
                key={p.id}
                className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                  selectedPipelineId === p.pipeline_template_id
                    ? 'border-primary bg-primary/5'
                    : 'border-border hover:bg-muted/50'
                }`}
                onClick={() => setSelectedPipelineId(p.pipeline_template_id)}
              >
                <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                  selectedPipelineId === p.pipeline_template_id ? 'border-primary' : 'border-muted-foreground/30'
                }`}>
                  {selectedPipelineId === p.pipeline_template_id && (
                    <div className="w-2 h-2 rounded-full bg-primary" />
                  )}
                </div>
                <div className="flex-1">
                  <p className="font-medium text-foreground">{p.pipeline_template?.name}</p>
                  {p.pipeline_template?.description && (
                    <p className="text-xs text-muted-foreground">{p.pipeline_template.description}</p>
                  )}
                </div>
              </label>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPipelineDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              className="btn-primary-gradient"
              onClick={handleConfirmClaimWithPipeline}
              disabled={!selectedPipelineId || claimCandidate.isPending}
            >
              <Check className="w-4 h-4 mr-1" />
              {claimCandidate.isPending ? 'Claiming...' : 'Claim & Start Pipeline'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default MyCandidates;
