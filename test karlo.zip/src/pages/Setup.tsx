import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Users, Shield, CheckCircle } from 'lucide-react';

const Setup = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [createdUsers, setCreatedUsers] = useState<string[]>([]);
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke('create-superuser', {
        body: { email, password, fullName },
      });

      if (error) throw error;
      if (data.error) throw new Error(data.error);

      setCreatedUsers((prev) => [...prev, email]);
      toast({
        title: 'Superuser created!',
        description: `Account for ${email} has been set up.`,
      });

      setEmail('');
      setPassword('');
      setFullName('');

      if (createdUsers.length >= 1) {
        toast({
          title: 'Setup complete!',
          description: 'Both superuser accounts have been created. Redirecting to login...',
        });
        setTimeout(() => navigate('/login'), 2000);
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to create superuser',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-md animate-fade-in">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary mb-4">
            <Shield className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-3xl font-bold text-foreground">Initial Setup</h1>
          <p className="text-muted-foreground mt-2">Create your superuser accounts</p>
        </div>

        {createdUsers.length > 0 && (
          <div className="mb-6 p-4 bg-success/10 border border-success/20 rounded-xl">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-5 h-5 text-success" />
              <span className="font-medium text-success">Superusers Created</span>
            </div>
            <ul className="space-y-1">
              {createdUsers.map((user) => (
                <li key={user} className="text-sm text-muted-foreground pl-7">
                  {user}
                </li>
              ))}
            </ul>
          </div>
        )}

        <Card className="shadow-[var(--shadow-elevated)]">
          <CardHeader className="space-y-1 pb-4">
            <CardTitle className="text-xl font-semibold text-center">
              Create Superuser {createdUsers.length + 1} of 2
            </CardTitle>
            <CardDescription className="text-center">
              Superusers have full access to manage the system
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <label className="input-label" htmlFor="fullName">
                  Full Name
                </label>
                <Input
                  id="fullName"
                  type="text"
                  placeholder="John Doe"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <label className="input-label" htmlFor="email">
                  Email *
                </label>
                <Input
                  id="email"
                  type="email"
                  placeholder="admin@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="input-label" htmlFor="password">
                  Password *
                </label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={6}
                />
              </div>
              <Button
                type="submit"
                className="w-full btn-primary-gradient"
                disabled={isLoading}
              >
                {isLoading ? 'Creating...' : 'Create Superuser'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {createdUsers.length >= 2 && (
          <div className="mt-6">
            <Button
              onClick={() => navigate('/login')}
              className="w-full"
              variant="outline"
            >
              Go to Login
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Setup;
