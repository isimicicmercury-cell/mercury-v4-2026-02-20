import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  usePipelineTemplates,
  useCreatePipelineTemplate,
  useDeletePipelineTemplate,
  useUpdatePipelineTemplate,
} from '@/hooks/usePipelines';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Plus, Trash2, Settings, GitBranch, Eye } from 'lucide-react';

const Pipelines = () => {
  const navigate = useNavigate();
  const { data: templates = [], isLoading } = usePipelineTemplates();
  const createTemplate = useCreatePipelineTemplate();
  const deleteTemplate = useDeletePipelineTemplate();
  const updateTemplate = useUpdatePipelineTemplate();

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [form, setForm] = useState({ name: '', description: '' });

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    await createTemplate.mutateAsync({ name: form.name, description: form.description || undefined });
    setForm({ name: '', description: '' });
    setIsAddOpen(false);
  };

  const toggleActive = async (id: string, currentActive: boolean) => {
    await updateTemplate.mutateAsync({ id, is_active: !currentActive });
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-header">Pipelines</h1>
          <p className="page-subheader">Manage hiring pipeline templates</p>
        </div>
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild>
            <Button className="btn-primary-gradient"><Plus className="w-4 h-4 mr-2" />New Pipeline</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader><DialogTitle>Create Pipeline Template</DialogTitle></DialogHeader>
            <form onSubmit={handleCreate} className="space-y-4 mt-4">
              <div>
                <Label>Pipeline Name *</Label>
                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Standard Hiring" required />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Optional description..." rows={3} />
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <Button type="button" variant="outline" onClick={() => setIsAddOpen(false)}>Cancel</Button>
                <Button type="submit" className="btn-primary-gradient" disabled={createTemplate.isPending}>
                  {createTemplate.isPending ? 'Creating...' : 'Create Pipeline'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="card-elevated p-6">
        {isLoading ? (
          <div className="py-12 text-center text-muted-foreground">Loading pipelines...</div>
        ) : templates.length === 0 ? (
          <div className="py-12 text-center">
            <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mx-auto mb-4">
              <GitBranch className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="font-semibold text-foreground mb-1">No pipelines yet</h3>
            <p className="text-muted-foreground text-sm">Create your first pipeline template to get started.</p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="table-header">Name</TableHead>
                <TableHead className="table-header">Description</TableHead>
                <TableHead className="table-header">Active</TableHead>
                <TableHead className="table-header text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {templates.map((t) => (
                <TableRow key={t.id} className="group">
                  <TableCell className="font-medium">{t.name}</TableCell>
                  <TableCell className="text-muted-foreground text-sm">{t.description || '—'}</TableCell>
                  <TableCell>
                    <Switch checked={t.is_active} onCheckedChange={() => toggleActive(t.id, t.is_active)} />
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button size="sm" variant="outline" onClick={() => navigate(`/pipelines/${t.id}`)}>
                        <Settings className="w-4 h-4 mr-1" />Stages
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => navigate(`/pipelines/${t.id}/kanban`)}>
                        <Eye className="w-4 h-4 mr-1" />Kanban
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => setDeleteId(t.id)} className="text-destructive hover:text-destructive hover:bg-destructive/10">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Pipeline</AlertDialogTitle>
            <AlertDialogDescription>This will delete the pipeline template and all its stages. Candidates currently in this pipeline will retain their history but lose active state.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => { if (deleteId) { deleteTemplate.mutate(deleteId); setDeleteId(null); } }} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Pipelines;
