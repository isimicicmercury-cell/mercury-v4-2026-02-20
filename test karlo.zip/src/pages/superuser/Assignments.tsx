import { useAssignments } from '@/hooks/useAssignments';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { UserCheck } from 'lucide-react';
import { formatDate } from '@/lib/dateUtils';

const Assignments = () => {
  const { data: assignments = [], isLoading } = useAssignments();

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="page-header">Assignments</h1>
        <p className="page-subheader">Track candidate assignments across all clients</p>
      </div>

      <div className="card-elevated p-6">
        {isLoading ? (
          <div className="py-12 text-center text-muted-foreground">Loading assignments...</div>
        ) : assignments.length === 0 ? (
          <div className="py-12 text-center">
            <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mx-auto mb-4">
              <UserCheck className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="font-semibold text-foreground mb-1">No assignments yet</h3>
            <p className="text-muted-foreground text-sm">
              Assign candidates to clients to see them here
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="table-header">Candidate</TableHead>
                  <TableHead className="table-header">Client</TableHead>
                  <TableHead className="table-header">Assigned</TableHead>
                  <TableHead className="table-header">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {assignments.map((assignment) => (
                  <TableRow key={assignment.id}>
                    <TableCell>
                      <div>
                        <p className="font-medium">{assignment.candidate?.full_name}</p>
                        <p className="text-sm text-muted-foreground">
                          {assignment.candidate?.email || '—'}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium">{assignment.client?.company_name}</p>
                        <p className="text-sm text-muted-foreground">
                          {assignment.client?.contact_name || '—'}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {formatDate(assignment.assigned_at)}
                    </TableCell>
                    <TableCell>
                      <span
                        className={`status-badge ${
                          assignment.status === 'pending'
                            ? 'status-pending'
                            : assignment.status === 'claimed'
                            ? 'status-claimed'
                            : 'bg-muted text-muted-foreground'
                        }`}
                      >
                        {assignment.status}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
    </div>
  );
};

export default Assignments;
