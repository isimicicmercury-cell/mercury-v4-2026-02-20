import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  useCandidates,
  useCreateCandidate,
  useDeleteCandidate,
  Candidate,
} from '@/hooks/useCandidates';
import { useAssignments } from '@/hooks/useAssignments';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Plus, Trash2, Search, UserPlus, Upload, Eye, ArrowUpDown, ImageIcon, X } from 'lucide-react';
import AssignCandidateDialog from '@/components/candidates/AssignCandidateDialog';
import { CandidateCSVUploadDialog } from '@/components/candidates/CandidateCSVUploadDialog';
import { BulkPhotoUploadDialog } from '@/components/candidates/BulkPhotoUploadDialog';

type SortField = 'full_name' | 'email' | 'experience_years' | 'status' | 'created_at' | 'candidate_code';
type SortDirection = 'asc' | 'desc';

const Candidates = () => {
  const navigate = useNavigate();
  const { data: candidates = [], isLoading } = useCandidates();
  const { data: allAssignments = [] } = useAssignments();
  const createCandidate = useCreateCandidate();
  const deleteCandidate = useDeleteCandidate();

  // Build a map of candidate ID -> assigned company names
  const candidateAssignmentMap = useMemo(() => {
    const map = new Map<string, Set<string>>();
    allAssignments.forEach((a) => {
      if (!map.has(a.candidate_id)) map.set(a.candidate_id, new Set());
      if (a.client?.company_name) map.get(a.candidate_id)!.add(a.client.company_name);
    });
    return map;
  }, [allAssignments]);

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isCSVOpen, setIsCSVOpen] = useState(false);
  const [isBulkPhotoOpen, setIsBulkPhotoOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [assignCandidate, setAssignCandidate] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<SortField>('created_at');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');

  const openCandidateProfile = (candidateId: string) => navigate(`/candidates/${candidateId}`);

  const [form, setForm] = useState({
    full_name: '', email: '', phone: '', skills: '', experience_years: '', notes: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await createCandidate.mutateAsync({
      full_name: form.full_name,
      email: form.email || null,
      phone: form.phone || null,
      skills: form.skills ? form.skills.split(',').map((s) => s.trim()) : null,
      experience_years: form.experience_years ? parseInt(form.experience_years) : null,
      notes: form.notes || null,
      resume_url: null,
      prezime: null, ime: null, prijava_drb: null, viza_d_form_ref_no: null,
      viza_d_status: null, plane_ticket: null, mjesto_i_drzava_rodenja: null,
      datum_rodenja: null, drzavljanstvo: null, vrsta_i_broj_putovnice: null,
      mjesto_izdavanja_putovnice: null, vrijedi_od_do: null,
      vrsta_i_broj_vize_mjesto_izdavanja: null, rok_vazenja_vize: null,
      datum_i_mjesto_ulaska_u_rh: null, rok_odobrenja_boravka: null,
      novi_smjestaj_boraviste: null, prethodni_smjestaj: null,
      datum_prijave_16a: null, datum_odjave_16a: null, oib: null,
      ime_oca: null, ime_majke: null, zanimanje: null, skolska_sprema: null,
      radno_mjesto: null, termin_lijecnickog: null, gsm: null, iban: null,
      prijava_hzmo: null, odjava_hzmo: null, ordinacija_opce_medicine: null,
      ginekolog: null, zubar: null, terapija_komentar: null,
    });
    setForm({ full_name: '', email: '', phone: '', skills: '', experience_years: '', notes: '' });
    setIsAddOpen(false);
  };

  const toggleSort = (field: SortField) => {
    if (sortField === field) setSortDirection(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortField(field); setSortDirection('asc'); }
  };

  const filteredAndSorted = useMemo(() => {
    let result = candidates.filter(
      (c) =>
        (c.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.candidate_code?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.skills?.some((s) => s.toLowerCase().includes(searchTerm.toLowerCase()))) &&
        (statusFilter === 'all' || c.status === statusFilter)
    );
    result.sort((a, b) => {
      const dir = sortDirection === 'asc' ? 1 : -1;
      const aVal = a[sortField]; const bVal = b[sortField];
      if (aVal == null && bVal == null) return 0;
      if (aVal == null) return 1; if (bVal == null) return -1;
      if (typeof aVal === 'string' && typeof bVal === 'string') return aVal.localeCompare(bVal) * dir;
      if (typeof aVal === 'number' && typeof bVal === 'number') return (aVal - bVal) * dir;
      return 0;
    });
    return result;
  }, [candidates, searchTerm, statusFilter, sortField, sortDirection]);

  const statusCounts = useMemo(() => ({
    all: candidates.length,
    available: candidates.filter(c => c.status === 'available').length,
    claimed: candidates.filter(c => c.status === 'claimed').length,
    rejected: candidates.filter(c => c.status === 'rejected').length,
  }), [candidates]);

  const SortButton = ({ field, children }: { field: SortField; children: React.ReactNode }) => (
    <button className="flex items-center gap-1 hover:text-foreground transition-colors" onClick={() => toggleSort(field)}>
      {children}
      <ArrowUpDown className={`w-3 h-3 ${sortField === field ? 'text-primary' : 'text-muted-foreground/40'}`} />
    </button>
  );

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-header">Candidates</h1>
          <p className="page-subheader">Manage your candidate master pool</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setIsBulkPhotoOpen(true)} className="hidden sm:flex">
            <ImageIcon className="w-4 h-4 mr-1.5" />Photos
          </Button>
          <Button variant="outline" size="sm" onClick={() => setIsCSVOpen(true)} className="hidden sm:flex">
            <Upload className="w-4 h-4 mr-1.5" />Import
          </Button>
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button className="btn-primary-gradient" size="sm"><Plus className="w-4 h-4 mr-1.5" />Add Candidate</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader><DialogTitle>Add New Candidate</DialogTitle></DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                <div><label className="input-label">Full Name *</label><Input value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} placeholder="John Doe" required /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><label className="input-label">Email</label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="john@email.com" /></div>
                  <div><label className="input-label">Phone</label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+1 234 567 890" /></div>
                </div>
                <div><label className="input-label">Skills (comma separated)</label><Input value={form.skills} onChange={(e) => setForm({ ...form, skills: e.target.value })} placeholder="React, TypeScript, Node.js" /></div>
                <div><label className="input-label">Years of Experience</label><Input type="number" value={form.experience_years} onChange={(e) => setForm({ ...form, experience_years: e.target.value })} placeholder="5" /></div>
                <div><label className="input-label">Notes</label><Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Additional notes..." rows={3} /></div>
                <p className="text-xs text-muted-foreground">A unique ID will be auto-generated.</p>
                <div className="flex justify-end gap-3 pt-2">
                  <Button type="button" variant="outline" onClick={() => setIsAddOpen(false)}>Cancel</Button>
                  <Button type="submit" className="btn-primary-gradient" disabled={createCandidate.isPending}>{createCandidate.isPending ? 'Adding...' : 'Add Candidate'}</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Main card */}
      <div className="card-elevated">
        {/* Status tabs */}
        <div className="flex items-center gap-1 p-3 pb-0 overflow-x-auto">
          {(['all', 'available', 'claimed', 'rejected'] as const).map((key) => (
            <button key={key} onClick={() => setStatusFilter(key)}
              className={`px-3 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                statusFilter === key ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
              }`}>
              {key.charAt(0).toUpperCase() + key.slice(1)}
              <span className="ml-1.5 text-[10px] opacity-60">{statusCounts[key]}</span>
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="flex items-center gap-3 p-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search by name, ID, email, or skill..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10 h-9 text-sm" />
            {searchTerm && (
              <button onClick={() => setSearchTerm('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
          <div className="text-xs text-muted-foreground whitespace-nowrap">{filteredAndSorted.length} result{filteredAndSorted.length !== 1 ? 's' : ''}</div>
        </div>

        {/* Table */}
        {isLoading ? (
          <div className="space-y-3 p-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center gap-4">
                <div className="w-8 h-8 rounded-full skeleton-pulse" />
                <div className="flex-1 space-y-2"><div className="h-4 w-40 skeleton-pulse" /><div className="h-3 w-24 skeleton-pulse" /></div>
                <div className="h-6 w-16 skeleton-pulse rounded-full" />
              </div>
            ))}
          </div>
        ) : filteredAndSorted.length === 0 ? (
          <div className="py-16 text-center">
            <div className="w-14 h-14 rounded-2xl bg-muted flex items-center justify-center mx-auto mb-4"><UserPlus className="w-7 h-7 text-muted-foreground" /></div>
            <h3 className="font-semibold text-foreground mb-1">No candidates found</h3>
            <p className="text-muted-foreground text-sm">{searchTerm || statusFilter !== 'all' ? 'Try adjusting your search or filters' : 'Add your first candidate to get started'}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="table-header w-[80px]"><SortButton field="candidate_code">ID</SortButton></TableHead>
                  <TableHead className="table-header"><SortButton field="full_name">Name</SortButton></TableHead>
                  <TableHead className="table-header hidden md:table-cell"><SortButton field="email">Email</SortButton></TableHead>
                  <TableHead className="table-header hidden lg:table-cell">Skills</TableHead>
                  <TableHead className="table-header hidden md:table-cell w-[80px]"><SortButton field="experience_years">Exp.</SortButton></TableHead>
                  <TableHead className="table-header hidden lg:table-cell">Assigned To</TableHead>
                  <TableHead className="table-header w-[100px]"><SortButton field="status">Status</SortButton></TableHead>
                  <TableHead className="table-header text-right w-[140px]">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAndSorted.map((candidate) => {
                  const initials = candidate.full_name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
                  return (
                    <TableRow key={candidate.id} className="group hover:bg-muted/30 transition-colors">
                      <TableCell><code className="text-[11px] font-mono px-1.5 py-0.5 bg-muted rounded text-muted-foreground">{candidate.candidate_code}</code></TableCell>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8 shrink-0">
                            {candidate.profile_picture_url ? <AvatarImage src={candidate.profile_picture_url} alt={candidate.full_name} className="object-cover" /> : null}
                            <AvatarFallback className="text-[10px] bg-primary/10 text-primary font-semibold">{initials}</AvatarFallback>
                          </Avatar>
                          <button onClick={() => openCandidateProfile(candidate.id)} className="hover:underline text-left text-sm font-medium text-foreground hover:text-primary transition-colors">
                            {candidate.full_name}
                          </button>
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm hidden md:table-cell">{candidate.email || <span className="text-muted-foreground/40">—</span>}</TableCell>
                      <TableCell className="hidden lg:table-cell">
                        <div className="flex flex-wrap gap-1">
                          {candidate.skills?.slice(0, 3).map((skill) => (<span key={skill} className="badge-pill">{skill}</span>))}
                          {candidate.skills && candidate.skills.length > 3 && <span className="text-[10px] text-muted-foreground self-center">+{candidate.skills.length - 3}</span>}
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm hidden md:table-cell">{candidate.experience_years ? `${candidate.experience_years} yrs` : <span className="text-muted-foreground/40">—</span>}</TableCell>
                      <TableCell className="hidden lg:table-cell">
                        {(() => {
                          const companies = candidateAssignmentMap.get(candidate.id);
                          if (!companies || companies.size === 0) return <span className="text-muted-foreground/40 text-xs">—</span>;
                          return (
                            <div className="flex flex-wrap gap-1">
                              {Array.from(companies).map(name => (
                                <span key={name} className="badge-pill text-[10px] bg-violet-500/10 text-violet-600 dark:text-violet-400 border-violet-500/20">{name}</span>
                              ))}
                            </div>
                          );
                        })()}
                      </TableCell>
                      <TableCell>
                        <span className={`status-badge text-[10px] ${candidate.status === 'available' ? 'status-available' : candidate.status === 'claimed' ? 'status-claimed' : candidate.status === 'rejected' ? 'status-rejected' : 'status-pending'}`}>
                          {candidate.status}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => openCandidateProfile(candidate.id)}><Eye className="w-4 h-4" /></Button>
                          {candidate.status === 'available' && (
                            <Button size="sm" variant="outline" className="h-8 text-xs" onClick={() => setAssignCandidate(candidate.id)}><UserPlus className="w-3.5 h-3.5 mr-1" />Assign</Button>
                          )}
                          <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-destructive hover:text-destructive hover:bg-destructive/10" onClick={() => setDeleteId(candidate.id)}><Trash2 className="w-4 h-4" /></Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </div>

      {/* Dialogs */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Delete Candidate</AlertDialogTitle><AlertDialogDescription>Are you sure? This action cannot be undone.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => { if (deleteId) { deleteCandidate.mutate(deleteId); setDeleteId(null); } }} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <AssignCandidateDialog candidateId={assignCandidate} open={!!assignCandidate} onOpenChange={() => setAssignCandidate(null)} />
      <CandidateCSVUploadDialog open={isCSVOpen} onOpenChange={setIsCSVOpen} />
      <BulkPhotoUploadDialog open={isBulkPhotoOpen} onOpenChange={setIsBulkPhotoOpen} />
    </div>
  );
};

export default Candidates;
