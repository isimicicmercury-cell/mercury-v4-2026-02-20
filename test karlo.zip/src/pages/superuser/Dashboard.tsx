import { useCandidates } from '@/hooks/useCandidates';
import { useClients } from '@/hooks/useClients';
import { useAssignments } from '@/hooks/useAssignments';
import { usePipelineTemplates } from '@/hooks/usePipelines';
import {
  Users, Building2, UserCheck, Clock, TrendingUp,
  ArrowUpRight, ArrowRight, GitBranch, Activity
} from 'lucide-react';
import { formatDate } from '@/lib/dateUtils';
import { useNavigate } from 'react-router-dom';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';

const Dashboard = () => {
  const navigate = useNavigate();
  const { data: candidates = [] } = useCandidates();
  const { data: clients = [] } = useClients();
  const { data: assignments = [] } = useAssignments();
  const { data: pipelines = [] } = usePipelineTemplates();

  const availableCandidates = candidates.filter((c) => c.status === 'available');
  const claimedCandidates = candidates.filter((c) => c.status === 'claimed');
  const pendingAssignments = assignments.filter((a) => a.status === 'pending');
  const activeClients = clients.filter((c) => !c.is_banned);

  const stats = [
    {
      label: 'Total Candidates',
      value: candidates.length,
      icon: Users,
      change: `${availableCandidates.length} available`,
      color: 'text-blue-600 dark:text-blue-400',
      bgColor: 'bg-blue-500/10',
      iconBg: 'bg-blue-500',
    },
    {
      label: 'Active Clients',
      value: activeClients.length,
      icon: Building2,
      change: `${clients.length} total`,
      color: 'text-violet-600 dark:text-violet-400',
      bgColor: 'bg-violet-500/10',
      iconBg: 'bg-violet-500',
    },
    {
      label: 'Claimed',
      value: claimedCandidates.length,
      icon: UserCheck,
      change: candidates.length > 0 ? `${Math.round((claimedCandidates.length / candidates.length) * 100)}% rate` : '0% rate',
      color: 'text-emerald-600 dark:text-emerald-400',
      bgColor: 'bg-emerald-500/10',
      iconBg: 'bg-emerald-500',
    },
    {
      label: 'Pending Reviews',
      value: pendingAssignments.length,
      icon: Clock,
      change: 'needs attention',
      color: 'text-amber-600 dark:text-amber-400',
      bgColor: 'bg-amber-500/10',
      iconBg: 'bg-amber-500',
    },
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Page header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-header">Dashboard</h1>
          <p className="page-subheader">Overview of your recruitment pipeline</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-medium">
            <Activity className="w-3.5 h-3.5" />
            <span>System Online</span>
          </div>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <div
            key={stat.label}
            className={`stat-card group animate-slide-up stagger-${index + 1}`}
          >
            <div className="flex items-start justify-between mb-4">
              <div className={`p-2.5 rounded-xl ${stat.bgColor} transition-transform group-hover:scale-110`}>
                <stat.icon className={`w-5 h-5 ${stat.color}`} />
              </div>
              <ArrowUpRight className="w-4 h-4 text-muted-foreground/40 group-hover:text-muted-foreground transition-colors" />
            </div>
            <p className="stat-value">{stat.value}</p>
            <div className="flex items-center justify-between mt-1">
              <p className="stat-label">{stat.label}</p>
              <span className="text-xs text-muted-foreground">{stat.change}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Content grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Candidates - spans 2 cols */}
        <div className="lg:col-span-2 card-elevated">
          <div className="flex items-center justify-between p-5 pb-0">
            <div>
              <h2 className="text-base font-semibold text-foreground">Recent Candidates</h2>
              <p className="text-xs text-muted-foreground mt-0.5">{candidates.length} total in pool</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="text-xs text-muted-foreground hover:text-foreground"
              onClick={() => navigate('/candidates')}
            >
              View all
              <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </Button>
          </div>
          <div className="p-5">
            <div className="space-y-1">
              {candidates.slice(0, 6).map((candidate) => {
                const initials = candidate.full_name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || '?';
                return (
                  <div
                    key={candidate.id}
                    className="flex items-center gap-3 py-2.5 px-3 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer group"
                    onClick={() => navigate(`/candidates/${candidate.id}`)}
                  >
                    <Avatar className="h-9 w-9 shrink-0">
                      {candidate.profile_picture_url ? (
                        <AvatarImage src={candidate.profile_picture_url} alt={candidate.full_name} className="object-cover" />
                      ) : null}
                      <AvatarFallback className="text-xs bg-primary/10 text-primary font-semibold">{initials}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm text-foreground truncate group-hover:text-primary transition-colors">{candidate.full_name}</p>
                      <p className="text-xs text-muted-foreground truncate">
                        {candidate.skills?.slice(0, 2).join(', ') || 'No skills listed'}
                      </p>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      {candidate.candidate_code && (
                        <code className="text-[10px] font-mono px-1.5 py-0.5 bg-muted rounded text-muted-foreground hidden sm:block">
                          {candidate.candidate_code}
                        </code>
                      )}
                      <span
                        className={`status-badge text-[10px] ${
                          candidate.status === 'available'
                            ? 'status-available'
                            : candidate.status === 'claimed'
                            ? 'status-claimed'
                            : candidate.status === 'rejected'
                            ? 'status-rejected'
                            : 'status-pending'
                        }`}
                      >
                        {candidate.status}
                      </span>
                    </div>
                  </div>
                );
              })}
              {candidates.length === 0 && (
                <div className="py-8 text-center">
                  <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center mx-auto mb-3">
                    <Users className="w-6 h-6 text-muted-foreground" />
                  </div>
                  <p className="text-muted-foreground text-sm">No candidates yet</p>
                  <p className="text-muted-foreground/60 text-xs mt-1">Add your first candidate to get started</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right column */}
        <div className="space-y-6">
          {/* Active Clients */}
          <div className="card-elevated">
            <div className="flex items-center justify-between p-5 pb-0">
              <h2 className="text-base font-semibold text-foreground">Active Clients</h2>
              <Button
                variant="ghost"
                size="sm"
                className="text-xs text-muted-foreground hover:text-foreground"
                onClick={() => navigate('/clients')}
              >
                View all
                <ArrowRight className="w-3.5 h-3.5 ml-1" />
              </Button>
            </div>
            <div className="p-5">
              <div className="space-y-1">
                {clients.slice(0, 5).map((client) => (
                  <div
                    key={client.id}
                    className="flex items-center gap-3 py-2 px-2 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
                    onClick={() => navigate(`/clients/${client.id}`)}
                  >
                    {client.logo_url ? (
                      <img src={client.logo_url} alt="" className="w-8 h-8 rounded-lg object-contain bg-muted border" />
                    ) : (
                      <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center">
                        <Building2 className="w-4 h-4 text-muted-foreground" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm text-foreground truncate">{client.company_name}</p>
                      <p className="text-xs text-muted-foreground truncate">
                        {client.contact_name || 'No contact'}
                      </p>
                    </div>
                    <span className="text-[10px] text-muted-foreground shrink-0">
                      {formatDate(client.created_at)}
                    </span>
                  </div>
                ))}
                {clients.length === 0 && (
                  <div className="py-6 text-center">
                    <Building2 className="w-6 h-6 text-muted-foreground mx-auto mb-2" />
                    <p className="text-muted-foreground text-sm">No clients yet</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="card-elevated p-5">
            <h2 className="text-base font-semibold text-foreground mb-4">Quick Actions</h2>
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: 'Add Candidate', icon: Users, path: '/candidates' },
                { label: 'Add Client', icon: Building2, path: '/clients' },
                { label: 'Assignments', icon: UserCheck, path: '/assignments' },
                { label: 'Pipelines', icon: GitBranch, path: '/pipelines' },
              ].map((action) => (
                <button
                  key={action.label}
                  onClick={() => navigate(action.path)}
                  className="flex flex-col items-center gap-2 p-3 rounded-xl border border-border/50 bg-muted/30 hover:bg-muted/50 hover:border-border transition-all text-center group"
                >
                  <action.icon className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
                  <span className="text-xs font-medium text-muted-foreground group-hover:text-foreground transition-colors">{action.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
