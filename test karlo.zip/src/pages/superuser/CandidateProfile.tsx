import { useState, useEffect, forwardRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useCandidates, useUpdateCandidate, Candidate } from '@/hooks/useCandidates';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { ArrowLeft, CalendarIcon, Plus, X, Download, Archive } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { CandidateDocumentUploader } from '@/components/candidates/CandidateDocumentUploader';
import { CandidatePhotoUploader } from '@/components/candidates/CandidatePhotoUploader';
import CandidatePipelineView from '@/components/pipeline/CandidatePipelineView';
import { useCandidateDocuments, getDocumentDownloadUrl } from '@/hooks/useCandidateDocuments';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import JSZip from 'jszip';

interface GsmEntry {
  type: string;
  number: string;
}

const GSM_TYPES = ['Phone', 'WhatsApp', 'Viber', 'Telegram', 'Signal', 'Other'];

const CandidateProfile = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { data: candidates = [] } = useCandidates();
  const { data: documents = [] } = useCandidateDocuments(id || null);
  const updateCandidate = useUpdateCandidate();
  const [isEditing, setIsEditing] = useState(false);
  const [form, setForm] = useState<Record<string, any>>({});
  const [gsmEntries, setGsmEntries] = useState<GsmEntry[]>([]);
  const [isDownloadingAll, setIsDownloadingAll] = useState(false);

  const candidate = candidates.find((c) => c.id === id);

  useEffect(() => {
    if (candidate) {
      setForm({
        prezime: candidate.prezime || '',
        ime: candidate.ime || '',
        full_name: candidate.full_name || '',
        email: candidate.email || '',
        prijava_drb: candidate.prijava_drb || '',
        viza_d_form_ref_no: candidate.viza_d_form_ref_no || '',
        viza_d_status: candidate.viza_d_status || '',
        plane_ticket: candidate.plane_ticket || '',
        mjesto_i_drzava_rodenja: candidate.mjesto_i_drzava_rodenja || '',
        datum_rodenja: candidate.datum_rodenja || null,
        drzavljanstvo: candidate.drzavljanstvo || '',
        vrsta_i_broj_putovnice: candidate.vrsta_i_broj_putovnice || '',
        mjesto_izdavanja_putovnice: candidate.mjesto_izdavanja_putovnice || '',
        vrijedi_od_do: candidate.vrijedi_od_do || '',
        vrsta_i_broj_vize_mjesto_izdavanja: candidate.vrsta_i_broj_vize_mjesto_izdavanja || '',
        rok_vazenja_vize: candidate.rok_vazenja_vize || null,
        datum_i_mjesto_ulaska_u_rh: candidate.datum_i_mjesto_ulaska_u_rh || '',
        rok_odobrenja_boravka: candidate.rok_odobrenja_boravka || null,
        novi_smjestaj_boraviste: candidate.novi_smjestaj_boraviste || '',
        prethodni_smjestaj: candidate.prethodni_smjestaj || '',
        datum_prijave_16a: candidate.datum_prijave_16a || null,
        datum_odjave_16a: candidate.datum_odjave_16a || null,
        oib: candidate.oib || '',
        ime_oca: candidate.ime_oca || '',
        ime_majke: candidate.ime_majke || '',
        zanimanje: candidate.zanimanje || '',
        skolska_sprema: candidate.skolska_sprema || '',
        radno_mjesto: candidate.radno_mjesto || '',
        termin_lijecnickog: candidate.termin_lijecnickog || '',
        iban: candidate.iban || '',
        prijava_hzmo: candidate.prijava_hzmo || null,
        odjava_hzmo: candidate.odjava_hzmo || null,
        ordinacija_opce_medicine: candidate.ordinacija_opce_medicine || '',
        ginekolog: candidate.ginekolog || '',
        zubar: candidate.zubar || '',
        terapija_komentar: candidate.terapija_komentar || '',
        notes: candidate.notes || '',
        skills: candidate.skills?.join(', ') || '',
        experience_years: candidate.experience_years?.toString() || '',
        phone: candidate.phone || '',
      });
      setGsmEntries(Array.isArray(candidate.gsm) ? candidate.gsm : []);
      setIsEditing(false);
    }
  }, [candidate]);

  const handleSave = async () => {
    if (!candidate) return;
    await updateCandidate.mutateAsync({
      id: candidate.id,
      ...form,
      datum_rodenja: form.datum_rodenja || null,
      rok_vazenja_vize: form.rok_vazenja_vize || null,
      rok_odobrenja_boravka: form.rok_odobrenja_boravka || null,
      datum_prijave_16a: form.datum_prijave_16a || null,
      datum_odjave_16a: form.datum_odjave_16a || null,
      prijava_hzmo: form.prijava_hzmo || null,
      odjava_hzmo: form.odjava_hzmo || null,
      skills: form.skills ? form.skills.split(',').map((s: string) => s.trim()) : null,
      experience_years: form.experience_years ? parseInt(form.experience_years) : null,
      gsm: gsmEntries,
    });
    setIsEditing(false);
  };

  const handleDownloadAll = async () => {
    if (documents.length === 0) return;
    setIsDownloadingAll(true);
    try {
      const zip = new JSZip();
      for (const doc of documents) {
        const { data, error } = await supabase.storage.from('candidate-documents').download(doc.file_path);
        if (error) { console.error(`Failed to download ${doc.file_name}:`, error); continue; }
        zip.file(doc.file_name, data);
      }
      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${candidate?.full_name || 'candidate'}_documents.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast({ title: 'Download complete', description: `Downloaded ${documents.length} documents as ZIP.` });
    } catch (error) {
      toast({ title: 'Download failed', description: 'Failed to create ZIP file.', variant: 'destructive' });
    } finally {
      setIsDownloadingAll(false);
    }
  };

  const addGsmEntry = () => setGsmEntries([...gsmEntries, { type: 'Phone', number: '' }]);
  const removeGsmEntry = (index: number) => setGsmEntries(gsmEntries.filter((_, i) => i !== index));
  const updateGsmEntry = (index: number, field: 'type' | 'number', value: string) => {
    const updated = [...gsmEntries];
    updated[index][field] = value;
    setGsmEntries(updated);
  };

  const DatePickerField = forwardRef<HTMLDivElement, { label: string; value: string | null; onChange: (date: string | null) => void }>(({ label, value, onChange }, ref) => {
    const dateValue = value ? new Date(value) : undefined;
    return (
      <div ref={ref} className="space-y-1">
        <Label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</Label>
        {isEditing ? (
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className={cn("w-full justify-start text-left font-normal", !dateValue && "text-muted-foreground")}>
                <CalendarIcon className="mr-2 h-4 w-4" />
                {dateValue ? format(dateValue, "dd.MM.yyyy") : "Select date"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar mode="single" selected={dateValue} onSelect={(date) => onChange(date ? format(date, 'yyyy-MM-dd') : null)} initialFocus className={cn("p-3 pointer-events-auto")} />
            </PopoverContent>
          </Popover>
        ) : (
          <p className="text-sm font-medium text-foreground py-1.5">{dateValue ? format(dateValue, "dd.MM.yyyy") : <span className="text-muted-foreground/50">—</span>}</p>
        )}
      </div>
    );
  });
  DatePickerField.displayName = 'DatePickerField';

  const TextField = ({ label, name, placeholder = '', type = 'text' }: { label: string; name: string; placeholder?: string; type?: string }) => (
    <div className="space-y-1">
      <Label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</Label>
      {isEditing ? (
        <Input type={type} value={form[name] || ''} onChange={(e) => setForm({ ...form, [name]: e.target.value })} placeholder={placeholder} />
      ) : (
        <p className="text-sm font-medium text-foreground py-1.5">{form[name] || <span className="text-muted-foreground/50">—</span>}</p>
      )}
    </div>
  );

  const TextAreaField = ({ label, name, placeholder = '' }: { label: string; name: string; placeholder?: string }) => (
    <div className="space-y-1">
      <Label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</Label>
      {isEditing ? (
        <Textarea value={form[name] || ''} onChange={(e) => setForm({ ...form, [name]: e.target.value })} placeholder={placeholder} rows={3} />
      ) : (
        <p className="text-sm font-medium text-foreground py-1.5 whitespace-pre-wrap">{form[name] || <span className="text-muted-foreground/50">—</span>}</p>
      )}
    </div>
  );

  const SectionHeader = ({ title }: { title: string }) => (
    <div className="border-b border-border pb-2 mb-4">
      <h3 className="text-sm font-semibold text-foreground uppercase tracking-wider">{title}</h3>
    </div>
  );

  if (!candidate) {
    return (
      <div className="space-y-6 animate-fade-in">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate('/candidates')}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div><h1 className="page-header">Candidate Not Found</h1></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header with photo */}
      <div className="flex items-start justify-between">
        <div className="flex items-start gap-6">
          <Button variant="ghost" size="icon" onClick={() => navigate('/candidates')} className="mt-1">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          
          <CandidatePhotoUploader
            candidateId={candidate.id}
            candidateCode={candidate.candidate_code}
            currentPhotoUrl={candidate.profile_picture_url}
            candidateName={candidate.full_name}
          />

          <div className="space-y-2">
            <h1 className="text-2xl font-bold text-foreground">{candidate.full_name}</h1>
            <div className="flex items-center gap-3">
              <span className={`status-badge ${
                candidate.status === 'available' ? 'status-available' :
                candidate.status === 'claimed' ? 'status-claimed' : 'status-pending'
              }`}>
                {candidate.status}
              </span>
              {candidate.zanimanje && (
                <span className="text-sm text-muted-foreground">{candidate.zanimanje}</span>
              )}
            </div>
            {candidate.email && <p className="text-sm text-muted-foreground">{candidate.email}</p>}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {isEditing ? (
            <>
              <Button variant="outline" onClick={() => setIsEditing(false)}>Cancel</Button>
              <Button className="btn-primary-gradient" onClick={handleSave} disabled={updateCandidate.isPending}>
                {updateCandidate.isPending ? 'Saving...' : 'Save Changes'}
              </Button>
            </>
          ) : (
            <Button variant="outline" onClick={() => setIsEditing(true)}>Edit Profile</Button>
          )}
        </div>
      </div>

      <div className="card-elevated p-6">
        <Tabs defaultValue="pipeline" className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-6">
            <TabsTrigger value="pipeline">Pipeline</TabsTrigger>
            <TabsTrigger value="personal">Personal</TabsTrigger>
            <TabsTrigger value="documents">Documents</TabsTrigger>
            <TabsTrigger value="residence">Residence</TabsTrigger>
            <TabsTrigger value="medical">Medical</TabsTrigger>
          </TabsList>

          <TabsContent value="pipeline" className="space-y-6">
            <CandidatePipelineView candidateId={candidate.id} />
          </TabsContent>

          <TabsContent value="personal" className="space-y-6">
            <SectionHeader title="Identity" />
            <div className="grid grid-cols-2 gap-x-8 gap-y-4">
              <TextField label="Prezime (Surname)" name="prezime" />
              <TextField label="Ime (First Name)" name="ime" />
              <TextField label="Full Name" name="full_name" />
              <TextField label="Email" name="email" type="email" />
              <TextField label="Mjesto i država rođenja" name="mjesto_i_drzava_rodenja" />
              <DatePickerField label="Datum rođenja" value={form.datum_rodenja} onChange={(date) => setForm({ ...form, datum_rodenja: date })} />
              <TextField label="Državljanstvo" name="drzavljanstvo" />
              <TextField label="OIB" name="oib" />
            </div>

            <SectionHeader title="Family" />
            <div className="grid grid-cols-2 gap-x-8 gap-y-4">
              <TextField label="Ime oca" name="ime_oca" />
              <TextField label="Ime majke" name="ime_majke" />
            </div>

            <SectionHeader title="Professional" />
            <div className="grid grid-cols-2 gap-x-8 gap-y-4">
              <TextField label="Zanimanje" name="zanimanje" />
              <TextField label="Školska sprema" name="skolska_sprema" />
              <TextField label="Radno mjesto" name="radno_mjesto" />
              <TextField label="Years of Experience" name="experience_years" type="number" />
              <div className="col-span-2">
                <TextField label="Skills (comma separated)" name="skills" />
              </div>
            </div>

            <SectionHeader title="Financial" />
            <div className="grid grid-cols-2 gap-x-8 gap-y-4">
              <TextField label="IBAN" name="iban" />
            </div>

            <SectionHeader title="Contact" />
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">GSM / Contacts</Label>
                {isEditing && (
                  <Button type="button" variant="outline" size="sm" onClick={addGsmEntry}>
                    <Plus className="w-4 h-4 mr-1" />Add
                  </Button>
                )}
              </div>
              {isEditing ? (
                <div className="space-y-2">
                  {gsmEntries.map((entry, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <Select value={entry.type} onValueChange={(value) => updateGsmEntry(index, 'type', value)}>
                        <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                        <SelectContent>{GSM_TYPES.map((type) => (<SelectItem key={type} value={type}>{type}</SelectItem>))}</SelectContent>
                      </Select>
                      <Input value={entry.number} onChange={(e) => updateGsmEntry(index, 'number', e.target.value)} placeholder="Number" className="flex-1" />
                      <Button type="button" variant="ghost" size="icon" onClick={() => removeGsmEntry(index)} className="text-destructive hover:text-destructive"><X className="w-4 h-4" /></Button>
                    </div>
                  ))}
                  {gsmEntries.length === 0 && <p className="text-sm text-muted-foreground">No contacts added</p>}
                </div>
              ) : (
                <div className="space-y-1">
                  {gsmEntries.length > 0 ? (
                    gsmEntries.map((entry, index) => (
                      <p key={index} className="text-sm font-medium">
                        <span className="text-muted-foreground text-xs uppercase mr-2">{entry.type}:</span>{entry.number}
                      </p>
                    ))
                  ) : (<p className="text-sm text-muted-foreground/50">—</p>)}
                </div>
              )}
              <TextField label="Phone (Legacy)" name="phone" />
            </div>

            <SectionHeader title="Notes" />
            <TextAreaField label="Notes" name="notes" />
          </TabsContent>

          <TabsContent value="documents" className="space-y-6">
            {documents.length > 0 && (
              <div className="flex justify-end mb-4">
                <Button variant="outline" onClick={handleDownloadAll} disabled={isDownloadingAll}>
                  <Archive className="w-4 h-4 mr-2" />
                  {isDownloadingAll ? 'Creating ZIP...' : `Download All (${documents.length})`}
                </Button>
              </div>
            )}
            <div className="mb-6 p-4 border rounded-lg bg-muted/30">
              <h4 className="text-sm font-semibold text-muted-foreground mb-3">Uploaded Files (CV, etc.)</h4>
              <CandidateDocumentUploader candidateId={candidate.id} />
            </div>

            <SectionHeader title="Passport & Travel" />
            <div className="grid grid-cols-2 gap-x-8 gap-y-4">
              <TextField label="Vrsta i broj putovnice" name="vrsta_i_broj_putovnice" />
              <TextField label="Mjesto izdavanja putovnice" name="mjesto_izdavanja_putovnice" />
              <TextField label="Vrijedi od/do" name="vrijedi_od_do" />
              <TextField label="Plane Ticket" name="plane_ticket" />
            </div>

            <SectionHeader title="Visa" />
            <div className="grid grid-cols-2 gap-x-8 gap-y-4">
              <TextField label="Vrsta i broj vize / Mjesto izdavanja" name="vrsta_i_broj_vize_mjesto_izdavanja" />
              <DatePickerField label="Rok važenja vize" value={form.rok_vazenja_vize} onChange={(date) => setForm({ ...form, rok_vazenja_vize: date })} />
              <TextField label="Viza D Form Ref No" name="viza_d_form_ref_no" />
              <TextField label="Viza D Status" name="viza_d_status" />
              <TextField label="Prijava DRB" name="prijava_drb" />
            </div>
          </TabsContent>

          <TabsContent value="residence" className="space-y-6">
            <SectionHeader title="Entry & Residence" />
            <div className="grid grid-cols-2 gap-x-8 gap-y-4">
              <TextField label="Datum i mjesto ulaska u RH" name="datum_i_mjesto_ulaska_u_rh" />
              <DatePickerField label="Rok odobrenja boravka" value={form.rok_odobrenja_boravka} onChange={(date) => setForm({ ...form, rok_odobrenja_boravka: date })} />
            </div>

            <SectionHeader title="Accommodation" />
            <div className="grid grid-cols-2 gap-x-8 gap-y-4">
              <TextField label="Novi smještaj / Boravište" name="novi_smjestaj_boraviste" />
              <TextField label="Prethodni smještaj" name="prethodni_smjestaj" />
            </div>

            <SectionHeader title="Registration" />
            <div className="grid grid-cols-2 gap-x-8 gap-y-4">
              <DatePickerField label="Datum prijave 16a" value={form.datum_prijave_16a} onChange={(date) => setForm({ ...form, datum_prijave_16a: date })} />
              <DatePickerField label="Datum odjave 16a" value={form.datum_odjave_16a} onChange={(date) => setForm({ ...form, datum_odjave_16a: date })} />
              <DatePickerField label="Prijava HZMO" value={form.prijava_hzmo} onChange={(date) => setForm({ ...form, prijava_hzmo: date })} />
              <DatePickerField label="Odjava HZMO" value={form.odjava_hzmo} onChange={(date) => setForm({ ...form, odjava_hzmo: date })} />
            </div>
          </TabsContent>

          <TabsContent value="medical" className="space-y-6">
            <SectionHeader title="Medical Appointments" />
            <div className="grid grid-cols-2 gap-x-8 gap-y-4">
              <TextField label="Termin liječničkog" name="termin_lijecnickog" />
              <TextField label="Ordinacija opće medicine" name="ordinacija_opce_medicine" />
              <TextField label="Ginekolog" name="ginekolog" />
              <TextField label="Zubar" name="zubar" />
            </div>
            <SectionHeader title="Therapy & Notes" />
            <TextAreaField label="Terapija / Komentar" name="terapija_komentar" />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default CandidateProfile;
