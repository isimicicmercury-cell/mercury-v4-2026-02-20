import { useState, useMemo } from 'react';
import { usePendingChanges, useApproveChanges, useRejectChanges, PendingChange } from '@/hooks/usePendingChanges';
import { useClients, useUpdateClient, Client } from '@/hooks/useClients';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Check, X, Clock, Building2, FileText, AlertCircle, AlertTriangle, ShieldCheck, ShieldX } from 'lucide-react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { ChangeComparisonCard } from '@/components/changes/ChangeComparisonCard';
import { formatDate, formatDateTime } from '@/lib/dateUtils';
import { Badge } from '@/components/ui/badge';

interface GroupedChanges {
  client: PendingChange['client'];
  clientId: string;
  changes: PendingChange[];
}

const PendingApprovals = () => {
  const { data: pendingChanges = [], isLoading } = usePendingChanges();
  const { data: clients = [] } = useClients();
  const approveChanges = useApproveChanges();
  const rejectChanges = useRejectChanges();
  const updateClient = useUpdateClient();

  const [selectedChange, setSelectedChange] = useState<PendingChange | null>(null);
  const [rejectDialogOpen, setRejectDialogOpen] = useState(false);
  const [rejectNotes, setRejectNotes] = useState('');
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [fraudReviewClient, setFraudReviewClient] = useState<Client | null>(null);

  // Get clients pending fraud review
  const fraudReviewClients = useMemo(() => {
    return clients.filter(c => c.fraud_review_status === 'pending' && c.fraud_match_data);
  }, [clients]);

  // Group changes by client and sort by submission date
  const groupedChanges = useMemo(() => {
    const groups: Record<string, GroupedChanges> = {};
    
    // Sort all changes by date first (oldest first within groups)
    const sortedChanges = [...pendingChanges].sort(
      (a, b) => new Date(a.submitted_at).getTime() - new Date(b.submitted_at).getTime()
    );
    
    sortedChanges.forEach((change) => {
      const clientId = change.client_id;
      if (!groups[clientId]) {
        groups[clientId] = {
          client: change.client,
          clientId,
          changes: [],
        };
      }
      groups[clientId].changes.push(change);
    });

    // Sort groups by the earliest submission date
    return Object.values(groups).sort((a, b) => {
      const aDate = new Date(a.changes[0].submitted_at).getTime();
      const bDate = new Date(b.changes[0].submitted_at).getTime();
      return bDate - aDate;
    });
  }, [pendingChanges]);

  // Get client data for comparison
  const getClientData = (clientId: string): Client | undefined => {
    return clients.find((c) => c.id === clientId);
  };

  const handleApprove = async (change: PendingChange) => {
    await approveChanges.mutateAsync({
      changeId: change.id,
      clientId: change.client_id,
      proposedChanges: change.proposed_changes as Record<string, unknown>,
      clientEmail: change.client?.contact_email,
      companyName: change.client?.company_name,
    });
  };

  const handleReject = async () => {
    if (!selectedChange) return;
    await rejectChanges.mutateAsync({
      changeId: selectedChange.id,
      notes: rejectNotes,
      clientEmail: selectedChange.client?.contact_email,
      companyName: selectedChange.client?.company_name,
      changedFields: Object.keys(selectedChange.proposed_changes as Record<string, unknown>),
    });
    setRejectDialogOpen(false);
    setSelectedChange(null);
    setRejectNotes('');
  };

  const openRejectDialog = (change: PendingChange) => {
    setSelectedChange(change);
    setRejectDialogOpen(true);
  };

  const openDetailDialog = (change: PendingChange) => {
    setSelectedChange(change);
    setDetailDialogOpen(true);
  };

  const getChangesWithComparison = (change: PendingChange) => {
    const clientData = getClientData(change.client_id);
    const proposedChanges = change.proposed_changes as Record<string, unknown>;
    
    return Object.entries(proposedChanges).map(([key, newValue]) => {
      const previousValue = clientData ? (clientData as unknown as Record<string, unknown>)[key] : null;
      return {
        field: key,
        previousValue,
        newValue,
      };
    });
  };

  const handleApproveFraudClient = async (client: Client) => {
    await updateClient.mutateAsync({
      id: client.id,
      fraud_review_status: 'approved',
      fraud_match_data: null,
    });
    setFraudReviewClient(null);
  };

  const handleBanFraudClient = async (client: Client) => {
    await updateClient.mutateAsync({
      id: client.id,
      fraud_review_status: 'banned',
      is_banned: true,
    });
    setFraudReviewClient(null);
  };

  const totalPending = groupedChanges.length + fraudReviewClients.length;

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="page-header flex items-center gap-2">
          <Clock className="w-6 h-6" />
          Pending Approvals
        </h1>
        <p className="page-subheader">
          Review and approve client profile change requests and fraud reviews
        </p>
      </div>

      {isLoading ? (
        <div className="py-12 text-center text-muted-foreground">Loading pending changes...</div>
      ) : totalPending === 0 ? (
        <div className="py-16 text-center">
          <div className="w-20 h-20 rounded-2xl bg-muted flex items-center justify-center mx-auto mb-6">
            <Check className="w-10 h-10 text-muted-foreground" />
          </div>
          <h3 className="text-xl font-semibold text-foreground mb-2">All caught up!</h3>
          <p className="text-muted-foreground max-w-sm mx-auto">
            There are no pending profile change requests or fraud reviews.
          </p>
        </div>
      ) : (
        <Tabs defaultValue="changes">
          <TabsList>
            <TabsTrigger value="changes" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Profile Changes
              {groupedChanges.length > 0 && (
                <Badge variant="secondary">{groupedChanges.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="fraud" className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              Fraud Reviews
              {fraudReviewClients.length > 0 && (
                <Badge variant="destructive">{fraudReviewClients.length}</Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="changes" className="mt-6">
            {groupedChanges.length === 0 ? (
              <div className="py-12 text-center text-muted-foreground">
                No pending profile changes.
              </div>
            ) : (
              <Accordion type="multiple" className="space-y-4">
                {groupedChanges.map((group) => (
                  <AccordionItem
                    key={group.clientId}
                    value={group.clientId}
                    className="card-elevated border rounded-xl overflow-hidden"
                  >
                    <AccordionTrigger className="px-6 py-4 hover:no-underline">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-xl bg-warning/10 flex items-center justify-center">
                          <Building2 className="w-6 h-6 text-warning" />
                        </div>
                        <div className="text-left">
                          <h3 className="text-lg font-semibold">
                            {group.client?.company_name || 'Unknown Client'}
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            {group.changes.length} pending change{group.changes.length !== 1 ? 's' : ''}
                          </p>
                        </div>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="px-6 pb-4">
                      <div className="space-y-4">
                        {group.changes.map((change) => (
                          <Card key={change.id} className="border-dashed">
                            <CardHeader className="pb-3">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <FileText className="w-4 h-4 text-muted-foreground" />
                                  <span className="text-sm text-muted-foreground">
                                    Submitted {formatDateTime(change.submitted_at)}
                                  </span>
                                </div>
                                <span className="status-badge bg-warning/10 text-warning border-warning/20">
                                  Pending
                                </span>
                              </div>
                            </CardHeader>
                            <CardContent className="space-y-4">
                              <Button
                                variant="outline"
                                className="w-full"
                                onClick={() => openDetailDialog(change)}
                              >
                                View Changes
                              </Button>

                              <div className="flex gap-2">
                                <Button
                                  variant="outline"
                                  className="flex-1 text-destructive hover:text-destructive"
                                  onClick={() => openRejectDialog(change)}
                                  disabled={rejectChanges.isPending}
                                >
                                  <X className="w-4 h-4 mr-1" />
                                  Reject
                                </Button>
                                <Button
                                  className="flex-1 btn-primary-gradient"
                                  onClick={() => handleApprove(change)}
                                  disabled={approveChanges.isPending}
                                >
                                  <Check className="w-4 h-4 mr-1" />
                                  Approve
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            )}
          </TabsContent>

          <TabsContent value="fraud" className="mt-6">
            {fraudReviewClients.length === 0 ? (
              <div className="py-12 text-center text-muted-foreground">
                No fraud reviews pending.
              </div>
            ) : (
              <div className="space-y-4">
                {fraudReviewClients.map((client) => (
                  <Card key={client.id} className="border-warning/50 bg-warning/5">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-xl bg-warning/10 flex items-center justify-center">
                            <AlertTriangle className="w-6 h-6 text-warning" />
                          </div>
                          <div>
                            <h3 className="text-lg font-semibold">{client.company_name}</h3>
                            <p className="text-sm text-muted-foreground">{client.contact_name}</p>
                          </div>
                        </div>
                        <Badge variant="outline" className="border-warning text-warning">
                          Fraud Match
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="p-4 bg-muted/50 rounded-lg">
                        <p className="text-sm font-medium mb-2">Matches with banned client:</p>
                        <p className="text-foreground font-semibold">{client.fraud_match_data?.matched_company_name}</p>
                        <p className="text-sm text-muted-foreground mt-2">
                          Matched fields: <span className="font-mono">{client.fraud_match_data?.matched_fields.join(', ')}</span>
                        </p>
                      </div>

                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-muted-foreground">Email:</span>
                          <p>{client.contact_email || '—'}</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Phone:</span>
                          <p>{client.phone || '—'}</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Tax ID:</span>
                          <p>{client.tax_id || '—'}</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Address:</span>
                          <p>{client.address_line || '—'}</p>
                        </div>
                      </div>

                      <div className="flex gap-2 pt-2">
                        <Button
                          variant="destructive"
                          className="flex-1"
                          onClick={() => handleBanFraudClient(client)}
                          disabled={updateClient.isPending}
                        >
                          <ShieldX className="w-4 h-4 mr-1" />
                          Confirm Fraud & Ban
                        </Button>
                        <Button
                          variant="outline"
                          className="flex-1"
                          onClick={() => handleApproveFraudClient(client)}
                          disabled={updateClient.isPending}
                        >
                          <ShieldCheck className="w-4 h-4 mr-1" />
                          Clear & Approve
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      )}

      {/* Detail Dialog - Shows Previous vs New Values */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[85vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Proposed Changes
            </DialogTitle>
            <DialogDescription>
              {selectedChange?.client?.company_name} - Submitted on{' '}
              {selectedChange && formatDateTime(selectedChange.submitted_at)}
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="max-h-[55vh] pr-4">
            <div className="space-y-4 py-4">
              {selectedChange &&
                getChangesWithComparison(selectedChange).map(({ field, previousValue, newValue }) => (
                  <ChangeComparisonCard
                    key={field}
                    field={field}
                    previousValue={previousValue}
                    newValue={newValue}
                  />
                ))}
            </div>
          </ScrollArea>
          <DialogFooter className="gap-2 border-t pt-4">
            <Button
              variant="outline"
              className="text-destructive hover:text-destructive"
              onClick={() => {
                setDetailDialogOpen(false);
                if (selectedChange) openRejectDialog(selectedChange);
              }}
            >
              <X className="w-4 h-4 mr-1" />
              Reject
            </Button>
            <Button
              className="btn-primary-gradient"
              onClick={() => {
                if (selectedChange) handleApprove(selectedChange);
                setDetailDialogOpen(false);
              }}
              disabled={approveChanges.isPending}
            >
              <Check className="w-4 h-4 mr-1" />
              Approve
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={rejectDialogOpen} onOpenChange={setRejectDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-destructive" />
              Reject Changes
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to reject these changes? You can optionally provide a reason.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <label className="input-label">Rejection Notes (optional)</label>
            <Textarea
              placeholder="Explain why these changes were rejected..."
              value={rejectNotes}
              onChange={(e) => setRejectNotes(e.target.value)}
              rows={3}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRejectDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleReject}
              disabled={rejectChanges.isPending}
            >
              Reject Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PendingApprovals;
