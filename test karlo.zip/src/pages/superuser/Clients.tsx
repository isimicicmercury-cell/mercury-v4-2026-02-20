import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useClients, useDeleteClient, useDeleteCompany, useBanClient, useAddRepresentative, Client, checkFraudMatches } from '@/hooks/useClients';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  Collapsible, CollapsibleContent, CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Plus, Trash2, Search, Building2, Eye, EyeOff, Copy, Upload, 
  ChevronDown, ChevronRight, Users, AlertTriangle, Ban, Globe, 
  Phone, Mail, MapPin, FileText, RefreshCw, UserPlus
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { AddClientDialog } from '@/components/clients/AddClientDialog';
import { CSVUploadDialog } from '@/components/clients/CSVUploadDialog';
import { Badge } from '@/components/ui/badge';
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from '@/components/ui/tooltip';
import { generateUsername, generatePassword } from '@/lib/croatianUtils';

interface GroupedClients {
  companyName: string;
  logo_url: string | null;
  clients: Client[];
  isBanned: boolean;
  hasFraudMatch: boolean;
  fraudMatchData: Client['fraud_match_data'];
}

const Clients = () => {
  const navigate = useNavigate();
  const { data: clients = [], isLoading } = useClients();
  const deleteClient = useDeleteClient();
  const deleteCompany = useDeleteCompany();
  const banClient = useBanClient();
  const addRepresentative = useAddRepresentative();
  const { toast } = useToast();

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isCSVOpen, setIsCSVOpen] = useState(false);
  const [deleteUserId, setDeleteUserId] = useState<string | null>(null);
  const [deleteCompanyName, setDeleteCompanyName] = useState<string | null>(null);
  const [banClientData, setBanClientData] = useState<{ id: string; is_banned: boolean } | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [showPasswords, setShowPasswords] = useState<Record<string, boolean>>({});
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());
  const [activeTab, setActiveTab] = useState('active');

  // Add representative dialog state
  const [addRepDialog, setAddRepDialog] = useState<{ open: boolean; group: GroupedClients | null }>({ open: false, group: null });
  const [newRepForm, setNewRepForm] = useState({ first_name: '', last_name: '', email: '', phone: '', work_title: '', login_username: '', login_password: generatePassword() });

  const groupClients = (clientList: Client[]) => {
    const groups: Map<string, GroupedClients> = new Map();
    clientList.forEach((client) => {
      const key = client.company_name;
      if (!groups.has(key)) {
        groups.set(key, { companyName: client.company_name, logo_url: client.logo_url, clients: [], isBanned: false, hasFraudMatch: false, fraudMatchData: null });
      }
      const group = groups.get(key)!;
      group.clients.push(client);
      if (client.logo_url && !group.logo_url) group.logo_url = client.logo_url;
      if (client.is_banned) group.isBanned = true;
      if (client.fraud_match_data) { group.hasFraudMatch = true; group.fraudMatchData = client.fraud_match_data; }
    });
    return Array.from(groups.values()).sort((a, b) => a.companyName.localeCompare(b.companyName));
  };

  const filtered = useMemo(() => {
    return clients.filter(
      (c) =>
        c.company_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.contact_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.contact_email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.login_username?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [clients, searchTerm]);

  const activeClients = useMemo(() => groupClients(filtered.filter(c => !c.is_banned)), [filtered]);
  const bannedClients = useMemo(() => groupClients(filtered.filter(c => c.is_banned)), [filtered]);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: 'Copied!', description: `${label} copied to clipboard.` });
  };

  const togglePasswordVisibility = (id: string) => {
    setShowPasswords((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleGroup = (companyName: string) => {
    const newExpanded = new Set(expandedGroups);
    if (newExpanded.has(companyName)) newExpanded.delete(companyName);
    else newExpanded.add(companyName);
    setExpandedGroups(newExpanded);
  };

  const openClientProfile = (clientId: string) => navigate(`/clients/${clientId}`);

  const handleBanToggle = (client: Client) => {
    setBanClientData({ id: client.id, is_banned: !client.is_banned });
  };

  const confirmBan = () => {
    if (banClientData) {
      banClient.mutate(banClientData);
      setBanClientData(null);
    }
  };

  const openAddRepDialog = (group: GroupedClients) => {
    const newPassword = generatePassword();
    setNewRepForm({ first_name: '', last_name: '', email: '', phone: '', work_title: '', login_username: '', login_password: newPassword });
    setAddRepDialog({ open: true, group });
  };

  const handleAddRepresentative = async () => {
    if (!addRepDialog.group || !newRepForm.email || (!newRepForm.first_name && !newRepForm.last_name)) return;
    const firstClient = addRepDialog.group.clients[0];
    const contactName = `${newRepForm.first_name} ${newRepForm.last_name}`.trim();
    
    await addRepresentative.mutateAsync({
      company_name: addRepDialog.group.companyName,
      contact_name: contactName,
      contact_email: newRepForm.email,
      phone: newRepForm.phone || undefined,
      login_username: newRepForm.login_username,
      login_password: newRepForm.login_password,
      website: firstClient.website || undefined,
      tax_id: firstClient.tax_id || undefined,
      founders_members: firstClient.founders_members || undefined,
      address_line: firstClient.address_line || undefined,
      city: firstClient.city || undefined,
      postal_code: firstClient.postal_code || undefined,
      state: firstClient.state || undefined,
      country: firstClient.country || undefined,
    });
    setAddRepDialog({ open: false, group: null });
  };

  // Update username when name changes in add rep form
  const updateNewRepField = (field: string, value: string) => {
    const updated = { ...newRepForm, [field]: value };
    if (field === 'first_name' || field === 'last_name') {
      const fullName = `${field === 'first_name' ? value : updated.first_name} ${field === 'last_name' ? value : updated.last_name}`.trim();
      updated.login_username = generateUsername(addRepDialog.group?.companyName || '', fullName, 0);
    }
    setNewRepForm(updated);
  };

  const getGroupBasicInfo = (group: GroupedClients) => {
    const firstClient = group.clients[0];
    return { website: firstClient?.website, phone: firstClient?.phone, email: firstClient?.contact_email, city: firstClient?.city, country: firstClient?.country, taxId: firstClient?.tax_id };
  };

  const renderGroupList = (groups: GroupedClients[], showBanButton: boolean) => {
    if (groups.length === 0) {
      return (
        <div className="py-12 text-center">
          <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mx-auto mb-4">
            <Building2 className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="font-semibold text-foreground mb-1">No clients found</h3>
          <p className="text-muted-foreground text-sm">{searchTerm ? 'Try a different search term' : 'No clients in this category'}</p>
        </div>
      );
    }

    return (
      <div className="space-y-2">
        {groups.map((group) => {
          const basicInfo = getGroupBasicInfo(group);
          return (
            <Collapsible key={group.companyName} open={expandedGroups.has(group.companyName)} onOpenChange={() => toggleGroup(group.companyName)}>
              <CollapsibleTrigger asChild>
                <div className={`flex items-center gap-3 p-3 rounded-lg hover:bg-muted/50 cursor-pointer border ${
                  group.isBanned ? 'border-destructive/50 bg-destructive/5' : 
                  group.hasFraudMatch ? 'border-warning/50 bg-warning/5' : 'border-border'
                }`}>
                  <div className="flex items-center gap-3 flex-1">
                    {expandedGroups.has(group.companyName) ? <ChevronDown className="w-4 h-4 text-muted-foreground" /> : <ChevronRight className="w-4 h-4 text-muted-foreground" />}
                    {group.logo_url ? (
                      <img src={group.logo_url} alt={`${group.companyName} logo`} className="w-10 h-10 rounded-lg object-contain bg-muted border border-border" />
                    ) : (
                      <div className="w-10 h-10 rounded-lg bg-muted border border-border flex items-center justify-center"><Building2 className="w-5 h-5 text-muted-foreground" /></div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-foreground">{group.companyName}</p>
                        {group.isBanned && (
                          <TooltipProvider><Tooltip><TooltipTrigger><AlertTriangle className="w-4 h-4 text-destructive" /></TooltipTrigger><TooltipContent><p>Fraudulent - Banned</p></TooltipContent></Tooltip></TooltipProvider>
                        )}
                        {group.hasFraudMatch && !group.isBanned && (
                          <TooltipProvider><Tooltip><TooltipTrigger><AlertTriangle className="w-4 h-4 text-warning" /></TooltipTrigger><TooltipContent><p>Matches with banned client: {group.fraudMatchData?.matched_company_name}</p><p className="text-xs">Fields: {group.fraudMatchData?.matched_fields.join(', ')}</p></TooltipContent></Tooltip></TooltipProvider>
                        )}
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
                        <span className="flex items-center gap-1"><Users className="w-3 h-3" />{group.clients.length} {group.clients.length === 1 ? 'user' : 'users'}</span>
                        {basicInfo.website && <span className="flex items-center gap-1"><Globe className="w-3 h-3" />{basicInfo.website.replace(/^https?:\/\//, '')}</span>}
                        {basicInfo.phone && <span className="flex items-center gap-1"><Phone className="w-3 h-3" />{basicInfo.phone}</span>}
                        {basicInfo.email && <span className="flex items-center gap-1"><Mail className="w-3 h-3" />{basicInfo.email}</span>}
                        {(basicInfo.city || basicInfo.country) && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{[basicInfo.city, basicInfo.country].filter(Boolean).join(', ')}</span>}
                        {basicInfo.taxId && <span className="flex items-center gap-1"><FileText className="w-3 h-3" />OIB: {basicInfo.taxId}</span>}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {group.isBanned && <Badge variant="destructive" className="text-xs">Banned</Badge>}
                    {group.hasFraudMatch && !group.isBanned && <Badge variant="outline" className="text-xs border-warning text-warning">Review</Badge>}
                    <Button size="sm" variant="ghost" onClick={(e) => { e.stopPropagation(); openClientProfile(group.clients[0].id); }}>View Company</Button>
                    <Button size="sm" variant="ghost" onClick={(e) => { e.stopPropagation(); openAddRepDialog(group); }} title="Add Representative">
                      <UserPlus className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive hover:bg-destructive/10" onClick={(e) => { e.stopPropagation(); setDeleteCompanyName(group.companyName); }}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <div className="ml-4 mt-2 border-l-2 border-border pl-4">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="table-header">Representative</TableHead>
                        <TableHead className="table-header">Username</TableHead>
                        <TableHead className="table-header">Password</TableHead>
                        <TableHead className="table-header text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {group.clients.map((client) => (
                        <TableRow key={client.id} className="group">
                          <TableCell>
                            <div>
                              <button onClick={() => openClientProfile(client.id)} className="font-medium text-primary hover:underline text-left">
                                {client.contact_name || 'Unnamed'}
                              </button>
                              <p className="text-sm text-muted-foreground">{client.contact_email || '—'}</p>
                              <p className="text-xs text-muted-foreground">{client.phone || ''}</p>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <code className="px-2 py-1 bg-muted rounded text-sm font-mono">{client.login_username}</code>
                              <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => copyToClipboard(client.login_username, 'Username')}><Copy className="h-3.5 w-3.5" /></Button>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <code className="px-2 py-1 bg-muted rounded text-sm font-mono">{showPasswords[client.id] ? client.login_password : '••••••••'}</code>
                              <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => togglePasswordVisibility(client.id)}>
                                {showPasswords[client.id] ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                              </Button>
                              <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => copyToClipboard(client.login_password, 'Password')}><Copy className="h-3.5 w-3.5" /></Button>
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              {showBanButton && (
                                <Button size="sm" variant="ghost" onClick={() => handleBanToggle(client)}
                                  className={client.is_banned ? "text-primary hover:text-primary hover:bg-primary/10" : "text-warning hover:text-warning hover:bg-warning/10"}
                                  title={client.is_banned ? 'Unban' : 'Ban'}>
                                  <Ban className="w-4 h-4" />
                                </Button>
                              )}
                              <Button size="sm" variant="ghost" onClick={() => setDeleteUserId(client.id)} className="text-destructive hover:text-destructive hover:bg-destructive/10">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CollapsibleContent>
            </Collapsible>
          );
        })}
      </div>
    );
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-header">Clients</h1>
          <p className="page-subheader">Manage your client accounts and credentials</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setIsCSVOpen(true)}><Upload className="w-4 h-4 mr-2" />Import CSV</Button>
          <Button className="btn-primary-gradient" onClick={() => setIsAddOpen(true)}><Plus className="w-4 h-4 mr-2" />Add Client</Button>
        </div>
      </div>

      <div className="card-elevated p-6">
        <div className="flex items-center gap-4 mb-6">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search clients..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10" />
          </div>
          <div className="text-sm text-muted-foreground">
            {clients.length} users in {activeClients.length + bannedClients.length} companies
          </div>
        </div>

        {isLoading ? (
          <div className="py-12 text-center text-muted-foreground">Loading clients...</div>
        ) : (
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-4">
              <TabsTrigger value="active">
                Active ({activeClients.length})
              </TabsTrigger>
              <TabsTrigger value="fraud" className="flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                Fraud ({bannedClients.length})
              </TabsTrigger>
            </TabsList>
            <TabsContent value="active">
              {renderGroupList(activeClients, true)}
            </TabsContent>
            <TabsContent value="fraud">
              {renderGroupList(bannedClients, true)}
            </TabsContent>
          </Tabs>
        )}
      </div>

      <AddClientDialog open={isAddOpen} onOpenChange={setIsAddOpen} />
      <CSVUploadDialog open={isCSVOpen} onOpenChange={setIsCSVOpen} />

      {/* Add Representative Dialog */}
      <Dialog open={addRepDialog.open} onOpenChange={(open) => setAddRepDialog({ open, group: open ? addRepDialog.group : null })}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Add Representative to {addRepDialog.group?.companyName}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="grid grid-cols-2 gap-3">
              <div><label className="input-label">First Name *</label><Input placeholder="Ime" value={newRepForm.first_name} onChange={(e) => updateNewRepField('first_name', e.target.value)} /></div>
              <div><label className="input-label">Last Name *</label><Input placeholder="Prezime" value={newRepForm.last_name} onChange={(e) => updateNewRepField('last_name', e.target.value)} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="input-label">Email *</label><Input type="email" placeholder="Email" value={newRepForm.email} onChange={(e) => updateNewRepField('email', e.target.value)} /></div>
              <div><label className="input-label">Phone</label><Input placeholder="Phone" value={newRepForm.phone} onChange={(e) => updateNewRepField('phone', e.target.value)} /></div>
            </div>
            <div><label className="input-label">Work Title</label><Input placeholder="Work Title" value={newRepForm.work_title} onChange={(e) => updateNewRepField('work_title', e.target.value)} /></div>
            <div className="pt-2 border-t border-border">
              <p className="text-xs font-medium text-muted-foreground mb-2">Login Credentials</p>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="input-label">Username</label><Input value={newRepForm.login_username} onChange={(e) => setNewRepForm({ ...newRepForm, login_username: e.target.value })} className="font-mono text-sm" /></div>
                <div>
                  <label className="input-label">Password</label>
                  <div className="flex gap-1">
                    <Input value={newRepForm.login_password} onChange={(e) => setNewRepForm({ ...newRepForm, login_password: e.target.value })} className="font-mono text-sm" />
                    <Button type="button" variant="outline" size="icon" onClick={() => setNewRepForm({ ...newRepForm, login_password: generatePassword() })} title="Generate new password"><RefreshCw className="h-3 w-3" /></Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddRepDialog({ open: false, group: null })}>Cancel</Button>
            <Button className="btn-primary-gradient" onClick={handleAddRepresentative} disabled={addRepresentative.isPending || !newRepForm.email || (!newRepForm.first_name && !newRepForm.last_name)}>
              {addRepresentative.isPending ? 'Adding...' : 'Add Representative'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete User Confirmation */}
      <AlertDialog open={!!deleteUserId} onOpenChange={() => setDeleteUserId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete User</AlertDialogTitle>
            <AlertDialogDescription>Are you sure you want to delete this user? This will remove their login credentials and all their candidate assignments. This action cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => { if (deleteUserId) { deleteClient.mutate(deleteUserId); setDeleteUserId(null); } }} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete User</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Company Confirmation */}
      <AlertDialog open={!!deleteCompanyName} onOpenChange={() => setDeleteCompanyName(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Entire Company</AlertDialogTitle>
            <AlertDialogDescription>Are you sure you want to delete "{deleteCompanyName}" and ALL its users? This action cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => { if (deleteCompanyName) { deleteCompany.mutate(deleteCompanyName); setDeleteCompanyName(null); } }} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete Company</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Ban/Unban Confirmation */}
      <AlertDialog open={!!banClientData} onOpenChange={() => setBanClientData(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{banClientData?.is_banned ? 'Ban Client' : 'Unban Client'}</AlertDialogTitle>
            <AlertDialogDescription>
              {banClientData?.is_banned 
                ? 'This will mark the client as fraudulent. They will be flagged with a red warning indicator.'
                : 'This will remove the fraudulent status from this client.'}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmBan} className={banClientData?.is_banned ? "bg-destructive text-destructive-foreground hover:bg-destructive/90" : "bg-primary text-primary-foreground hover:bg-primary/90"}>
              {banClientData?.is_banned ? 'Ban Client' : 'Unban Client'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Clients;
