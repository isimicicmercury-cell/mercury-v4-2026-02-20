import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  usePipelineTemplates,
  usePipelineStages,
  useSavePipelineStages,
  PipelineStage,
} from '@/hooks/usePipelines';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { ArrowLeft, Plus, Trash2, ChevronUp, ChevronDown, Save, GripVertical } from 'lucide-react';

const STAGE_TYPES = ['claimed', 'test', 'interview', 'decision', 'other'];

type LocalStage = {
  name: string;
  stage_type: string;
  position: number;
  is_required: boolean;
  can_client_advance: boolean;
};

const PipelineBuilder = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { data: templates = [] } = usePipelineTemplates();
  const { data: existingStages = [] } = usePipelineStages(id || null);
  const saveStages = useSavePipelineStages();

  const template = templates.find((t) => t.id === id);
  const [stages, setStages] = useState<LocalStage[]>([]);
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    if (existingStages.length > 0) {
      setStages(existingStages.map((s) => ({
        name: s.name,
        stage_type: s.stage_type,
        position: s.position,
        is_required: s.is_required,
        can_client_advance: s.can_client_advance,
      })));
    }
  }, [existingStages]);

  const addStage = () => {
    setStages([...stages, {
      name: '',
      stage_type: 'other',
      position: stages.length + 1,
      is_required: true,
      can_client_advance: false,
    }]);
    setHasChanges(true);
  };

  const removeStage = (index: number) => {
    const updated = stages.filter((_, i) => i !== index).map((s, i) => ({ ...s, position: i + 1 }));
    setStages(updated);
    setHasChanges(true);
  };

  const moveStage = (index: number, direction: 'up' | 'down') => {
    if (direction === 'up' && index === 0) return;
    if (direction === 'down' && index === stages.length - 1) return;
    const swapIndex = direction === 'up' ? index - 1 : index + 1;
    const updated = [...stages];
    [updated[index], updated[swapIndex]] = [updated[swapIndex], updated[index]];
    setStages(updated.map((s, i) => ({ ...s, position: i + 1 })));
    setHasChanges(true);
  };

  const updateStage = (index: number, field: keyof LocalStage, value: any) => {
    const updated = [...stages];
    (updated[index] as any)[field] = value;
    setStages(updated);
    setHasChanges(true);
  };

  const handleSave = async () => {
    if (!id) return;
    await saveStages.mutateAsync({ templateId: id, stages });
    setHasChanges(false);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate('/pipelines')}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="page-header">{template?.name || 'Pipeline Builder'}</h1>
            <p className="page-subheader">Configure pipeline stages in order</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={addStage}>
            <Plus className="w-4 h-4 mr-2" />Add Stage
          </Button>
          <Button className="btn-primary-gradient" onClick={handleSave} disabled={saveStages.isPending || !hasChanges}>
            <Save className="w-4 h-4 mr-2" />{saveStages.isPending ? 'Saving...' : 'Save Stages'}
          </Button>
        </div>
      </div>

      {stages.length === 0 ? (
        <div className="card-elevated p-12 text-center">
          <p className="text-muted-foreground mb-4">No stages defined. Add stages to build your pipeline.</p>
          <Button variant="outline" onClick={addStage}><Plus className="w-4 h-4 mr-2" />Add First Stage</Button>
        </div>
      ) : (
        <div className="space-y-3">
          {stages.map((stage, index) => (
            <div key={index} className="card-elevated p-4">
              <div className="flex items-start gap-4">
                {/* Position indicator */}
                <div className="flex flex-col items-center gap-1 pt-2">
                  <div className="w-8 h-8 rounded-full bg-primary/10 text-primary text-sm font-bold flex items-center justify-center">
                    {index + 1}
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => moveStage(index, 'up')} disabled={index === 0}>
                      <ChevronUp className="w-4 h-4" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => moveStage(index, 'down')} disabled={index === stages.length - 1}>
                      <ChevronDown className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Stage fields */}
                <div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div>
                    <Label className="text-xs text-muted-foreground">Stage Name</Label>
                    <Input
                      value={stage.name}
                      onChange={(e) => updateStage(index, 'name', e.target.value)}
                      placeholder="e.g. Interview"
                    />
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Type</Label>
                    <Select value={stage.stage_type} onValueChange={(v) => updateStage(index, 'stage_type', v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {STAGE_TYPES.map((t) => (
                          <SelectItem key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-end gap-4">
                    <div className="flex items-center gap-2">
                      <Switch checked={stage.is_required} onCheckedChange={(v) => updateStage(index, 'is_required', v)} />
                      <Label className="text-xs">Required</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch checked={stage.can_client_advance} onCheckedChange={(v) => updateStage(index, 'can_client_advance', v)} />
                      <Label className="text-xs">Client can advance</Label>
                    </div>
                  </div>
                </div>

                <Button size="icon" variant="ghost" onClick={() => removeStage(index)} className="text-destructive hover:text-destructive hover:bg-destructive/10 mt-6">
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default PipelineBuilder;
