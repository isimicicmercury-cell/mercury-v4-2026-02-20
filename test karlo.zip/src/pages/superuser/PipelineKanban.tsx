import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  usePipelineTemplates,
  usePipelineKanban,
  useAdvanceCandidateStage,
} from '@/hooks/usePipelines';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { ArrowLeft, ArrowRight, GripVertical, User, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

const PipelineKanban = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { data: templates = [] } = usePipelineTemplates();
  const { data: kanbanData } = usePipelineKanban(id || null);
  const advanceStage = useAdvanceCandidateStage();

  const template = templates.find((t) => t.id === id);
  const stages = kanbanData?.stages || [];
  const candidates = kanbanData?.candidates || [];

  const getCandidatesForStage = (stageId: string) =>
    candidates.filter((c) => c.current_stage_id === stageId);

  const handleAdvance = async (candidateId: string) => {
    await advanceStage.mutateAsync({ candidateId });
  };

  // Color palette for stage headers
  const stageColors = [
    'from-blue-500/20 to-blue-500/5 border-blue-500/30',
    'from-violet-500/20 to-violet-500/5 border-violet-500/30',
    'from-amber-500/20 to-amber-500/5 border-amber-500/30',
    'from-emerald-500/20 to-emerald-500/5 border-emerald-500/30',
    'from-rose-500/20 to-rose-500/5 border-rose-500/30',
    'from-cyan-500/20 to-cyan-500/5 border-cyan-500/30',
  ];

  const stageDotColors = [
    'bg-blue-500', 'bg-violet-500', 'bg-amber-500',
    'bg-emerald-500', 'bg-rose-500', 'bg-cyan-500',
  ];

  return (
    <div className="space-y-6 animate-fade-in h-full">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate('/pipelines')} className="shrink-0">
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex-1 min-w-0">
          <h1 className="page-header truncate">{template?.name || 'Pipeline'}</h1>
          <p className="page-subheader">
            Kanban board — {candidates.length} candidate{candidates.length !== 1 ? 's' : ''} across {stages.length} stage{stages.length !== 1 ? 's' : ''}
          </p>
        </div>
      </div>

      {/* Kanban board */}
      <div className="flex gap-4 overflow-x-auto pb-4 -mx-4 px-4 md:-mx-8 md:px-8">
        {stages.map((stage, stageIndex) => {
          const stageCandidates = getCandidatesForStage(stage.id);
          const isLastStage = stageIndex === stages.length - 1;
          const colorClass = stageColors[stageIndex % stageColors.length];
          const dotColor = stageDotColors[stageIndex % stageDotColors.length];

          return (
            <div key={stage.id} className="min-w-[280px] max-w-[300px] flex-shrink-0 flex flex-col">
              {/* Column header */}
              <div className={`p-3 rounded-t-xl border border-b-0 bg-gradient-to-b ${colorClass}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${dotColor}`} />
                    <h3 className="text-sm font-semibold text-foreground">{stage.name}</h3>
                  </div>
                  <span className="text-xs font-medium text-muted-foreground bg-background/80 px-2 py-0.5 rounded-full">
                    {stageCandidates.length}
                  </span>
                </div>
                <div className="flex gap-2 mt-1.5">
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-background/50 text-muted-foreground font-medium">{stage.stage_type}</span>
                  {!stage.is_required && <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-600 dark:text-amber-400 font-medium">optional</span>}
                  {stage.can_client_advance && <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-600 dark:text-blue-400 font-medium">client</span>}
                </div>
              </div>

              {/* Column body */}
              <div className="flex-1 border border-border rounded-b-xl bg-muted/20 min-h-[200px] p-2 space-y-2">
                {stageCandidates.length === 0 ? (
                  <div className="flex items-center justify-center h-32 text-xs text-muted-foreground/40">
                    <p>No candidates</p>
                  </div>
                ) : (
                  stageCandidates.map((cp) => {
                    const c = cp.candidate;
                    const initials = c.full_name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || '?';
                    return (
                      <div
                        key={cp.id}
                        className="card-elevated p-3 space-y-2 cursor-default group"
                      >
                        <div className="flex items-center gap-2.5">
                          <Avatar className="h-8 w-8 shrink-0">
                            {c.profile_picture_url ? (
                              <AvatarImage src={c.profile_picture_url} alt={c.full_name} className="object-cover" />
                            ) : null}
                            <AvatarFallback className="text-[10px] bg-primary/10 text-primary font-semibold">{initials}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-foreground truncate">{c.full_name}</p>
                            <div className="flex items-center gap-2">
                              <code className="text-[10px] font-mono text-muted-foreground">{c.candidate_code}</code>
                              {c.skills && c.skills.length > 0 && (
                                <span className="text-[10px] text-muted-foreground/60 truncate">
                                  {c.skills[0]}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        {!isLastStage && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="w-full text-xs h-8 group-hover:border-primary/30 group-hover:text-primary transition-colors"
                            onClick={() => handleAdvance(cp.candidate_id)}
                            disabled={advanceStage.isPending}
                          >
                            <span className="truncate">Move to {stages[stageIndex + 1]?.name}</span>
                            <ChevronRight className="w-3.5 h-3.5 ml-1 shrink-0" />
                          </Button>
                        )}

                        {isLastStage && (
                          <div className="flex items-center justify-center py-1">
                            <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">Final Stage</span>
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          );
        })}

        {stages.length === 0 && (
          <div className="flex-1 flex items-center justify-center py-16">
            <div className="text-center">
              <div className="w-14 h-14 rounded-2xl bg-muted flex items-center justify-center mx-auto mb-4">
                <User className="w-7 h-7 text-muted-foreground" />
              </div>
              <h3 className="font-semibold text-foreground mb-1">No stages configured</h3>
              <p className="text-muted-foreground text-sm mb-4">Add stages to this pipeline to start tracking candidates.</p>
              <Button variant="outline" onClick={() => navigate(`/pipelines/${id}`)}>
                Configure Stages
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PipelineKanban;
