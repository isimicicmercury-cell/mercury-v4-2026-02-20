import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useClients, useUpdateClient, useUpdateClientCredentials, Client, Representative } from '@/hooks/useClients';
import { useCompanyAssignments, Assignment } from '@/hooks/useAssignments';
import ClientPipelineSelector from '@/components/pipeline/ClientPipelineSelector';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Plus, Trash2, Building2, Globe, MapPin, FileText, Users, Briefcase,
  Pencil, Save, X, ArrowLeft, Copy, Eye, EyeOff, Key, RefreshCw, UserCheck
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { generatePassword } from '@/lib/croatianUtils';
import { formatDate } from '@/lib/dateUtils';

const ClientProfile = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { data: clients = [], isLoading } = useClients();
  const updateClient = useUpdateClient();
  const updateCredentials = useUpdateClientCredentials();

  const [isEditing, setIsEditing] = useState(false);
  const [form, setForm] = useState<Partial<Client>>({});
  const [showPasswords, setShowPasswords] = useState<Record<string, boolean>>({});
  const [editingCredentials, setEditingCredentials] = useState<Record<string, { username: string; password: string }>>({});

  const client = clients.find(c => c.id === id);

  // Get all clients (representatives) for the same company
  const companyClients = client
    ? clients.filter(c => c.company_name === client.company_name)
    : [];

  // Use the first client created as the source of basic company info
  const primaryClient = companyClients.length > 0
    ? companyClients.reduce((oldest, c) => new Date(c.created_at) < new Date(oldest.created_at) ? c : oldest, companyClients[0])
    : client;

  const companyName = primaryClient?.company_name || client?.company_name || null;

  // Get candidates assigned to this company
  const { data: companyAssignments = [] } = useCompanyAssignments(companyName);

  useEffect(() => {
    if (client && !isEditing) {
      setForm({});
    }
  }, [client, isEditing]);

  const startEditing = () => {
    if (primaryClient) {
      setForm({
        company_name: primaryClient.company_name,
        contact_name: primaryClient.contact_name,
        contact_email: primaryClient.contact_email,
        phone: primaryClient.phone,
        notes: primaryClient.notes,
        founders_members: primaryClient.founders_members,
        representatives: primaryClient.representatives || [],
        website: primaryClient.website,
        tax_id: primaryClient.tax_id,
        country: primaryClient.country,
        state: primaryClient.state,
        city: primaryClient.city,
        postal_code: primaryClient.postal_code,
        address_line: primaryClient.address_line,
      });
      setIsEditing(true);
    }
  };

  const cancelEditing = () => {
    setIsEditing(false);
    setForm({});
  };

  const handleSave = async () => {
    if (!primaryClient) return;
    await updateClient.mutateAsync({ id: primaryClient.id, ...form });
    setIsEditing(false);
  };

  const addRepresentative = () => {
    const reps = (form.representatives || []) as Representative[];
    setForm({
      ...form,
      representatives: [...reps, { first_name: '', last_name: '', email: '', phone: '', work_title: '' }],
    });
  };

  const updateRepresentative = (index: number, field: keyof Representative, value: string) => {
    const reps = [...((form.representatives || []) as Representative[])];
    reps[index] = { ...reps[index], [field]: value };
    setForm({ ...form, representatives: reps });
  };

  const removeRepresentative = (index: number) => {
    const reps = [...((form.representatives || []) as Representative[])];
    reps.splice(index, 1);
    setForm({ ...form, representatives: reps });
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: 'Copied!', description: `${label} copied to clipboard.` });
  };

  const togglePassword = (id: string) => {
    setShowPasswords(prev => ({ ...prev, [id]: !prev[id] }));
  };

  // Credential editing
  const startEditingCredentials = (cc: Client) => {
    setEditingCredentials(prev => ({
      ...prev,
      [cc.id]: { username: cc.login_username, password: cc.login_password },
    }));
  };

  const cancelEditingCredentials = (clientId: string) => {
    setEditingCredentials(prev => {
      const next = { ...prev };
      delete next[clientId];
      return next;
    });
  };

  const handleSaveCredentials = async (clientId: string) => {
    const creds = editingCredentials[clientId];
    if (!creds) return;
    await updateCredentials.mutateAsync({
      clientId,
      login_username: creds.username,
      login_password: creds.password,
    });
    cancelEditingCredentials(clientId);
  };

  if (isLoading) {
    return <div className="py-12 text-center text-muted-foreground">Loading client...</div>;
  }

  if (!client) {
    return (
      <div className="py-12 text-center">
        <h3 className="font-semibold text-foreground mb-2">Client not found</h3>
        <p className="text-muted-foreground mb-4">The client you're looking for doesn't exist.</p>
        <Button variant="outline" onClick={() => navigate('/clients')}>
          <ArrowLeft className="w-4 h-4 mr-2" />Back to Clients
        </Button>
      </div>
    );
  }

  // Use primaryClient for display of basic info
  const displayData = isEditing ? form : primaryClient;
  const representatives = ((displayData?.representatives || []) as Representative[]);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate('/clients')}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="page-header flex items-center gap-2">
              <Building2 className="w-6 h-6" />{primaryClient?.company_name || client.company_name}
            </h1>
            <p className="page-subheader">Client profile and information</p>
          </div>
        </div>
        {!isEditing ? (
          <Button variant="outline" onClick={startEditing}>
            <Pencil className="w-4 h-4 mr-2" />Edit Profile
          </Button>
        ) : (
          <div className="flex gap-2">
            <Button variant="outline" onClick={cancelEditing}>
              <X className="w-4 h-4 mr-2" />Cancel
            </Button>
            <Button onClick={handleSave} disabled={updateClient.isPending} className="btn-primary-gradient">
              <Save className="w-4 h-4 mr-2" />{updateClient.isPending ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column */}
        <div className="space-y-6">
          {/* Basic Information */}
          <div className="card-elevated p-6">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 flex items-center gap-2">
              <Building2 className="w-4 h-4" />Basic Information
            </h3>
            <div className="space-y-4">
              {(primaryClient?.logo_url || (primaryClient as any)?.pending_logo_url) && (
                <div className="flex items-start gap-4 pb-4 border-b">
                  <div className="w-20 h-20 rounded-xl border-2 border-border bg-muted overflow-hidden">
                    <img src={primaryClient?.logo_url || ''} alt="Company logo" className="w-full h-full object-contain p-2" />
                  </div>
                  <div className="flex-1">
                    <label className="input-label">Company Logo</label>
                    {(primaryClient as any)?.pending_logo_url && (
                      <div className="mt-2 p-2 bg-amber-500/10 border border-amber-500/20 rounded-lg flex items-center gap-2">
                        <span className="text-xs text-amber-600 dark:text-amber-400 font-medium">Pending approval:</span>
                        <img src={(primaryClient as any).pending_logo_url} alt="Pending logo" className="w-8 h-8 object-contain rounded border" />
                      </div>
                    )}
                  </div>
                </div>
              )}
              <div>
                <label className="input-label">Company Name</label>
                {isEditing ? (
                  <Input value={form.company_name || ''} onChange={(e) => setForm({ ...form, company_name: e.target.value })} />
                ) : (
                  <p className="text-foreground font-medium">{primaryClient?.company_name}</p>
                )}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="input-label">Contact Name</label>
                  {isEditing ? (
                    <Input value={form.contact_name || ''} onChange={(e) => setForm({ ...form, contact_name: e.target.value })} />
                  ) : (
                    <p className="text-foreground">{primaryClient?.contact_name || '—'}</p>
                  )}
                </div>
                <div>
                  <label className="input-label">Contact Email</label>
                  {isEditing ? (
                    <Input type="email" value={form.contact_email || ''} onChange={(e) => setForm({ ...form, contact_email: e.target.value })} />
                  ) : (
                    <p className="text-foreground">{primaryClient?.contact_email || '—'}</p>
                  )}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="input-label">Phone</label>
                  {isEditing ? (
                    <Input value={form.phone || ''} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                  ) : (
                    <p className="text-foreground">{primaryClient?.phone || '—'}</p>
                  )}
                </div>
                <div>
                  <label className="input-label flex items-center gap-1"><Globe className="w-3 h-3" />Website</label>
                  {isEditing ? (
                    <Input value={form.website || ''} onChange={(e) => setForm({ ...form, website: e.target.value })} placeholder="https://example.com" />
                  ) : (
                    <p className="text-foreground">
                      {primaryClient?.website ? <a href={primaryClient.website} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">{primaryClient.website}</a> : '—'}
                    </p>
                  )}
                </div>
              </div>
              <div>
                <label className="input-label flex items-center gap-1"><FileText className="w-3 h-3" />Tax ID (OIB)</label>
                {isEditing ? (
                  <Input value={form.tax_id || ''} onChange={(e) => setForm({ ...form, tax_id: e.target.value })} />
                ) : (
                  <p className="text-foreground">{primaryClient?.tax_id || '—'}</p>
                )}
              </div>
            </div>
          </div>

          {/* Address */}
          <div className="card-elevated p-6">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 flex items-center gap-2">
              <MapPin className="w-4 h-4" />Address
            </h3>
            <div className="space-y-4">
              <div>
                <label className="input-label">Address Line</label>
                {isEditing ? <Input value={form.address_line || ''} onChange={(e) => setForm({ ...form, address_line: e.target.value })} /> : <p className="text-foreground">{primaryClient?.address_line || '—'}</p>}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="input-label">City</label>{isEditing ? <Input value={form.city || ''} onChange={(e) => setForm({ ...form, city: e.target.value })} /> : <p className="text-foreground">{primaryClient?.city || '—'}</p>}</div>
                <div><label className="input-label">Postal Code</label>{isEditing ? <Input value={form.postal_code || ''} onChange={(e) => setForm({ ...form, postal_code: e.target.value })} /> : <p className="text-foreground">{primaryClient?.postal_code || '—'}</p>}</div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="input-label">State</label>{isEditing ? <Input value={form.state || ''} onChange={(e) => setForm({ ...form, state: e.target.value })} /> : <p className="text-foreground">{primaryClient?.state || '—'}</p>}</div>
                <div><label className="input-label">Country</label>{isEditing ? <Input value={form.country || ''} onChange={(e) => setForm({ ...form, country: e.target.value })} /> : <p className="text-foreground">{primaryClient?.country || '—'}</p>}</div>
              </div>
            </div>
          </div>

          {/* Assigned Candidates (Superuser View) */}
          <div className="card-elevated p-6">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 flex items-center gap-2">
              <UserCheck className="w-4 h-4" />Assigned Candidates ({companyAssignments.length})
            </h3>
            {companyAssignments.length === 0 ? (
              <p className="text-sm text-muted-foreground">No candidates assigned to this company yet.</p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="table-header">Candidate</TableHead>
                      <TableHead className="table-header">Status</TableHead>
                      <TableHead className="table-header">Assigned</TableHead>
                      <TableHead className="table-header text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {companyAssignments.map((assignment) => {
                      const c = assignment.candidate;
                      const initials = c?.full_name?.split(' ').map((n: string) => n[0]).join('').toUpperCase().slice(0, 2) || '?';
                      return (
                        <TableRow key={assignment.id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <Avatar className="h-8 w-8 shrink-0">
                                {c?.profile_picture_url ? <AvatarImage src={c.profile_picture_url} alt={c?.full_name} className="object-cover" /> : null}
                                <AvatarFallback className="text-[10px] bg-primary/10 text-primary font-semibold">{initials}</AvatarFallback>
                              </Avatar>
                              <div>
                                <button onClick={() => navigate(`/candidates/${c?.id}`)} className="text-sm font-medium text-foreground hover:text-primary hover:underline">
                                  {c?.full_name || 'Unknown'}
                                </button>
                                {c?.candidate_code && <p className="text-xs text-muted-foreground font-mono">{c.candidate_code}</p>}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <span className={`status-badge text-[10px] ${
                              assignment.status === 'pending' ? 'status-pending' :
                              assignment.status === 'claimed' ? 'status-claimed' :
                              assignment.status === 'rejected' ? 'status-rejected' : 'status-available'
                            }`}>{assignment.status}</span>
                          </TableCell>
                          <TableCell className="text-xs text-muted-foreground">{formatDate(assignment.assigned_at)}</TableCell>
                          <TableCell className="text-right">
                            <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => navigate(`/candidates/${c?.id}`)}>
                              <Eye className="w-3.5 h-3.5 mr-1" />View
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </div>
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          {/* Founders/Members */}
          <div className="card-elevated p-6">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 flex items-center gap-2">
              <Users className="w-4 h-4" />Osnivaci / Clanovi
            </h3>
            {isEditing ? (
              <Textarea value={form.founders_members || ''} onChange={(e) => setForm({ ...form, founders_members: e.target.value })} placeholder="List founders and members..." rows={4} />
            ) : (
              <p className="text-foreground whitespace-pre-wrap">{primaryClient?.founders_members || '—'}</p>
            )}
          </div>

          {/* Zastupnici - All users with login credentials (editable) */}
          <div className="card-elevated p-6">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 flex items-center gap-2">
              <Key className="w-4 h-4" />Zastupnici ({companyClients.length})
            </h3>
            <div className="space-y-3">
              {companyClients.map((cc) => {
                const isEditingCreds = !!editingCredentials[cc.id];
                const creds = editingCredentials[cc.id];
                return (
                  <div key={cc.id} className="p-3 border border-border rounded-lg bg-muted/30">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <p className="text-sm font-medium text-foreground">{cc.contact_name || 'Unnamed'}</p>
                        {cc.contact_email && <p className="text-xs text-muted-foreground">{cc.contact_email}</p>}
                      </div>
                      {!isEditingCreds ? (
                        <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => startEditingCredentials(cc)}>
                          <Pencil className="w-3 h-3 mr-1" />Edit Login
                        </Button>
                      ) : (
                        <div className="flex gap-1">
                          <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => cancelEditingCredentials(cc.id)}>
                            <X className="w-3 h-3" />
                          </Button>
                          <Button size="sm" variant="default" className="h-7 text-xs btn-primary-gradient" onClick={() => handleSaveCredentials(cc.id)} disabled={updateCredentials.isPending}>
                            <Save className="w-3 h-3 mr-1" />Save
                          </Button>
                        </div>
                      )}
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs text-muted-foreground">Username</label>
                        {isEditingCreds ? (
                          <Input
                            value={creds.username}
                            onChange={(e) => setEditingCredentials(prev => ({ ...prev, [cc.id]: { ...prev[cc.id], username: e.target.value } }))}
                            className="font-mono text-xs h-8"
                          />
                        ) : (
                          <div className="flex items-center gap-1">
                            <code className="px-2 py-1 bg-muted rounded text-xs font-mono">{cc.login_username}</code>
                            <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => copyToClipboard(cc.login_username, 'Username')}>
                              <Copy className="h-3 w-3" />
                            </Button>
                          </div>
                        )}
                      </div>
                      <div>
                        <label className="text-xs text-muted-foreground">Password</label>
                        {isEditingCreds ? (
                          <div className="flex gap-1">
                            <Input
                              value={creds.password}
                              onChange={(e) => setEditingCredentials(prev => ({ ...prev, [cc.id]: { ...prev[cc.id], password: e.target.value } }))}
                              className="font-mono text-xs h-8"
                            />
                            <Button size="icon" variant="outline" className="h-8 w-8 shrink-0" onClick={() => setEditingCredentials(prev => ({ ...prev, [cc.id]: { ...prev[cc.id], password: generatePassword() } }))}>
                              <RefreshCw className="h-3 w-3" />
                            </Button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1">
                            <code className="px-2 py-1 bg-muted rounded text-xs font-mono">
                              {showPasswords[cc.id] ? cc.login_password : '••••••••'}
                            </code>
                            <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => togglePassword(cc.id)}>
                              {showPasswords[cc.id] ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                            </Button>
                            <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => copyToClipboard(cc.login_password, 'Password')}>
                              <Copy className="h-3 w-3" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Additional Representatives (from JSON) */}
          {representatives.length > 0 && (
            <div className="card-elevated p-6">
              <h3 className="text-sm font-semibold text-muted-foreground mb-4 flex items-center gap-2">
                <Briefcase className="w-4 h-4" />Additional Contacts
              </h3>
              <div className="space-y-3">
                {representatives.map((rep, index) => (
                  <div key={index} className="p-4 border border-border rounded-lg bg-muted/30">
                    {isEditing ? (
                      <div className="space-y-3">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-medium text-muted-foreground">Contact {index + 1}</span>
                          <Button type="button" variant="ghost" size="icon" className="h-6 w-6 text-destructive hover:text-destructive" onClick={() => removeRepresentative(index)}>
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <Input placeholder="First Name" value={rep.first_name || (rep as any).full_name || ''} onChange={(e) => updateRepresentative(index, 'first_name', e.target.value)} />
                          <Input placeholder="Last Name" value={rep.last_name || ''} onChange={(e) => updateRepresentative(index, 'last_name', e.target.value)} />
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <Input placeholder="Email" type="email" value={rep.email} onChange={(e) => updateRepresentative(index, 'email', e.target.value)} />
                          <Input placeholder="Phone" value={rep.phone} onChange={(e) => updateRepresentative(index, 'phone', e.target.value)} />
                        </div>
                        <Input placeholder="Work Title" value={rep.work_title} onChange={(e) => updateRepresentative(index, 'work_title', e.target.value)} />
                      </div>
                    ) : (
                      <div>
                        <p className="font-medium">{(rep.first_name || rep.last_name) ? `${rep.first_name || ''} ${rep.last_name || ''}`.trim() : (rep as any).full_name || '—'}</p>
                        <p className="text-sm text-muted-foreground">{rep.work_title || '—'}</p>
                        <div className="flex gap-4 mt-2 text-sm text-muted-foreground">
                          <span>{rep.email || '—'}</span>
                          <span>{rep.phone || '—'}</span>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
                {isEditing && (
                  <Button type="button" variant="outline" size="sm" onClick={addRepresentative} className="w-full">
                    <Plus className="w-4 h-4 mr-2" />Add Contact
                  </Button>
                )}
              </div>
            </div>
          )}

          {/* Pipeline Assignment */}
          <ClientPipelineSelector clientId={client.id} />

          {/* Notes */}
          <div className="card-elevated p-6">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4">Notes</h3>
            {isEditing ? (
              <Textarea value={form.notes || ''} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Internal notes..." rows={4} />
            ) : (
              <p className="text-foreground whitespace-pre-wrap">{primaryClient?.notes || '—'}</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ClientProfile;
