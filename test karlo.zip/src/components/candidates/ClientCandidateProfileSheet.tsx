import { Candidate } from '@/hooks/useCandidates';
import { Label } from '@/components/ui/label';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { format } from 'date-fns';
import { CandidateDocumentUploader } from './CandidateDocumentUploader';
import { Lock } from 'lucide-react';
import CandidatePipelineView from '@/components/pipeline/CandidatePipelineView';

interface GsmEntry {
  type: string;
  number: string;
}

interface ClientCandidateProfileSheetProps {
  candidate: Candidate | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  isHired?: boolean;
}

const ClientCandidateProfileSheet = ({
  candidate,
  open,
  onOpenChange,
  isHired = false,
}: ClientCandidateProfileSheetProps) => {
  if (!candidate) return null;

  const gsmEntries: GsmEntry[] = Array.isArray(candidate.gsm) ? candidate.gsm : [];

  const fmtDate = (dateStr: string | null | undefined) => {
    if (!dateStr) return null;
    try { return format(new Date(dateStr), 'dd.MM.yyyy'); } catch { return null; }
  };

  const DisplayField = ({ label, value }: { label: string; value: string | null | undefined }) => (
    <div className="space-y-1">
      <Label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</Label>
      <p className="text-sm font-medium text-foreground py-1">{value || <span className="text-muted-foreground/50">—</span>}</p>
    </div>
  );

  const SectionHeader = ({ title }: { title: string }) => (
    <div className="border-b border-border pb-2 mb-4">
      <h3 className="text-sm font-semibold text-foreground uppercase tracking-wider">{title}</h3>
    </div>
  );

  const initials = candidate.full_name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="sm:max-w-2xl w-full">
        <SheetHeader className="pb-4">
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16 border-2 border-border">
              {candidate.profile_picture_url ? (
                <AvatarImage src={candidate.profile_picture_url} alt={candidate.full_name} className="object-cover" />
              ) : null}
              <AvatarFallback className="text-lg font-bold bg-primary/10 text-primary">{initials}</AvatarFallback>
            </Avatar>
            <div>
              <SheetTitle>{candidate.full_name}</SheetTitle>
              <div className="flex items-center gap-2 mt-1">
                <span className={`status-badge w-fit ${candidate.status === 'available' ? 'status-available' : candidate.status === 'claimed' ? 'status-claimed' : 'status-pending'}`}>
                  {candidate.status}
                </span>
                <span className="text-xs font-mono text-muted-foreground bg-muted px-2 py-0.5 rounded">ID: {candidate.candidate_code}</span>
              </div>
            </div>
          </div>
        </SheetHeader>

        <ScrollArea className="h-[calc(100vh-140px)] pr-4">
          <Tabs defaultValue="personal" className="w-full">
            <TabsList className={`grid w-full mb-4 ${isHired ? 'grid-cols-5' : 'grid-cols-3'}`}>
              <TabsTrigger value="personal">Personal</TabsTrigger>
              {isHired && <TabsTrigger value="pipeline">Pipeline</TabsTrigger>}
              <TabsTrigger value="documents">Documents</TabsTrigger>
              <TabsTrigger value="residence">Residence</TabsTrigger>
              {isHired && <TabsTrigger value="medical">Medical</TabsTrigger>}
            </TabsList>

            <TabsContent value="personal" className="space-y-6">
              <SectionHeader title="Identity" />
              <div className="grid grid-cols-2 gap-x-6 gap-y-3">
                <DisplayField label="Prezime (Surname)" value={candidate.prezime} />
                <DisplayField label="Ime (First Name)" value={candidate.ime} />
                <DisplayField label="Full Name" value={candidate.full_name} />
                <DisplayField label="Email" value={candidate.email} />
                <DisplayField label="Mjesto i država rođenja" value={candidate.mjesto_i_drzava_rodenja} />
                <DisplayField label="Datum rođenja" value={fmtDate(candidate.datum_rodenja)} />
                <DisplayField label="Državljanstvo" value={candidate.drzavljanstvo} />
              </div>
              {/* OIB, IBAN intentionally hidden from client view — sensitive financial data */}

              <SectionHeader title="Professional" />
              <div className="grid grid-cols-2 gap-x-6 gap-y-3">
                <DisplayField label="Zanimanje" value={candidate.zanimanje} />
                <DisplayField label="Školska sprema" value={candidate.skolska_sprema} />
                <DisplayField label="Radno mjesto" value={candidate.radno_mjesto} />
                <DisplayField label="Years of Experience" value={candidate.experience_years?.toString()} />
              </div>

              <SectionHeader title="Contact" />
              <div>
                <Label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">GSM / Contacts</Label>
                <div className="space-y-1 py-2">
                  {gsmEntries.length > 0 ? (
                    gsmEntries.map((entry, index) => (
                      <p key={index} className="text-sm font-medium">
                        <span className="text-muted-foreground text-xs uppercase mr-2">{entry.type}:</span>{entry.number}
                      </p>
                    ))
                  ) : (<p className="text-sm text-muted-foreground/50">—</p>)}
                </div>
              </div>
              <DisplayField label="Phone" value={candidate.phone} />
            </TabsContent>

            {isHired && (
              <TabsContent value="pipeline" className="space-y-6">
                <CandidatePipelineView candidateId={candidate.id} />
              </TabsContent>
            )}

            <TabsContent value="documents" className="space-y-6">
              <div className="mb-6">
                <h4 className="text-sm font-semibold text-muted-foreground mb-3">Uploaded Files</h4>
                <CandidateDocumentUploader candidateId={candidate.id} readOnly />
              </div>
            </TabsContent>

            <TabsContent value="residence" className="space-y-6">
              <SectionHeader title="Entry & Residence" />
              <div className="grid grid-cols-2 gap-x-6 gap-y-3">
                <DisplayField label="Datum i mjesto ulaska u RH" value={candidate.datum_i_mjesto_ulaska_u_rh} />
                <DisplayField label="Rok odobrenja boravka" value={fmtDate(candidate.rok_odobrenja_boravka)} />
              </div>

              <SectionHeader title="Accommodation" />
              <div className="grid grid-cols-2 gap-x-6 gap-y-3">
                <DisplayField label="Novi smještaj / Boravište" value={candidate.novi_smjestaj_boraviste} />
                <DisplayField label="Prethodni smještaj" value={candidate.prethodni_smjestaj} />
              </div>
            </TabsContent>

            {isHired && (
              <TabsContent value="medical" className="space-y-6">
                <SectionHeader title="Medical Appointments" />
                <div className="grid grid-cols-2 gap-x-6 gap-y-3">
                  <DisplayField label="Termin liječničkog" value={candidate.termin_lijecnickog} />
                  <DisplayField label="Ordinacija opće medicine" value={candidate.ordinacija_opce_medicine} />
                  <DisplayField label="Ginekolog" value={candidate.ginekolog} />
                  <DisplayField label="Zubar" value={candidate.zubar} />
                </div>
                <SectionHeader title="Therapy & Notes" />
                <div>
                  <Label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Terapija / Komentar</Label>
                  <p className="text-sm font-medium text-foreground py-1.5 whitespace-pre-wrap">{candidate.terapija_komentar || <span className="text-muted-foreground/50">—</span>}</p>
                </div>
              </TabsContent>
            )}

            {!isHired && (
              <div className="mt-4">
                <Alert>
                  <Lock className="h-4 w-4" />
                  <AlertDescription>
                    Medical records will be available after you hire this candidate.
                  </AlertDescription>
                </Alert>
              </div>
            )}
          </Tabs>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
};

export default ClientCandidateProfileSheet;
