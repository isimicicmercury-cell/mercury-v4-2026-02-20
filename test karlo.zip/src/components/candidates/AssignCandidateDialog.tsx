import { useState, useMemo } from 'react';
import { useClients } from '@/hooks/useClients';
import { useAssignCandidate } from '@/hooks/useAssignments';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';

interface AssignCandidateDialogProps {
  candidateId: string | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const AssignCandidateDialog = ({
  candidateId,
  open,
  onOpenChange,
}: AssignCandidateDialogProps) => {
  const { data: clients = [] } = useClients();
  const assignCandidate = useAssignCandidate();
  const [selectedCompanies, setSelectedCompanies] = useState<string[]>([]);

  // Group clients by company - pick one client ID per company for assignment
  const companies = useMemo(() => {
    const map = new Map<string, { companyName: string; clientIds: string[]; contactName: string | null }>();
    clients.forEach((client) => {
      if (!map.has(client.company_name)) {
        map.set(client.company_name, {
          companyName: client.company_name,
          clientIds: [],
          contactName: client.contact_name,
        });
      }
      map.get(client.company_name)!.clientIds.push(client.id);
    });
    return Array.from(map.values());
  }, [clients]);

  const handleToggleCompany = (companyName: string) => {
    setSelectedCompanies((prev) =>
      prev.includes(companyName)
        ? prev.filter((name) => name !== companyName)
        : [...prev, companyName]
    );
  };

  const handleAssign = async () => {
    if (!candidateId || selectedCompanies.length === 0) return;

    // Get all client IDs for selected companies
    const allClientIds: string[] = [];
    selectedCompanies.forEach((companyName) => {
      const company = companies.find((c) => c.companyName === companyName);
      if (company) {
        // Assign to ALL client records of the company so all reps can see
        allClientIds.push(...company.clientIds);
      }
    });

    await assignCandidate.mutateAsync({
      candidateId,
      clientIds: allClientIds,
    });

    setSelectedCompanies([]);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Assign Candidate to Companies</DialogTitle>
        </DialogHeader>
        <div className="py-4">
          <p className="text-sm text-muted-foreground mb-4">
            Select the companies who should review this candidate:
          </p>
          <div className="space-y-3 max-h-64 overflow-y-auto">
            {companies.map((company) => (
              <label
                key={company.companyName}
                className="flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-muted/50 cursor-pointer transition-colors"
              >
                <Checkbox
                  checked={selectedCompanies.includes(company.companyName)}
                  onCheckedChange={() => handleToggleCompany(company.companyName)}
                />
                <div className="flex-1">
                  <p className="font-medium text-foreground">{company.companyName}</p>
                  <p className="text-sm text-muted-foreground">
                    {company.clientIds.length} {company.clientIds.length === 1 ? 'representative' : 'representatives'}
                  </p>
                </div>
              </label>
            ))}
            {companies.length === 0 && (
              <p className="text-center text-muted-foreground py-4">
                No clients available. Create a client first.
              </p>
            )}
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            className="btn-primary-gradient"
            onClick={handleAssign}
            disabled={selectedCompanies.length === 0 || assignCandidate.isPending}
          >
            {assignCandidate.isPending ? 'Assigning...' : `Assign to ${selectedCompanies.length} Company(ies)`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AssignCandidateDialog;
