import { useState, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useUpdateCandidate } from '@/hooks/useCandidates';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Camera, Upload, X } from 'lucide-react';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';

const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
const MAX_SIZE = 5 * 1024 * 1024; // 5MB

interface CandidatePhotoUploaderProps {
  candidateId: string;
  candidateCode: string;
  currentPhotoUrl: string | null;
  candidateName: string;
  readOnly?: boolean;
}

export const CandidatePhotoUploader = ({
  candidateId,
  candidateCode,
  currentPhotoUrl,
  candidateName,
  readOnly = false,
}: CandidatePhotoUploaderProps) => {
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const updateCandidate = useUpdateCandidate();
  const { toast } = useToast();

  const handleUpload = async (file: File) => {
    if (!ALLOWED_TYPES.includes(file.type)) {
      toast({ title: 'Invalid file type', description: 'Please upload a JPG, PNG, WebP, or GIF image.', variant: 'destructive' });
      return;
    }
    if (file.size > MAX_SIZE) {
      toast({ title: 'File too large', description: 'Maximum file size is 5MB.', variant: 'destructive' });
      return;
    }

    setIsUploading(true);
    try {
      const ext = file.name.split('.').pop()?.toLowerCase() || 'jpg';
      const filePath = `${candidateId}/profile.${ext}`;

      // Delete old photo if exists
      if (currentPhotoUrl) {
        const oldPath = currentPhotoUrl.split('/candidate-photos/')[1];
        if (oldPath) {
          await supabase.storage.from('candidate-photos').remove([oldPath]);
        }
      }

      const { error: uploadError } = await supabase.storage
        .from('candidate-photos')
        .upload(filePath, file, { upsert: true });

      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage
        .from('candidate-photos')
        .getPublicUrl(filePath);

      await updateCandidate.mutateAsync({
        id: candidateId,
        profile_picture_url: urlData.publicUrl,
      });

      toast({ title: 'Photo uploaded', description: 'Profile picture has been updated.' });
    } catch (error) {
      toast({ title: 'Upload failed', description: error instanceof Error ? error.message : 'Unknown error', variant: 'destructive' });
    } finally {
      setIsUploading(false);
    }
  };

  const handleRemove = async () => {
    if (!currentPhotoUrl) return;
    setIsUploading(true);
    try {
      const oldPath = currentPhotoUrl.split('/candidate-photos/')[1];
      if (oldPath) {
        await supabase.storage.from('candidate-photos').remove([oldPath]);
      }
      await updateCandidate.mutateAsync({ id: candidateId, profile_picture_url: null });
      toast({ title: 'Photo removed' });
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to remove photo.', variant: 'destructive' });
    } finally {
      setIsUploading(false);
    }
  };

  const initials = candidateName
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  return (
    <div className="flex flex-col items-center gap-3">
      <Avatar className="h-28 w-28 border-4 border-border shadow-lg">
        {currentPhotoUrl ? (
          <AvatarImage src={currentPhotoUrl} alt={candidateName} className="object-cover" />
        ) : null}
        <AvatarFallback className="text-2xl font-bold bg-primary/10 text-primary">
          {initials}
        </AvatarFallback>
      </Avatar>

      {!readOnly && (
        <div className="flex items-center gap-2">
          <input
            ref={fileInputRef}
            type="file"
            accept={ALLOWED_TYPES.join(',')}
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) handleUpload(file);
              e.target.value = '';
            }}
          />
          <Button
            variant="outline"
            size="sm"
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploading}
          >
            <Camera className="w-4 h-4 mr-1" />
            {isUploading ? 'Uploading...' : currentPhotoUrl ? 'Change' : 'Add Photo'}
          </Button>
          {currentPhotoUrl && (
            <Button variant="ghost" size="sm" onClick={handleRemove} disabled={isUploading} className="text-destructive hover:text-destructive">
              <X className="w-4 h-4" />
            </Button>
          )}
        </div>
      )}

      <p className="text-xs font-mono text-muted-foreground bg-muted px-2 py-1 rounded">
        ID: {candidateCode}
      </p>
    </div>
  );
};
