import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import {
  useCandidateDocuments,
  useUploadCandidateDocument,
  useDeleteCandidateDocument,
  getDocumentDownloadUrl,
  CandidateDocument,
} from '@/hooks/useCandidateDocuments';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Upload, FileText, Trash2, Download, Loader2, Eye, Archive } from 'lucide-react';
import { format } from 'date-fns';
import JSZip from 'jszip';

interface CandidateDocumentUploaderProps {
  candidateId: string;
  readOnly?: boolean;
}

const formatFileSize = (bytes: number | null): string => {
  if (!bytes) return 'Unknown size';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};

const isPreviewable = (fileType: string | null): boolean => {
  if (!fileType) return false;
  return fileType.startsWith('image/') || fileType === 'application/pdf';
};

export const CandidateDocumentUploader = ({ candidateId, readOnly = false }: CandidateDocumentUploaderProps) => {
  const { data: documents = [], isLoading } = useCandidateDocuments(candidateId);
  const uploadDocument = useUploadCandidateDocument();
  const deleteDocument = useDeleteCandidateDocument();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [selectedDocs, setSelectedDocs] = useState<Set<string>>(new Set());
  const [previewDoc, setPreviewDoc] = useState<{ url: string; name: string; type: string } | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [downloadingZip, setDownloadingZip] = useState(false);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      return;
    }

    await uploadDocument.mutateAsync({ candidateId, file });
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleDownload = async (doc: CandidateDocument) => {
    setDownloadingId(doc.id);
    try {
      const url = await getDocumentDownloadUrl(doc.file_path);
      if (url) {
        const link = document.createElement('a');
        link.href = url;
        link.download = doc.file_name;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    } finally {
      setDownloadingId(null);
    }
  };

  const handlePreview = async (doc: CandidateDocument) => {
    setPreviewLoading(true);
    try {
      const url = await getDocumentDownloadUrl(doc.file_path);
      if (url) {
        setPreviewDoc({ url, name: doc.file_name, type: doc.file_type || '' });
      }
    } finally {
      setPreviewLoading(false);
    }
  };

  const handleDelete = async (doc: CandidateDocument) => {
    await deleteDocument.mutateAsync({
      documentId: doc.id,
      filePath: doc.file_path,
      candidateId,
    });
    // Remove from selection if deleted
    setSelectedDocs(prev => {
      const next = new Set(prev);
      next.delete(doc.id);
      return next;
    });
  };

  const toggleSelection = (docId: string) => {
    setSelectedDocs(prev => {
      const next = new Set(prev);
      if (next.has(docId)) {
        next.delete(docId);
      } else {
        next.add(docId);
      }
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedDocs.size === documents.length) {
      setSelectedDocs(new Set());
    } else {
      setSelectedDocs(new Set(documents.map(d => d.id)));
    }
  };

  const downloadSelected = async () => {
    const docsToDownload = documents.filter(d => selectedDocs.has(d.id));
    if (docsToDownload.length === 0) return;

    if (docsToDownload.length === 1) {
      await handleDownload(docsToDownload[0]);
      return;
    }

    setDownloadingZip(true);
    try {
      const zip = new JSZip();
      for (const doc of docsToDownload) {
        const url = await getDocumentDownloadUrl(doc.file_path);
        if (url) {
          const response = await fetch(url);
          const blob = await response.blob();
          zip.file(doc.file_name, blob);
        }
      }
      const content = await zip.generateAsync({ type: 'blob' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(content);
      link.download = `documents-${Date.now()}.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(link.href);
    } finally {
      setDownloadingZip(false);
    }
  };

  const downloadAll = async () => {
    if (documents.length === 0) return;
    setDownloadingZip(true);
    try {
      const zip = new JSZip();
      for (const doc of documents) {
        const url = await getDocumentDownloadUrl(doc.file_path);
        if (url) {
          const response = await fetch(url);
          const blob = await response.blob();
          zip.file(doc.file_name, blob);
        }
      }
      const content = await zip.generateAsync({ type: 'blob' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(content);
      link.download = `all-documents-${Date.now()}.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(link.href);
    } finally {
      setDownloadingZip(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Upload and Actions Bar */}
      <div className="flex items-center gap-2 flex-wrap">
        {!readOnly && (
          <>
            <Button
              variant="outline"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              disabled={uploadDocument.isPending}
            >
              {uploadDocument.isPending ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Upload className="w-4 h-4 mr-2" />
              )}
              Upload Document
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              onChange={handleFileSelect}
              className="hidden"
              accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.txt"
            />
          </>
        )}
        
        {documents.length > 0 && (
          <>
            <Button
              variant="outline"
              size="sm"
              onClick={downloadAll}
              disabled={downloadingZip}
            >
              {downloadingZip ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Archive className="w-4 h-4 mr-2" />
              )}
              Download All
            </Button>
            
            {selectedDocs.size > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={downloadSelected}
                disabled={downloadingZip}
              >
                <Download className="w-4 h-4 mr-2" />
                Download Selected ({selectedDocs.size})
              </Button>
            )}
          </>
        )}
      </div>

      {/* Documents List */}
      {isLoading ? (
        <div className="text-sm text-muted-foreground">Loading documents...</div>
      ) : documents.length === 0 ? (
        <div className="text-sm text-muted-foreground py-4 text-center border border-dashed rounded-lg">
          No documents uploaded yet
        </div>
      ) : (
        <div className="space-y-2">
          {/* Select All */}
          <div className="flex items-center gap-2 p-2 border-b">
            <Checkbox
              checked={selectedDocs.size === documents.length}
              onCheckedChange={toggleSelectAll}
            />
            <span className="text-sm text-muted-foreground">
              Select all ({documents.length} files)
            </span>
          </div>
          
          {documents.map((doc) => (
            <div
              key={doc.id}
              className="flex items-center justify-between p-3 bg-muted/30 border rounded-lg"
            >
              <div className="flex items-center gap-3 min-w-0 flex-1">
                <Checkbox
                  checked={selectedDocs.has(doc.id)}
                  onCheckedChange={() => toggleSelection(doc.id)}
                />
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                  <FileText className="w-5 h-5 text-primary" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium truncate">{doc.file_name}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatFileSize(doc.file_size)} • {format(new Date(doc.uploaded_at), 'dd.MM.yyyy')}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                {isPreviewable(doc.file_type) && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => handlePreview(doc)}
                    disabled={previewLoading}
                    title="Preview"
                  >
                    <Eye className="w-4 h-4" />
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => handleDownload(doc)}
                  disabled={downloadingId === doc.id}
                  title="Download"
                >
                  {downloadingId === doc.id ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Download className="w-4 h-4" />
                  )}
                </Button>
                {!readOnly && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-destructive hover:text-destructive"
                    onClick={() => handleDelete(doc)}
                    disabled={deleteDocument.isPending}
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Preview Dialog */}
      <Dialog open={!!previewDoc} onOpenChange={(open) => !open && setPreviewDoc(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>{previewDoc?.name}</DialogTitle>
          </DialogHeader>
          <div className="flex-1 overflow-auto">
            {previewDoc?.type.startsWith('image/') ? (
              <img
                src={previewDoc.url}
                alt={previewDoc.name}
                className="max-w-full h-auto mx-auto"
              />
            ) : previewDoc?.type === 'application/pdf' ? (
              <iframe
                src={previewDoc.url}
                className="w-full h-[70vh]"
                title={previewDoc.name}
              />
            ) : null}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CandidateDocumentUploader;
