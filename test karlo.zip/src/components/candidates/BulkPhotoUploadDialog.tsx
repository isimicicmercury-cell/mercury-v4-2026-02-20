import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useCandidates, useUpdateCandidate } from '@/hooks/useCandidates';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';
import { Upload, Check, X, AlertCircle, ImageIcon } from 'lucide-react';

const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
const MAX_SIZE = 5 * 1024 * 1024; // 5MB

interface UploadResult {
  fileName: string;
  candidateCode: string;
  status: 'pending' | 'success' | 'error';
  error?: string;
}

interface BulkPhotoUploadDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const BulkPhotoUploadDialog = ({ open, onOpenChange }: BulkPhotoUploadDialogProps) => {
  const { data: candidates = [] } = useCandidates();
  const updateCandidate = useUpdateCandidate();
  const { toast } = useToast();
  const [files, setFiles] = useState<File[]>([]);
  const [results, setResults] = useState<UploadResult[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadComplete, setUploadComplete] = useState(false);

  const validateAndSetFiles = (selectedFiles: FileList | null) => {
    if (!selectedFiles) return;
    
    const fileArray = Array.from(selectedFiles);
    const validatedResults: UploadResult[] = [];
    const validFiles: File[] = [];

    for (const file of fileArray) {
      const nameWithoutExt = file.name.replace(/\.[^.]+$/, '').toUpperCase();
      
      if (!ALLOWED_TYPES.includes(file.type)) {
        validatedResults.push({ fileName: file.name, candidateCode: nameWithoutExt, status: 'error', error: 'Invalid file type. Use JPG, PNG, WebP, or GIF.' });
        continue;
      }

      if (file.size > MAX_SIZE) {
        validatedResults.push({ fileName: file.name, candidateCode: nameWithoutExt, status: 'error', error: 'File exceeds 5MB limit.' });
        continue;
      }

      // Check if candidate code matches any candidate
      const matched = candidates.find(c => c.candidate_code === nameWithoutExt);
      if (!matched) {
        validatedResults.push({ fileName: file.name, candidateCode: nameWithoutExt, status: 'error', error: `No candidate found with ID "${nameWithoutExt}".` });
        continue;
      }

      validatedResults.push({ fileName: file.name, candidateCode: nameWithoutExt, status: 'pending' });
      validFiles.push(file);
    }

    setResults(validatedResults);
    setFiles(validFiles);
    setUploadComplete(false);
  };

  const handleUpload = async () => {
    if (files.length === 0) return;
    setIsProcessing(true);

    const updatedResults = [...results];

    for (let i = 0; i < updatedResults.length; i++) {
      if (updatedResults[i].status !== 'pending') continue;

      const result = updatedResults[i];
      const file = files.find(f => f.name.replace(/\.[^.]+$/, '').toUpperCase() === result.candidateCode);
      if (!file) continue;

      const candidate = candidates.find(c => c.candidate_code === result.candidateCode);
      if (!candidate) continue;

      try {
        const ext = file.name.split('.').pop()?.toLowerCase() || 'jpg';
        const filePath = `${candidate.id}/profile.${ext}`;

        // Delete old photo if exists
        if (candidate.profile_picture_url) {
          const oldPath = candidate.profile_picture_url.split('/candidate-photos/')[1];
          if (oldPath) {
            await supabase.storage.from('candidate-photos').remove([oldPath]);
          }
        }

        const { error: uploadError } = await supabase.storage
          .from('candidate-photos')
          .upload(filePath, file, { upsert: true });

        if (uploadError) throw uploadError;

        const { data: urlData } = supabase.storage
          .from('candidate-photos')
          .getPublicUrl(filePath);

        await updateCandidate.mutateAsync({
          id: candidate.id,
          profile_picture_url: urlData.publicUrl,
        });

        updatedResults[i].status = 'success';
      } catch (error) {
        updatedResults[i].status = 'error';
        updatedResults[i].error = error instanceof Error ? error.message : 'Upload failed';
      }

      setResults([...updatedResults]);
    }

    setIsProcessing(false);
    setUploadComplete(true);

    const successCount = updatedResults.filter(r => r.status === 'success').length;
    const errorCount = updatedResults.filter(r => r.status === 'error').length;

    toast({
      title: 'Bulk Upload Complete',
      description: `${successCount} photos uploaded${errorCount > 0 ? `, ${errorCount} failed` : ''}.`,
      variant: errorCount > 0 ? 'destructive' : 'default',
    });
  };

  const reset = () => {
    setFiles([]);
    setResults([]);
    setUploadComplete(false);
  };

  const pendingCount = results.filter(r => r.status === 'pending').length;

  return (
    <Dialog open={open} onOpenChange={(v) => { onOpenChange(v); if (!v) reset(); }}>
      <DialogContent className="sm:max-w-lg max-h-[80vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ImageIcon className="w-5 h-5" />
            Bulk Upload Profile Photos
          </DialogTitle>
          <DialogDescription>
            Upload multiple candidate photos at once. File names must match candidate IDs (e.g. AZGE25.jpg).
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {results.length === 0 ? (
            <div className="border-2 border-dashed border-border rounded-xl p-8 text-center">
              <ImageIcon className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-sm text-muted-foreground mb-2">
                Select photos to upload. Each file name must be the candidate's unique ID.
              </p>
              <p className="text-xs text-muted-foreground mb-4">
                Supported: JPG, PNG, WebP, GIF (max 5MB each)
              </p>
              <input
                type="file"
                accept={ALLOWED_TYPES.join(',')}
                multiple
                onChange={(e) => validateAndSetFiles(e.target.files)}
                className="max-w-xs mx-auto"
              />
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <span className="text-sm font-medium">
                  {results.length} files selected ({pendingCount} ready, {results.filter(r => r.status === 'error').length} errors)
                </span>
                <Button variant="ghost" size="sm" onClick={reset}>Change files</Button>
              </div>

              <ScrollArea className="h-48 border rounded-lg">
                <div className="p-3 space-y-2">
                  {results.map((result, index) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-muted/50 rounded-md">
                      <div className="flex items-center gap-2">
                        {result.status === 'pending' && <div className="w-4 h-4 rounded-full bg-muted-foreground/30" />}
                        {result.status === 'success' && <Check className="w-4 h-4 text-green-500" />}
                        {result.status === 'error' && <X className="w-4 h-4 text-destructive" />}
                        <div>
                          <span className="text-sm font-medium">{result.fileName}</span>
                          <span className="text-xs text-muted-foreground ml-2">→ {result.candidateCode}</span>
                        </div>
                      </div>
                      {result.error && <span className="text-xs text-destructive max-w-[200px] truncate">{result.error}</span>}
                    </div>
                  ))}
                </div>
              </ScrollArea>

              <div className="flex items-start gap-2 p-3 bg-accent/10 rounded-lg">
                <AlertCircle className="w-4 h-4 text-accent mt-0.5 shrink-0" />
                <p className="text-xs text-muted-foreground">
                  File name format: <code className="px-1 py-0.5 bg-muted rounded">CANDIDATEID.jpg</code> (e.g., AZGE25.jpg, KOUU99.png)
                </p>
              </div>

              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => onOpenChange(false)}>
                  {uploadComplete ? 'Close' : 'Cancel'}
                </Button>
                {!uploadComplete && pendingCount > 0 && (
                  <Button className="btn-primary-gradient" onClick={handleUpload} disabled={isProcessing}>
                    {isProcessing ? 'Uploading...' : `Upload ${pendingCount} Photos`}
                  </Button>
                )}
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
