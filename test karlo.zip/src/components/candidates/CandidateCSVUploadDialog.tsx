import { useState } from 'react';
import { useCreateCandidate } from '@/hooks/useCandidates';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Upload, FileText, Check, X, AlertCircle, Download } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CandidateCSVUploadDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface ParsedCandidate {
  full_name: string;
  prezime?: string;
  ime?: string;
  email?: string;
  phone?: string;
  prijava_drb?: string;
  viza_d_form_ref_no?: string;
  viza_d_status?: string;
  plane_ticket?: string;
  mjesto_i_drzava_rodenja?: string;
  datum_rodenja?: string;
  drzavljanstvo?: string;
  vrsta_i_broj_putovnice?: string;
  mjesto_izdavanja_putovnice?: string;
  vrijedi_od_do?: string;
  vrsta_i_broj_vize_mjesto_izdavanja?: string;
  rok_vazenja_vize?: string;
  datum_i_mjesto_ulaska_u_rh?: string;
  rok_odobrenja_boravka?: string;
  novi_smjestaj_boraviste?: string;
  prethodni_smjestaj?: string;
  datum_prijave_16a?: string;
  datum_odjave_16a?: string;
  oib?: string;
  ime_oca?: string;
  ime_majke?: string;
  zanimanje?: string;
  skolska_sprema?: string;
  radno_mjesto?: string;
  termin_lijecnickog?: string;
  gsm?: string;
  iban?: string;
  prijava_hzmo?: string;
  odjava_hzmo?: string;
  ordinacija_opce_medicine?: string;
  ginekolog?: string;
  zubar?: string;
  terapija_komentar?: string;
  skills?: string;
  experience_years?: string;
  notes?: string;
}

interface UploadResult {
  candidate: ParsedCandidate;
  status: 'pending' | 'success' | 'error';
  error?: string;
}

const SHORT_HEADERS = 'full_name,email,phone,skills,experience_years,notes';
const LONG_HEADERS = 'prezime,ime,full_name,email,prijava_drb,viza_d_form_ref_no,viza_d_status,plane_ticket,mjesto_i_drzava_rodenja,datum_rodenja,drzavljanstvo,vrsta_i_broj_putovnice,mjesto_izdavanja_putovnice,vrijedi_od_do,vrsta_i_broj_vize_mjesto_izdavanja,rok_vazenja_vize,datum_i_mjesto_ulaska_u_rh,rok_odobrenja_boravka,novi_smjestaj_boraviste,prethodni_smjestaj,datum_prijave_16a,datum_odjave_16a,oib,ime_oca,ime_majke,zanimanje,skolska_sprema,radno_mjesto,termin_lijecnickog,gsm,iban,prijava_hzmo,odjava_hzmo,ordinacija_opce_medicine,ginekolog,zubar,terapija_komentar,phone,skills,experience_years,notes';

const SHORT_CSV_EXAMPLE = `${SHORT_HEADERS}
John Doe,john@email.com,+1234567890,"React, TypeScript",5,Great candidate`;

const LONG_CSV_EXAMPLE = `${LONG_HEADERS}
Doe,John,John Doe,john@email.com,DRB123,VISA-REF-001,Approved,TK-12345,Zagreb Croatia,1990-01-15,Croatian,P123456,Zagreb,2020-01-01/2030-01-01,V123/Zagreb,2025-12-31,2024-01-01 Zagreb,2025-06-01,New Address,Old Address,2024-01-15,,,12345678901,Ivan,Marija,Developer,University,"Phone:+385123456,WhatsApp:+385123456",HR1234567890123456789,2024-01-20,,Dr. Smith,Dr. Jones,Dr. Brown,Regular checkups,+1234567890,"React, Node.js",5,Senior developer`;

export const CandidateCSVUploadDialog = ({ open, onOpenChange }: CandidateCSVUploadDialogProps) => {
  const createCandidate = useCreateCandidate();
  const { toast } = useToast();
  const [file, setFile] = useState<File | null>(null);
  const [parsedCandidates, setParsedCandidates] = useState<UploadResult[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadComplete, setUploadComplete] = useState(false);

  const parseCSV = (text: string): ParsedCandidate[] => {
    const lines = text.trim().split('\n');
    if (lines.length < 2) return [];

    const headers = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/['"]/g, ''));
    const candidates: ParsedCandidate[] = [];

    for (let i = 1; i < lines.length; i++) {
      const values: string[] = [];
      let current = '';
      let inQuotes = false;
      
      for (const char of lines[i]) {
        if (char === '"') {
          inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
          values.push(current.trim());
          current = '';
        } else {
          current += char;
        }
      }
      values.push(current.trim());

      const candidate: Record<string, string> = {};
      headers.forEach((header, index) => {
        if (values[index]) {
          candidate[header] = values[index].replace(/^["']|["']$/g, '');
        }
      });

      if (candidate.full_name) {
        candidates.push(candidate as unknown as ParsedCandidate);
      }
    }

    return candidates;
  };

  const parseGsmString = (gsmStr: string): { type: string; number: string }[] => {
    if (!gsmStr) return [];
    const entries = gsmStr.split(',');
    return entries.map(entry => {
      const parts = entry.split(':');
      if (parts.length === 2) {
        return { type: parts[0].trim(), number: parts[1].trim() };
      }
      return { type: 'Phone', number: entry.trim() };
    }).filter(e => e.number);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setUploadComplete(false);
      
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        const candidates = parseCSV(text);
        setParsedCandidates(candidates.map(candidate => ({ candidate, status: 'pending' })));
      };
      reader.readAsText(selectedFile);
    }
  };

  const handleUpload = async () => {
    if (parsedCandidates.length === 0) return;

    setIsProcessing(true);
    const results = [...parsedCandidates];

    for (let i = 0; i < results.length; i++) {
      try {
        const c = results[i].candidate;
        await createCandidate.mutateAsync({
          full_name: c.full_name,
          prezime: c.prezime || null,
          ime: c.ime || null,
          email: c.email || null,
          phone: c.phone || null,
          prijava_drb: c.prijava_drb || null,
          viza_d_form_ref_no: c.viza_d_form_ref_no || null,
          viza_d_status: c.viza_d_status || null,
          plane_ticket: c.plane_ticket || null,
          mjesto_i_drzava_rodenja: c.mjesto_i_drzava_rodenja || null,
          datum_rodenja: c.datum_rodenja || null,
          drzavljanstvo: c.drzavljanstvo || null,
          vrsta_i_broj_putovnice: c.vrsta_i_broj_putovnice || null,
          mjesto_izdavanja_putovnice: c.mjesto_izdavanja_putovnice || null,
          vrijedi_od_do: c.vrijedi_od_do || null,
          vrsta_i_broj_vize_mjesto_izdavanja: c.vrsta_i_broj_vize_mjesto_izdavanja || null,
          rok_vazenja_vize: c.rok_vazenja_vize || null,
          datum_i_mjesto_ulaska_u_rh: c.datum_i_mjesto_ulaska_u_rh || null,
          rok_odobrenja_boravka: c.rok_odobrenja_boravka || null,
          novi_smjestaj_boraviste: c.novi_smjestaj_boraviste || null,
          prethodni_smjestaj: c.prethodni_smjestaj || null,
          datum_prijave_16a: c.datum_prijave_16a || null,
          datum_odjave_16a: c.datum_odjave_16a || null,
          oib: c.oib || null,
          ime_oca: c.ime_oca || null,
          ime_majke: c.ime_majke || null,
          zanimanje: c.zanimanje || null,
          skolska_sprema: c.skolska_sprema || null,
          radno_mjesto: c.radno_mjesto || null,
          termin_lijecnickog: c.termin_lijecnickog || null,
          gsm: parseGsmString(c.gsm || ''),
          iban: c.iban || null,
          prijava_hzmo: c.prijava_hzmo || null,
          odjava_hzmo: c.odjava_hzmo || null,
          ordinacija_opce_medicine: c.ordinacija_opce_medicine || null,
          ginekolog: c.ginekolog || null,
          zubar: c.zubar || null,
          terapija_komentar: c.terapija_komentar || null,
          skills: c.skills ? c.skills.split(',').map(s => s.trim()) : null,
          experience_years: c.experience_years ? parseInt(c.experience_years) : null,
          notes: c.notes || null,
          resume_url: null,
        });
        results[i].status = 'success';
      } catch (error) {
        results[i].status = 'error';
        results[i].error = error instanceof Error ? error.message : 'Unknown error';
      }
      setParsedCandidates([...results]);
    }

    setIsProcessing(false);
    setUploadComplete(true);

    const successCount = results.filter(r => r.status === 'success').length;
    const errorCount = results.filter(r => r.status === 'error').length;

    toast({
      title: 'Upload Complete',
      description: `${successCount} candidates created${errorCount > 0 ? `, ${errorCount} failed` : ''}.`,
      variant: errorCount > 0 ? 'destructive' : 'default',
    });
  };

  const downloadExample = (type: 'short' | 'long') => {
    const content = type === 'short' ? SHORT_CSV_EXAMPLE : LONG_CSV_EXAMPLE;
    const blob = new Blob([content], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `candidate_import_${type}_example.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const resetDialog = () => {
    setFile(null);
    setParsedCandidates([]);
    setUploadComplete(false);
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { onOpenChange(v); if (!v) resetDialog(); }}>
      <DialogContent className="sm:max-w-lg max-h-[80vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5" />
            Import Candidates from CSV
          </DialogTitle>
          <DialogDescription>
            Upload a CSV file to create multiple candidates at once
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="upload" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="upload">Upload</TabsTrigger>
            <TabsTrigger value="examples">CSV Format</TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="space-y-4 mt-4">
            {!file ? (
              <div className="border-2 border-dashed border-border rounded-xl p-8 text-center">
                <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-sm text-muted-foreground mb-4">
                  Select a CSV file to import candidates
                </p>
                <Input
                  type="file"
                  accept=".csv"
                  onChange={handleFileChange}
                  className="max-w-xs mx-auto"
                />
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm font-medium">{file.name}</span>
                    <span className="text-xs text-muted-foreground">
                      ({parsedCandidates.length} candidates found)
                    </span>
                  </div>
                  <Button variant="ghost" size="sm" onClick={resetDialog}>
                    Change file
                  </Button>
                </div>

                <ScrollArea className="h-48 border rounded-lg">
                  <div className="p-3 space-y-2">
                    {parsedCandidates.map((result, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-2 bg-muted/50 rounded-md"
                      >
                        <div className="flex items-center gap-2">
                          {result.status === 'pending' && (
                            <div className="w-4 h-4 rounded-full bg-muted-foreground/30" />
                          )}
                          {result.status === 'success' && (
                            <Check className="w-4 h-4 text-success" />
                          )}
                          {result.status === 'error' && (
                            <X className="w-4 h-4 text-destructive" />
                          )}
                          <span className="text-sm font-medium">{result.candidate.full_name}</span>
                        </div>
                        {result.error && (
                          <span className="text-xs text-destructive">{result.error}</span>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>

                <div className="flex justify-end gap-3">
                  <Button variant="outline" onClick={() => onOpenChange(false)}>
                    {uploadComplete ? 'Close' : 'Cancel'}
                  </Button>
                  {!uploadComplete && (
                    <Button
                      className="btn-primary-gradient"
                      onClick={handleUpload}
                      disabled={isProcessing || parsedCandidates.length === 0}
                    >
                      {isProcessing ? 'Processing...' : `Import ${parsedCandidates.length} Candidates`}
                    </Button>
                  )}
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="examples" className="space-y-4 mt-4">
            <div className="space-y-4">
              {/* Short Version */}
              <div className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="font-medium text-sm">Short Version (Basic Fields)</h4>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => downloadExample('short')}>
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
                <div className="bg-muted rounded-md p-3">
                  <p className="text-xs font-mono text-muted-foreground break-all">
                    {SHORT_HEADERS}
                  </p>
                </div>
              </div>

              {/* Long Version */}
              <div className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="font-medium text-sm">Long Version (All Fields)</h4>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => downloadExample('long')}>
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
                <div className="bg-muted rounded-md p-3 max-h-24 overflow-y-auto">
                  <p className="text-xs font-mono text-muted-foreground break-all">
                    {LONG_HEADERS}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-2 p-3 bg-accent/10 rounded-lg">
                <AlertCircle className="w-4 h-4 text-accent mt-0.5 shrink-0" />
                <div className="text-xs text-muted-foreground">
                  <p className="font-medium text-foreground mb-1">Required field:</p>
                  <p>full_name</p>
                  <p className="mt-2">GSM format: "Phone:+123,WhatsApp:+456"</p>
                  <p className="mt-1">Date format: YYYY-MM-DD</p>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};
