import { useState } from 'react';
import { useCancelPendingChange, PendingChange } from '@/hooks/usePendingChanges';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { 
  Clock, 
  CheckCircle, 
  XCircle, 
  Eye, 
  Trash2,
  FileText,
  ArrowRight
} from 'lucide-react';
import { formatDateTime, formatDate } from '@/lib/dateUtils';

interface PendingChangesListProps {
  changes: PendingChange[];
}

const fieldLabels: Record<string, string> = {
  company_name: 'Company Name',
  contact_name: 'Contact Name',
  contact_email: 'Contact Email',
  phone: 'Phone',
  website: 'Website',
  tax_id: 'Tax ID (OIB)',
  founders_members: 'Founders/Members',
  address_line: 'Address Line',
  city: 'City',
  postal_code: 'Postal Code',
  state: 'State',
  country: 'Country',
  notes: 'Notes',
  logo_url: 'Logo',
  accent_color: 'Accent Color',
  representatives: 'Representatives',
};

export const PendingChangesList = ({ changes }: PendingChangesListProps) => {
  const cancelChange = useCancelPendingChange();
  const [selectedChange, setSelectedChange] = useState<PendingChange | null>(null);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);

  const openDetailDialog = (change: PendingChange) => {
    setSelectedChange(change);
    setDetailDialogOpen(true);
  };

  const openCancelDialog = (change: PendingChange) => {
    setSelectedChange(change);
    setCancelDialogOpen(true);
  };

  const handleCancel = async () => {
    if (!selectedChange) return;
    await cancelChange.mutateAsync(selectedChange.id);
    setCancelDialogOpen(false);
    setSelectedChange(null);
  };

  const getChangedFields = (change: PendingChange) => {
    const proposedChanges = change.proposed_changes as Record<string, unknown>;
    return Object.entries(proposedChanges);
  };

  const formatValue = (key: string, value: unknown): React.ReactNode => {
    if (value === null || value === undefined || value === '') {
      return <span className="text-muted-foreground italic">Empty</span>;
    }

    if (key === 'logo_url' && typeof value === 'string') {
      return (
        <img 
          src={value} 
          alt="Logo" 
          className="w-12 h-12 rounded-lg object-contain border bg-muted"
        />
      );
    }

    if (key === 'accent_color' && typeof value === 'string') {
      return (
        <div className="flex items-center gap-2">
          <div 
            className="w-6 h-6 rounded border shadow-sm"
            style={{ backgroundColor: value }}
          />
          <span className="text-xs font-mono">{value}</span>
        </div>
      );
    }

    if (key === 'representatives' && Array.isArray(value)) {
      return (
        <div className="space-y-1">
          {value.map((rep: Record<string, string>, i: number) => (
            <div key={i} className="text-xs bg-muted/50 p-2 rounded">
              <p className="font-medium">{rep.full_name || '—'}</p>
              <p className="text-muted-foreground">{rep.work_title || '—'}</p>
            </div>
          ))}
        </div>
      );
    }

    return String(value);
  };

  if (changes.length === 0) {
    return null;
  }

  return (
    <>
      <div className="card-elevated p-4">
        <h3 className="text-sm font-semibold text-muted-foreground mb-3 flex items-center gap-2">
          <FileText className="w-4 h-4" />
          Change Requests
        </h3>
        <div className="space-y-2">
          {changes.map((change) => (
            <div 
              key={change.id} 
              className="flex items-center justify-between py-3 px-3 border border-border rounded-lg bg-muted/30"
            >
              <div className="flex items-center gap-3">
                {change.status === 'pending' && <Clock className="w-4 h-4 text-warning" />}
                {change.status === 'approved' && <CheckCircle className="w-4 h-4 text-success" />}
                {change.status === 'rejected' && <XCircle className="w-4 h-4 text-destructive" />}
                <div>
                  <span className="text-sm font-medium">
                    {Object.keys(change.proposed_changes as object).length} field(s)
                  </span>
                  <p className="text-xs text-muted-foreground">
                    {formatDate(change.submitted_at)}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className={`text-xs px-2 py-0.5 rounded-full ${
                  change.status === 'pending' ? 'bg-warning/10 text-warning' :
                  change.status === 'approved' ? 'bg-success/10 text-success' :
                  'bg-destructive/10 text-destructive'
                }`}>
                  {change.status}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7"
                  onClick={() => openDetailDialog(change)}
                >
                  <Eye className="w-3.5 h-3.5" />
                </Button>
                {change.status === 'pending' && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-destructive hover:text-destructive"
                    onClick={() => openCancelDialog(change)}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* View Changes Dialog */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="max-w-lg max-h-[85vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Change Request Details
            </DialogTitle>
            <DialogDescription>
              Submitted on {selectedChange && formatDateTime(selectedChange.submitted_at)}
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="max-h-[50vh] pr-4">
            <div className="space-y-3 py-2">
              {selectedChange && getChangedFields(selectedChange).map(([key, value]) => (
                <div key={key} className="p-3 border rounded-lg bg-muted/30">
                  <p className="text-xs font-medium text-muted-foreground mb-2">
                    {fieldLabels[key] || key}
                  </p>
                  <div className="flex items-center gap-2">
                    <ArrowRight className="w-4 h-4 text-primary shrink-0" />
                    <div className="text-sm">{formatValue(key, value)}</div>
                  </div>
                </div>
              ))}

              {selectedChange?.reviewer_notes && (
                <div className="p-3 border border-destructive/30 bg-destructive/5 rounded-lg">
                  <p className="text-xs font-medium text-destructive mb-1">Reviewer Notes</p>
                  <p className="text-sm">{selectedChange.reviewer_notes}</p>
                </div>
              )}
            </div>
          </ScrollArea>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDetailDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Cancel Confirmation Dialog */}
      <AlertDialog open={cancelDialogOpen} onOpenChange={setCancelDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cancel Change Request</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to cancel this change request? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep Request</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleCancel}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Cancel Request
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};
