import { Badge } from '@/components/ui/badge';
import { ArrowRight, User, Mail, Phone, Briefcase } from 'lucide-react';

interface Representative {
  full_name: string;
  email: string;
  phone: string;
  work_title: string;
}

interface ChangeComparisonCardProps {
  field: string;
  previousValue: unknown;
  newValue: unknown;
}

const formatFieldName = (key: string) => {
  const fieldNames: Record<string, string> = {
    company_name: 'Company Name',
    contact_name: 'Contact Name',
    contact_email: 'Contact Email',
    phone: 'Phone',
    website: 'Website',
    tax_id: 'Tax ID (OIB)',
    founders_members: 'Founders / Members',
    representatives: 'Representatives',
    country: 'Country',
    state: 'State',
    city: 'City',
    postal_code: 'Postal Code',
    address_line: 'Address Line',
    notes: 'Notes',
    logo_url: 'Company Logo',
    accent_color: 'Accent Color',
  };
  return fieldNames[key] || key.replace(/_/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase());
};

const isRepresentativesField = (value: unknown): value is Representative[] => {
  return Array.isArray(value) && value.length > 0 && typeof value[0] === 'object' && 'full_name' in (value[0] as object);
};

const RepresentativeCard = ({ rep, variant }: { rep: Representative; variant: 'old' | 'new' }) => {
  const bgClass = variant === 'old' ? 'bg-destructive/5 border-destructive/20' : 'bg-success/5 border-success/20';
  
  return (
    <div className={`p-3 rounded-lg border ${bgClass} space-y-2`}>
      <div className="flex items-center gap-2">
        <User className="w-4 h-4 text-muted-foreground" />
        <span className="font-medium text-sm">{rep.full_name || '—'}</span>
      </div>
      <div className="flex items-center gap-2">
        <Briefcase className="w-3.5 h-3.5 text-muted-foreground" />
        <span className="text-xs text-muted-foreground">{rep.work_title || '—'}</span>
      </div>
      <div className="flex items-center gap-2">
        <Mail className="w-3.5 h-3.5 text-muted-foreground" />
        <span className="text-xs text-muted-foreground">{rep.email || '—'}</span>
      </div>
      <div className="flex items-center gap-2">
        <Phone className="w-3.5 h-3.5 text-muted-foreground" />
        <span className="text-xs text-muted-foreground">{rep.phone || '—'}</span>
      </div>
    </div>
  );
};

const ColorPreview = ({ color }: { color: string }) => (
  <div className="flex items-center gap-2">
    <div 
      className="w-8 h-8 rounded-lg border shadow-sm" 
      style={{ backgroundColor: color }}
    />
    <code className="text-xs bg-muted px-2 py-1 rounded">{color}</code>
  </div>
);

const LogoPreview = ({ url }: { url: string }) => (
  <div className="w-16 h-16 rounded-lg border overflow-hidden bg-muted">
    <img src={url} alt="Logo" className="w-full h-full object-contain" />
  </div>
);

const SimpleValue = ({ value, variant }: { value: unknown; variant: 'old' | 'new' }) => {
  const displayValue = value === null || value === undefined || value === '' ? '—' : String(value);
  const bgClass = variant === 'old' 
    ? 'bg-destructive/5 border-destructive/20 text-foreground' 
    : 'bg-success/5 border-success/20 text-foreground';
  
  return (
    <div className={`px-4 py-3 rounded-lg border ${bgClass} text-sm`}>
      {displayValue}
    </div>
  );
};

export const ChangeComparisonCard = ({ field, previousValue, newValue }: ChangeComparisonCardProps) => {
  const fieldLabel = formatFieldName(field);
  const isReps = isRepresentativesField(previousValue) || isRepresentativesField(newValue);
  const isColor = field === 'accent_color';
  const isLogo = field === 'logo_url';

  const renderValue = (value: unknown, variant: 'old' | 'new') => {
    if (isReps) {
      const reps = (value as Representative[]) || [];
      if (reps.length === 0) {
        return <SimpleValue value="No representatives" variant={variant} />;
      }
      return (
        <div className="space-y-2">
          {reps.map((rep, idx) => (
            <RepresentativeCard key={idx} rep={rep} variant={variant} />
          ))}
        </div>
      );
    }

    if (isColor && value && typeof value === 'string') {
      return <ColorPreview color={value} />;
    }

    if (isLogo && value && typeof value === 'string') {
      return <LogoPreview url={value} />;
    }

    return <SimpleValue value={value} variant={variant} />;
  };

  // Find specific differences for representatives
  const findRepChanges = () => {
    if (!isReps) return null;
    
    const oldReps = (previousValue as Representative[]) || [];
    const newReps = (newValue as Representative[]) || [];
    
    const changes: string[] = [];
    
    if (oldReps.length !== newReps.length) {
      changes.push(`Count changed from ${oldReps.length} to ${newReps.length}`);
    }
    
    // Find modified representatives
    newReps.forEach((newRep, idx) => {
      const oldRep = oldReps[idx];
      if (oldRep) {
        const fields = ['full_name', 'email', 'phone', 'work_title'] as const;
        fields.forEach((f) => {
          if (oldRep[f] !== newRep[f]) {
            changes.push(`${formatFieldName(f)} changed for representative ${idx + 1}`);
          }
        });
      }
    });
    
    return changes.length > 0 ? changes : null;
  };

  const repChanges = findRepChanges();

  return (
    <div className="rounded-xl border bg-card overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 bg-muted/50 border-b">
        <div className="flex items-center justify-between">
          <h4 className="font-semibold text-foreground">{fieldLabel}</h4>
          <Badge variant="outline" className="text-xs">
            Modified
          </Badge>
        </div>
        {repChanges && (
          <div className="mt-2 flex flex-wrap gap-1.5">
            {repChanges.map((change, idx) => (
              <Badge key={idx} variant="secondary" className="text-xs font-normal">
                {change}
              </Badge>
            ))}
          </div>
        )}
      </div>
      
      {/* Content */}
      <div className="p-4">
        <div className="grid grid-cols-[1fr_auto_1fr] gap-4 items-start">
          {/* Previous Value */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-destructive" />
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                Previous
              </span>
            </div>
            {renderValue(previousValue, 'old')}
          </div>
          
          {/* Arrow */}
          <div className="flex items-center justify-center pt-7">
            <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
              <ArrowRight className="w-5 h-5 text-muted-foreground" />
            </div>
          </div>
          
          {/* New Value */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-success" />
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                New
              </span>
            </div>
            {renderValue(newValue, 'new')}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChangeComparisonCard;