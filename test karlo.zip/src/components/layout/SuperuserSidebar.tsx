import { useLocation, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';
import {
  Users,
  Building2,
  LayoutDashboard,
  LogOut,
  GitBranch,
  UserCheck,
  Clock,
  Sun,
  Moon,
  Monitor,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTheme } from '@/hooks/useTheme';
import { useState } from 'react';
import {
  Tooltip, TooltipContent, TooltipTrigger,
} from '@/components/ui/tooltip';

const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
  { icon: Users, label: 'Candidates', path: '/candidates' },
  { icon: Building2, label: 'Clients', path: '/clients' },
  { icon: GitBranch, label: 'Pipelines', path: '/pipelines' },
  { icon: UserCheck, label: 'Assignments', path: '/assignments' },
  { icon: Clock, label: 'Approvals', path: '/approvals' },
];

const SuperuserSidebar = () => {
  const location = useLocation();
  const { signOut, user } = useAuth();
  const { theme, setTheme } = useTheme();
  const [collapsed, setCollapsed] = useState(false);

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  return (
    <aside
      className={cn(
        'bg-sidebar flex flex-col border-r border-sidebar-border shrink-0 h-screen sticky top-0 transition-all duration-300',
        collapsed ? 'w-[68px]' : 'w-[240px]'
      )}
    >
      {/* Logo */}
      <div className={cn('p-4 border-b border-sidebar-border', collapsed ? 'px-3' : 'px-5')}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-sidebar-primary flex items-center justify-center shrink-0 shadow-lg shadow-sidebar-primary/20">
            <Users className="w-4 h-4 text-sidebar-primary-foreground" />
          </div>
          {!collapsed && (
            <div className="animate-fade-in overflow-hidden">
              <h1 className="font-bold text-sidebar-foreground text-sm leading-tight">MercuryWerks</h1>
              <span className="text-[10px] text-sidebar-foreground/50 font-medium tracking-wider uppercase">Admin</span>
            </div>
          )}
        </div>
      </div>

      {/* Navigation */}
      <nav className={cn('flex-1 py-3 space-y-0.5 overflow-y-auto', collapsed ? 'px-2' : 'px-3')}>
        {navItems.map((item) => {
          const active = isActive(item.path);
          const link = (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                'sidebar-nav-item',
                active && 'sidebar-nav-item-active',
                collapsed && 'justify-center px-2'
              )}
            >
              <item.icon className={cn('w-[18px] h-[18px] shrink-0', active && 'text-sidebar-primary')} />
              {!collapsed && <span className="truncate">{item.label}</span>}
            </Link>
          );

          if (collapsed) {
            return (
              <Tooltip key={item.path}>
                <TooltipTrigger asChild>{link}</TooltipTrigger>
                <TooltipContent side="right" className="text-xs">
                  {item.label}
                </TooltipContent>
              </Tooltip>
            );
          }

          return link;
        })}
      </nav>

      {/* Bottom section */}
      <div className={cn('mt-auto border-t border-sidebar-border', collapsed ? 'p-2' : 'p-3')}>
        {/* Theme Toggle */}
        <div className="mb-3 flex items-center justify-center gap-0.5 p-1 rounded-lg bg-sidebar-accent/50">
          {[
            { key: 'light', icon: Sun, title: 'Light' },
            { key: 'grey', icon: Monitor, title: 'Grey' },
            { key: 'dark', icon: Moon, title: 'Dark' },
          ].map((t) => (
            <Tooltip key={t.key}>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className={cn(
                    'h-7 w-7 text-sidebar-foreground/60 hover:text-sidebar-foreground',
                    theme === t.key && 'bg-sidebar-accent text-sidebar-foreground'
                  )}
                  onClick={() => setTheme(t.key as any)}
                >
                  <t.icon className="h-3.5 w-3.5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="right" className="text-xs">{t.title}</TooltipContent>
            </Tooltip>
          ))}
        </div>

        {/* User info */}
        {!collapsed && (
          <div className="mb-2 px-2 animate-fade-in">
            <p className="text-[10px] text-sidebar-foreground/40 uppercase tracking-wider font-medium">Account</p>
            <p className="text-xs text-sidebar-foreground/80 font-medium truncate mt-0.5">
              {user?.email}
            </p>
          </div>
        )}

        {/* Sign out */}
        <Button
          variant="ghost"
          className={cn(
            'w-full text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-sidebar-accent text-sm',
            collapsed ? 'justify-center px-2' : 'justify-start gap-3'
          )}
          onClick={signOut}
        >
          <LogOut className="w-4 h-4 shrink-0" />
          {!collapsed && <span>Sign out</span>}
        </Button>

        {/* Collapse toggle */}
        <Button
          variant="ghost"
          size="icon"
          className="w-full h-8 mt-1 text-sidebar-foreground/40 hover:text-sidebar-foreground hover:bg-sidebar-accent"
          onClick={() => setCollapsed(!collapsed)}
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </Button>
      </div>
    </aside>
  );
};

export default SuperuserSidebar;
