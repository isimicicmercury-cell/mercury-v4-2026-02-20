import { useLocation, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useClients } from '@/hooks/useClients';
import { cn } from '@/lib/utils';
import {
  Users,
  LayoutDashboard,
  LogOut,
  CheckCircle,
  Building2,
  Sun,
  Moon,
  Monitor,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTheme } from '@/hooks/useTheme';

const navItems = [
  { icon: LayoutDashboard, label: 'My Candidates', path: '/' },
  { icon: CheckCircle, label: 'My Hires', path: '/my-hires' },
  { icon: Building2, label: 'My Profile', path: '/my-profile' },
];

const ClientSidebar = () => {
  const location = useLocation();
  const { signOut, user, clientId } = useAuth();
  const { data: clients = [] } = useClients();
  const { theme, setTheme } = useTheme();

  const client = clients.find(c => c.id === clientId);
  const accentColor = client?.accent_color;

  // Build sidebar style with accent color
  const sidebarStyle = accentColor ? {
    '--sidebar-accent-color': accentColor,
  } as React.CSSProperties : {};

  return (
    <aside 
      className={cn(
        "w-64 flex flex-col border-r shrink-0 h-screen sticky top-0",
        accentColor ? "client-sidebar-themed" : "bg-sidebar border-sidebar-border"
      )}
      style={sidebarStyle}
    >
      <div className={cn(
        "p-6 border-b",
        accentColor ? "border-white/10" : "border-sidebar-border"
      )}>
        <div className="flex items-center gap-3">
          {client?.logo_url ? (
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center overflow-hidden">
              <img 
                src={client.logo_url} 
                alt={`${client.company_name} logo`}
                className="w-full h-full object-contain p-1"
              />
            </div>
          ) : (
            <div className={cn(
              "w-10 h-10 rounded-xl flex items-center justify-center",
              accentColor ? "bg-white/20" : "bg-sidebar-primary"
            )}>
              <Users className={cn(
                "w-5 h-5",
                accentColor ? "text-white" : "text-sidebar-primary-foreground"
              )} />
            </div>
          )}
          <div>
            <h1 className={cn(
              "font-bold",
              accentColor ? "text-white" : "text-sidebar-foreground"
            )}>{client?.company_name || 'TalentBridge'}</h1>
            <span className={cn(
              "text-xs",
              accentColor ? "text-white/60" : "text-sidebar-foreground/60"
            )}>Client Portal</span>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={cn(
              'flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors',
              accentColor 
                ? 'text-white/80 hover:bg-white/10 hover:text-white'
                : 'text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-foreground',
              location.pathname === item.path && (
                accentColor 
                  ? 'bg-white/20 text-white font-medium'
                  : 'bg-sidebar-accent text-sidebar-foreground font-medium'
              )
            )}
          >
            <item.icon className="w-5 h-5" />
            <span>{item.label}</span>
          </Link>
        ))}
      </nav>

      {/* Floating bottom section */}
      <div className={cn(
        "mt-auto p-4 border-t",
        accentColor ? "border-white/10" : "border-sidebar-border"
      )}>
        {/* Theme Toggle */}
        <div className="mb-4 flex items-center justify-center gap-1 p-1 rounded-lg bg-white/10">
          <Button
            variant="ghost"
            size="icon"
            className={cn(
              "h-8 w-8",
              theme === 'light' && "bg-white/20"
            )}
            onClick={() => setTheme('light')}
            title="Light mode"
          >
            <Sun className={cn(
              "h-4 w-4",
              accentColor ? "text-white" : "text-sidebar-foreground"
            )} />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className={cn(
              "h-8 w-8",
              theme === 'grey' && "bg-white/20"
            )}
            onClick={() => setTheme('grey')}
            title="Grey mode"
          >
            <Monitor className={cn(
              "h-4 w-4",
              accentColor ? "text-white" : "text-sidebar-foreground"
            )} />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className={cn(
              "h-8 w-8",
              theme === 'dark' && "bg-white/20"
            )}
            onClick={() => setTheme('dark')}
            title="Dark mode"
          >
            <Moon className={cn(
              "h-4 w-4",
              accentColor ? "text-white" : "text-sidebar-foreground"
            )} />
          </Button>
        </div>

        <div className="mb-4 px-3">
          <p className={cn(
            "text-xs",
            accentColor ? "text-white/60" : "text-sidebar-foreground/60"
          )}>Logged in as</p>
          <p className={cn(
            "text-sm font-medium truncate",
            accentColor ? "text-white" : "text-sidebar-foreground"
          )}>
            {user?.email}
          </p>
        </div>
        <Button
          variant="ghost"
          className={cn(
            "w-full justify-start gap-3",
            accentColor 
              ? "text-white/80 hover:text-white hover:bg-white/10"
              : "text-sidebar-foreground/80 hover:text-sidebar-foreground hover:bg-sidebar-accent"
          )}
          onClick={signOut}
        >
          <LogOut className="w-5 h-5" />
          <span>Sign out</span>
        </Button>
      </div>
    </aside>
  );
};

export default ClientSidebar;
