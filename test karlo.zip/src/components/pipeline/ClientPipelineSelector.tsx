import {
  usePipelineTemplates,
  useCompanyPipelineAssignments,
  useAssignClientPipeline,
  useRemoveClientPipeline,
  usePipelineStages,
  ClientPipelineAssignment,
  PipelineTemplate,
} from '@/hooks/usePipelines';
import { useClients } from '@/hooks/useClients';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { GitBranch, X, ChevronRight, Plus } from 'lucide-react';
import { useState } from 'react';

interface ClientPipelineSelectorProps {
  clientId: string;
}

const PipelineStagePreview = ({ templateId }: { templateId: string }) => {
  const { data: stages = [] } = usePipelineStages(templateId);
  if (stages.length === 0) return null;
  return (
    <div className="flex items-center gap-0 overflow-x-auto py-1">
      {stages.map((stage, i) => (
        <div key={stage.id} className="flex items-center">
          <span className="text-xs text-muted-foreground whitespace-nowrap px-1 py-0.5 bg-muted rounded">
            {stage.name}
          </span>
          {i < stages.length - 1 && (
            <ChevronRight className="w-3 h-3 text-muted-foreground/30 shrink-0" />
          )}
        </div>
      ))}
    </div>
  );
};

const ClientPipelineSelector = ({ clientId }: ClientPipelineSelectorProps) => {
  const { data: templates = [] } = usePipelineTemplates();
  const { data: clients = [] } = useClients();
  const client = clients.find(c => c.id === clientId);
  const companyName = client?.company_name || null;
  const { data: assignments = [] } = useCompanyPipelineAssignments(companyName);
  const assignPipeline = useAssignClientPipeline();
  const removePipeline = useRemoveClientPipeline();
  const [selectedId, setSelectedId] = useState<string>('');

  const activeTemplates = templates.filter((t) => t.is_active);
  const assignedTemplateIds = new Set(assignments.map(a => a.pipeline_template_id));
  const availableTemplates = activeTemplates.filter(t => !assignedTemplateIds.has(t.id));

  const handleAssign = async () => {
    if (!selectedId || !companyName) return;
    await assignPipeline.mutateAsync({ clientId, pipelineTemplateId: selectedId, companyName });
    setSelectedId('');
  };

  const handleRemove = async (pipelineTemplateId: string) => {
    if (!companyName) return;
    await removePipeline.mutateAsync({ clientId, pipelineTemplateId, companyName });
  };

  return (
    <div className="card-elevated p-6">
      <h3 className="text-sm font-semibold text-muted-foreground mb-4 flex items-center gap-2">
        <GitBranch className="w-4 h-4" />Hiring Pipelines ({assignments.length})
      </h3>

      {assignments.length > 0 ? (
        <div className="space-y-3">
          {assignments.map((assignment) => (
            <div key={assignment.id} className="p-3 border border-border rounded-lg bg-muted/30">
              <div className="flex items-center justify-between mb-1">
                <div>
                  <p className="font-medium text-foreground text-sm">{assignment.pipeline_template?.name}</p>
                  {assignment.pipeline_template?.description && (
                    <p className="text-xs text-muted-foreground">{assignment.pipeline_template.description}</p>
                  )}
                </div>
                <Button size="sm" variant="ghost" onClick={() => handleRemove(assignment.pipeline_template_id)} className="text-destructive hover:text-destructive h-7 w-7 p-0">
                  <X className="w-3.5 h-3.5" />
                </Button>
              </div>
              <PipelineStagePreview templateId={assignment.pipeline_template_id} />
            </div>
          ))}

          {/* Add another pipeline */}
          {availableTemplates.length > 0 && (
            <div className="pt-2 border-t border-border">
              <Label className="text-xs text-muted-foreground">Add Pipeline</Label>
              <div className="flex gap-2 mt-1">
                <Select value={selectedId} onValueChange={setSelectedId}>
                  <SelectTrigger className="flex-1 h-8 text-xs">
                    <SelectValue placeholder="Select pipeline..." />
                  </SelectTrigger>
                  <SelectContent>
                    {availableTemplates.map((t) => (
                      <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button size="sm" variant="outline" onClick={handleAssign} disabled={!selectedId || assignPipeline.isPending}>
                  <Plus className="w-3.5 h-3.5 mr-1" />Add
                </Button>
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">No pipelines assigned. Add pipelines so that claimed candidates can enter the hiring process.</p>
          <div className="flex gap-2">
            <Select value={selectedId} onValueChange={setSelectedId}>
              <SelectTrigger className="flex-1">
                <SelectValue placeholder="Select a pipeline..." />
              </SelectTrigger>
              <SelectContent>
                {activeTemplates.map((t) => (
                  <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button className="btn-primary-gradient" onClick={handleAssign} disabled={!selectedId || assignPipeline.isPending}>
              Assign
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ClientPipelineSelector;
