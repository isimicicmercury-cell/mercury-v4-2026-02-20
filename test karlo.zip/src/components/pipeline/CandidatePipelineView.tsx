import { useState } from 'react';
import {
  useCandidatePipelineState,
  usePipelineStages,
  useCandidateStageHistory,
  useAdvanceCandidateStage,
  useUpdateCandidatePipelineStatus,
  CandidateStageHistory,
} from '@/hooks/usePipelines';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { CheckCircle, Circle, ChevronRight, SkipForward, Clock, AlertCircle, ArrowRight } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface CandidatePipelineViewProps {
  candidateId: string;
}

const CandidatePipelineView = ({ candidateId }: CandidatePipelineViewProps) => {
  const { role } = useAuth();
  const { data: pipelineState } = useCandidatePipelineState(candidateId);
  const { data: stages = [] } = usePipelineStages(pipelineState?.pipeline_template_id || null);
  const { data: history = [] } = useCandidateStageHistory(candidateId);
  const advanceStage = useAdvanceCandidateStage();
  const updateStatus = useUpdateCandidatePipelineStatus();

  const [advanceDialogOpen, setAdvanceDialogOpen] = useState(false);
  const [advanceNote, setAdvanceNote] = useState('');
  const [isSkipping, setIsSkipping] = useState(false);

  if (!pipelineState) {
    return (
      <div className="p-4 border border-border rounded-lg bg-muted/30 text-center">
        <p className="text-sm text-muted-foreground">This candidate is not in any pipeline.</p>
      </div>
    );
  }

  const currentStageIndex = stages.findIndex((s) => s.id === pipelineState.current_stage_id);
  const currentStage = stages[currentStageIndex];
  const nextStage = stages[currentStageIndex + 1];
  const isLastStage = currentStageIndex === stages.length - 1;
  const canSkip = currentStage && !currentStage.is_required;

  const canUserAdvance = role === 'superuser' || (currentStage?.can_client_advance === true);

  const handleAdvance = async () => {
    await advanceStage.mutateAsync({ candidateId, note: advanceNote || undefined, skip: isSkipping });
    setAdvanceDialogOpen(false);
    setAdvanceNote('');
    setIsSkipping(false);
  };

  const handleStatusChange = async (newStatus: string) => {
    await updateStatus.mutateAsync({ candidateId, status: newStatus });
  };

  const statusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-accent';
      case 'hired': return 'text-success';
      case 'rejected': return 'text-destructive';
      case 'on_hold': return 'text-warning';
      default: return 'text-muted-foreground';
    }
  };

  return (
    <div className="space-y-6">
      {/* Status bar */}
      <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50 border border-border">
        <div className="flex items-center gap-3">
          <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Pipeline Status</span>
          <span className={cn('font-semibold text-sm uppercase', statusColor(pipelineState.status))}>
            {pipelineState.status}
          </span>
        </div>
        {role === 'superuser' && (
          <Select value={pipelineState.status} onValueChange={handleStatusChange}>
            <SelectTrigger className="w-[140px] h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="hired">Hired</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
              <SelectItem value="on_hold">On Hold</SelectItem>
            </SelectContent>
          </Select>
        )}
      </div>

      {/* Stage Timeline */}
      <div className="flex items-center gap-0 overflow-x-auto pb-2">
        {stages.map((stage, i) => {
          const isPast = i < currentStageIndex;
          const isCurrent = i === currentStageIndex;
          const isFuture = i > currentStageIndex;
          return (
            <div key={stage.id} className="flex items-center">
              <div className={cn(
                'flex flex-col items-center gap-1 px-3 py-2 rounded-lg min-w-[100px] text-center transition-colors',
                isCurrent && 'bg-primary/10 border border-primary/30',
                isPast && 'opacity-70',
              )}>
                {isPast ? (
                  <CheckCircle className="w-5 h-5 text-success" />
                ) : isCurrent ? (
                  <div className="relative">
                    <Circle className="w-5 h-5 text-primary fill-primary/20" />
                    <div className="absolute inset-0 animate-ping">
                      <Circle className="w-5 h-5 text-primary/30" />
                    </div>
                  </div>
                ) : (
                  <Circle className="w-5 h-5 text-muted-foreground/30" />
                )}
                <span className={cn(
                  'text-xs font-medium',
                  isCurrent ? 'text-foreground' : 'text-muted-foreground'
                )}>{stage.name}</span>
                <span className="text-[10px] text-muted-foreground/60">{stage.stage_type}</span>
                {!stage.is_required && (
                  <span className="text-[10px] text-warning italic">optional</span>
                )}
              </div>
              {i < stages.length - 1 && (
                <ChevronRight className="w-4 h-4 text-muted-foreground/30 shrink-0" />
              )}
            </div>
          );
        })}
      </div>

      {/* Action Buttons */}
      {pipelineState.status === 'active' && canUserAdvance && (
        <div className="flex gap-2">
          {!isLastStage && (
            <Button
              className="btn-primary-gradient"
              onClick={() => { setIsSkipping(false); setAdvanceDialogOpen(true); }}
              disabled={advanceStage.isPending}
            >
              <ArrowRight className="w-4 h-4 mr-2" />
              Advance to {nextStage?.name || 'Next'}
            </Button>
          )}
          {canSkip && !isLastStage && (
            <Button
              variant="outline"
              onClick={() => { setIsSkipping(true); setAdvanceDialogOpen(true); }}
              disabled={advanceStage.isPending}
            >
              <SkipForward className="w-4 h-4 mr-2" />
              Skip (Optional)
            </Button>
          )}
        </div>
      )}

      {/* History */}
      <div>
        <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Stage History</h4>
        {history.length === 0 ? (
          <p className="text-sm text-muted-foreground/50">No history yet.</p>
        ) : (
          <div className="space-y-2">
            {history.map((h) => {
              const fromStage = stages.find(s => s.id === h.from_stage_id);
              const toStage = stages.find(s => s.id === h.to_stage_id);
              return (
                <div key={h.id} className="flex items-start gap-3 p-2 rounded bg-muted/30 border border-border/50">
                  <Clock className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 text-xs">
                      {fromStage && (
                        <>
                          <span className="text-muted-foreground">{fromStage.name}</span>
                          <ChevronRight className="w-3 h-3 text-muted-foreground/50" />
                        </>
                      )}
                      <span className="font-medium text-foreground">{toStage?.name || '?'}</span>
                    </div>
                    {h.note && <p className="text-xs text-muted-foreground mt-0.5">{h.note}</p>}
                  </div>
                  <span className="text-[10px] text-muted-foreground/60 whitespace-nowrap">
                    {format(new Date(h.changed_at), 'dd.MM.yyyy HH:mm')}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Advance Dialog */}
      <Dialog open={advanceDialogOpen} onOpenChange={setAdvanceDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{isSkipping ? 'Skip Stage' : 'Advance Stage'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="flex items-center gap-2 text-sm">
              <span className="text-muted-foreground">{currentStage?.name}</span>
              <ChevronRight className="w-4 h-4 text-muted-foreground/50" />
              <span className="font-medium text-foreground">{nextStage?.name}</span>
            </div>
            <div>
              <Label>Note (optional)</Label>
              <Input
                value={advanceNote}
                onChange={(e) => setAdvanceNote(e.target.value)}
                placeholder="Add a note about this transition..."
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setAdvanceDialogOpen(false)}>Cancel</Button>
              <Button className="btn-primary-gradient" onClick={handleAdvance} disabled={advanceStage.isPending}>
                {advanceStage.isPending ? 'Processing...' : isSkipping ? 'Skip Stage' : 'Advance'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CandidatePipelineView;
