import { useState } from 'react';
import { useCreateClient } from '@/hooks/useClients';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Upload, FileText, Check, X, AlertCircle, Download } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CSVUploadDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface ParsedClient {
  company_name: string;
  contact_name?: string;
  contact_email: string;
  phone?: string;
  notes?: string;
  login_username: string;
  login_password: string;
  website?: string;
  tax_id?: string;
  founders_members?: string;
  address_line?: string;
  city?: string;
  postal_code?: string;
  state?: string;
  country?: string;
}

interface UploadResult {
  client: ParsedClient;
  status: 'pending' | 'success' | 'error';
  error?: string;
}

const SHORT_HEADERS = 'company_name,contact_email,login_username,login_password';
const LONG_HEADERS = 'company_name,contact_name,contact_email,phone,login_username,login_password,website,tax_id,founders_members,address_line,city,postal_code,state,country,notes';

const SHORT_CSV_EXAMPLE = `${SHORT_HEADERS}
Acme Corp,contact@acme.com,acme_user,SecurePass123!
Beta Inc,hello@beta.io,beta_admin,BetaPass456@`;

const LONG_CSV_EXAMPLE = `${LONG_HEADERS}
Acme Corp,John Smith,contact@acme.com,+1234567890,acme_user,SecurePass123!,https://acme.com,12345678901,"John Smith, Jane Doe",123 Main St,New York,10001,NY,USA,Premium client`;

export const CSVUploadDialog = ({ open, onOpenChange }: CSVUploadDialogProps) => {
  const createClient = useCreateClient();
  const { toast } = useToast();
  const [file, setFile] = useState<File | null>(null);
  const [parsedClients, setParsedClients] = useState<UploadResult[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadComplete, setUploadComplete] = useState(false);

  const parseCSV = (text: string): ParsedClient[] => {
    const lines = text.trim().split('\n');
    if (lines.length < 2) return [];

    const headers = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/['"]/g, ''));
    const clients: ParsedClient[] = [];

    for (let i = 1; i < lines.length; i++) {
      const values: string[] = [];
      let current = '';
      let inQuotes = false;
      
      for (const char of lines[i]) {
        if (char === '"') {
          inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
          values.push(current.trim());
          current = '';
        } else {
          current += char;
        }
      }
      values.push(current.trim());

      const client: Record<string, string> = {};
      headers.forEach((header, index) => {
        if (values[index]) {
          client[header] = values[index].replace(/^["']|["']$/g, '');
        }
      });

      if (client.company_name && client.contact_email && client.login_username && client.login_password) {
        clients.push(client as unknown as ParsedClient);
      }
    }

    return clients;
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setUploadComplete(false);
      
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        const clients = parseCSV(text);
        setParsedClients(clients.map(client => ({ client, status: 'pending' })));
      };
      reader.readAsText(selectedFile);
    }
  };

  const handleUpload = async () => {
    if (parsedClients.length === 0) return;

    setIsProcessing(true);
    const results = [...parsedClients];

    for (let i = 0; i < results.length; i++) {
      try {
        const clientData = results[i].client;
        await createClient.mutateAsync({
          company_name: clientData.company_name,
          contact_name: clientData.contact_name,
          contact_email: clientData.contact_email,
          phone: clientData.phone,
          notes: clientData.notes,
          login_username: clientData.login_username,
          login_password: clientData.login_password,
          // Extended fields
          website: clientData.website,
          tax_id: clientData.tax_id,
          founders_members: clientData.founders_members,
          address_line: clientData.address_line,
          city: clientData.city,
          postal_code: clientData.postal_code,
          state: clientData.state,
          country: clientData.country,
        });
        results[i].status = 'success';
      } catch (error) {
        results[i].status = 'error';
        results[i].error = error instanceof Error ? error.message : 'Unknown error';
      }
      setParsedClients([...results]);
    }

    setIsProcessing(false);
    setUploadComplete(true);

    const successCount = results.filter(r => r.status === 'success').length;
    const errorCount = results.filter(r => r.status === 'error').length;

    toast({
      title: 'Upload Complete',
      description: `${successCount} clients created${errorCount > 0 ? `, ${errorCount} failed` : ''}.`,
      variant: errorCount > 0 ? 'destructive' : 'default',
    });
  };

  const downloadExample = (type: 'short' | 'long') => {
    const content = type === 'short' ? SHORT_CSV_EXAMPLE : LONG_CSV_EXAMPLE;
    const blob = new Blob([content], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `client_import_${type}_example.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const resetDialog = () => {
    setFile(null);
    setParsedClients([]);
    setUploadComplete(false);
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { onOpenChange(v); if (!v) resetDialog(); }}>
      <DialogContent className="sm:max-w-lg max-h-[80vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5" />
            Import Clients from CSV
          </DialogTitle>
          <DialogDescription>
            Upload a CSV file to create multiple clients at once
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="upload" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="upload">Upload</TabsTrigger>
            <TabsTrigger value="examples">CSV Format</TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="space-y-4 mt-4">
            {!file ? (
              <div className="border-2 border-dashed border-border rounded-xl p-8 text-center">
                <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-sm text-muted-foreground mb-4">
                  Select a CSV file to import clients
                </p>
                <Input
                  type="file"
                  accept=".csv"
                  onChange={handleFileChange}
                  className="max-w-xs mx-auto"
                />
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm font-medium">{file.name}</span>
                    <span className="text-xs text-muted-foreground">
                      ({parsedClients.length} clients found)
                    </span>
                  </div>
                  <Button variant="ghost" size="sm" onClick={resetDialog}>
                    Change file
                  </Button>
                </div>

                <ScrollArea className="h-48 border rounded-lg">
                  <div className="p-3 space-y-2">
                    {parsedClients.map((result, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-2 bg-muted/50 rounded-md"
                      >
                        <div className="flex items-center gap-2">
                          {result.status === 'pending' && (
                            <div className="w-4 h-4 rounded-full bg-muted-foreground/30" />
                          )}
                          {result.status === 'success' && (
                            <Check className="w-4 h-4 text-success" />
                          )}
                          {result.status === 'error' && (
                            <X className="w-4 h-4 text-destructive" />
                          )}
                          <span className="text-sm font-medium">{result.client.company_name}</span>
                          <span className="text-xs text-muted-foreground">
                            ({result.client.login_username})
                          </span>
                        </div>
                        {result.error && (
                          <span className="text-xs text-destructive">{result.error}</span>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>

                <div className="flex justify-end gap-3">
                  <Button variant="outline" onClick={() => onOpenChange(false)}>
                    {uploadComplete ? 'Close' : 'Cancel'}
                  </Button>
                  {!uploadComplete && (
                    <Button
                      className="btn-primary-gradient"
                      onClick={handleUpload}
                      disabled={isProcessing || parsedClients.length === 0}
                    >
                      {isProcessing ? 'Processing...' : `Import ${parsedClients.length} Clients`}
                    </Button>
                  )}
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="examples" className="space-y-4 mt-4">
            <div className="space-y-4">
              {/* Short Version */}
              <div className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="font-medium text-sm">Short Version (Required Fields)</h4>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => downloadExample('short')}>
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
                <div className="bg-muted rounded-md p-3">
                  <p className="text-xs font-mono text-muted-foreground break-all">
                    {SHORT_HEADERS}
                  </p>
                </div>
              </div>

              {/* Long Version */}
              <div className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="font-medium text-sm">Long Version (All Fields)</h4>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => downloadExample('long')}>
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
                <div className="bg-muted rounded-md p-3">
                  <p className="text-xs font-mono text-muted-foreground break-all">
                    {LONG_HEADERS}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-2 p-3 bg-accent/10 rounded-lg">
                <AlertCircle className="w-4 h-4 text-accent mt-0.5 shrink-0" />
                <div className="text-xs text-muted-foreground">
                  <p className="font-medium text-foreground mb-1">Required fields:</p>
                  <p>company_name, contact_email, login_username, login_password</p>
                  <p className="mt-2">All other fields are optional. Wrap values containing commas in double quotes.</p>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};