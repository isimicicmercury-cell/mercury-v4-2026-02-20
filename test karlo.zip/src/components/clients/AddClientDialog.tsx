import { useState, useEffect, useMemo } from 'react';
import { useCreateClient, useClients, Representative, checkFraudMatches, FraudMatchData } from '@/hooks/useClients';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Plus, Trash2, ChevronDown, ChevronUp, RefreshCw, AlertTriangle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { generateUsername, generatePassword } from '@/lib/croatianUtils';

interface AddClientDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface RepresentativeWithCredentials extends Representative {
  login_username: string;
  login_password: string;
}

interface ClientForm {
  company_name: string;
  phone: string;
  notes: string;
  founders_members: string;
  website: string;
  tax_id: string;
  country: string;
  state: string;
  city: string;
  postal_code: string;
  address_line: string;
  representatives: RepresentativeWithCredentials[];
}

const initialForm: ClientForm = {
  company_name: '',
  phone: '',
  notes: '',
  founders_members: '',
  website: '',
  tax_id: '',
  country: '',
  state: '',
  city: '',
  postal_code: '',
  address_line: '',
  representatives: [{ 
    first_name: '',
    last_name: '',
    email: '', 
    phone: '', 
    work_title: '',
    login_username: '',
    login_password: generatePassword(),
  }],
};

export const AddClientDialog = ({ open, onOpenChange }: AddClientDialogProps) => {
  const createClient = useCreateClient();
  const { data: allClients = [] } = useClients();
  const [form, setForm] = useState<ClientForm>(initialForm);
  const [showExtended, setShowExtended] = useState(false);
  const [fraudWarning, setFraudWarning] = useState<FraudMatchData | null>(null);

  const bannedClients = useMemo(() => allClients.filter(c => c.is_banned), [allClients]);
  
  useEffect(() => {
    if (form.company_name || form.phone || form.tax_id || form.address_line) {
      const match = checkFraudMatches(
        {
          company_name: form.company_name,
          contact_email: form.representatives[0]?.email,
          phone: form.phone,
          tax_id: form.tax_id,
          address_line: form.address_line,
        },
        bannedClients
      );
      setFraudWarning(match);
    } else {
      setFraudWarning(null);
    }
  }, [form.company_name, form.phone, form.tax_id, form.address_line, form.representatives, bannedClients]);

  useEffect(() => {
    if (open) {
      setForm({
        ...initialForm,
        representatives: [{ 
          first_name: '',
          last_name: '',
          email: '', 
          phone: '', 
          work_title: '',
          login_username: '',
          login_password: generatePassword(),
        }],
      });
      setShowExtended(false);
    }
  }, [open]);

  // Auto-generate username when company or rep name changes
  useEffect(() => {
    const updatedReps = form.representatives.map((rep, index) => ({
      ...rep,
      login_username: generateUsername(form.company_name, `${rep.first_name} ${rep.last_name}`.trim(), index),
    }));
    
    const usernamesChanged = updatedReps.some((rep, index) => 
      rep.login_username !== form.representatives[index].login_username
    );
    
    if (usernamesChanged && form.company_name) {
      setForm(prev => ({ ...prev, representatives: updatedReps }));
    }
  }, [form.company_name]);

  const addRepresentative = () => {
    const newRep: RepresentativeWithCredentials = {
      first_name: '',
      last_name: '',
      email: '',
      phone: '',
      work_title: '',
      login_username: generateUsername(form.company_name, '', form.representatives.length),
      login_password: generatePassword(),
    };
    setForm({
      ...form,
      representatives: [...form.representatives, newRep],
    });
  };

  const updateRepresentative = (index: number, field: keyof RepresentativeWithCredentials, value: string) => {
    const reps = [...form.representatives];
    reps[index] = { ...reps[index], [field]: value };
    
    // Auto-update username when name changes
    if (field === 'first_name' || field === 'last_name') {
      const fullName = `${field === 'first_name' ? value : reps[index].first_name} ${field === 'last_name' ? value : reps[index].last_name}`.trim();
      reps[index].login_username = generateUsername(form.company_name, fullName, index);
    }
    
    setForm({ ...form, representatives: reps });
  };

  const regeneratePassword = (index: number) => {
    const reps = [...form.representatives];
    reps[index].login_password = generatePassword();
    setForm({ ...form, representatives: reps });
  };

  const removeRepresentative = (index: number) => {
    if (form.representatives.length <= 1) return;
    const reps = [...form.representatives];
    reps.splice(index, 1);
    setForm({ ...form, representatives: reps });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const validReps = form.representatives.filter(rep => rep.email && (rep.first_name || rep.last_name));
    if (validReps.length === 0) return;

    for (const rep of validReps) {
      const contactName = `${rep.first_name} ${rep.last_name}`.trim();
      await createClient.mutateAsync({
        company_name: form.company_name,
        contact_name: contactName,
        contact_email: rep.email,
        phone: rep.phone || form.phone || undefined,
        notes: form.notes || undefined,
        login_username: rep.login_username,
        login_password: rep.login_password,
        website: form.website || undefined,
        tax_id: form.tax_id || undefined,
        founders_members: form.founders_members || undefined,
        address_line: form.address_line || undefined,
        city: form.city || undefined,
        postal_code: form.postal_code || undefined,
        state: form.state || undefined,
        country: form.country || undefined,
        ...(fraudWarning ? { fraud_match_data: fraudWarning, fraud_review_status: 'pending' } : {}),
      });
    }
    
    setForm(initialForm);
    setShowExtended(false);
    setFraudWarning(null);
    onOpenChange(false);
  };

  const hasValidRepresentative = form.representatives.some(rep => rep.email && (rep.first_name || rep.last_name));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle>Add New Client</DialogTitle>
        </DialogHeader>
        <ScrollArea className="max-h-[70vh] pr-4">
          <form onSubmit={handleSubmit} className="space-y-4 mt-4">
            {/* Fraud Warning */}
            {fraudWarning && (
              <Alert className="border-warning bg-warning/10">
                <AlertTriangle className="h-4 w-4 text-warning" />
                <AlertDescription className="text-warning">
                  <strong>Warning:</strong> This client matches data from a banned client: {fraudWarning.matched_company_name}
                  <br />
                  <span className="text-sm">Matched fields: {fraudWarning.matched_fields.join(', ')}</span>
                  <br />
                  <span className="text-sm">This client will be flagged for manual review in the Approvals tab.</span>
                </AlertDescription>
              </Alert>
            )}
            
            {/* Basic Fields */}
            <div>
              <label className="input-label">Company Name *</label>
              <Input
                value={form.company_name}
                onChange={(e) => setForm({ ...form, company_name: e.target.value })}
                placeholder="Acme Corporation"
                required
              />
            </div>
            
            <div>
              <label className="input-label">Phone</label>
              <Input
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                placeholder="+385 1 234 5678"
              />
            </div>

            {/* Representatives Section */}
            <div className="border-t border-border pt-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="text-sm font-semibold text-foreground">Representatives (Zastupnici) *</p>
                  <p className="text-xs text-muted-foreground">At least one representative with email is required. Each gets their own login.</p>
                </div>
              </div>
              
              <Alert className="mb-4">
                <AlertDescription className="text-xs">
                  Each representative will receive their own username and password to log in as this client.
                </AlertDescription>
              </Alert>
              
              <div className="space-y-4">
                {form.representatives.map((rep, index) => (
                  <div key={index} className="p-4 border border-border rounded-lg bg-muted/30 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-foreground">
                        Representative {index + 1}
                      </span>
                      {form.representatives.length > 1 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6 text-destructive hover:text-destructive"
                          onClick={() => removeRepresentative(index)}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      )}
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="input-label">First Name *</label>
                        <Input
                          placeholder="Ime"
                          value={rep.first_name}
                          onChange={(e) => updateRepresentative(index, 'first_name', e.target.value)}
                          required={index === 0}
                        />
                      </div>
                      <div>
                        <label className="input-label">Last Name *</label>
                        <Input
                          placeholder="Prezime"
                          value={rep.last_name}
                          onChange={(e) => updateRepresentative(index, 'last_name', e.target.value)}
                          required={index === 0}
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="input-label">Email *</label>
                        <Input
                          placeholder="Email"
                          type="email"
                          value={rep.email}
                          onChange={(e) => updateRepresentative(index, 'email', e.target.value)}
                          required={index === 0}
                        />
                      </div>
                      <div>
                        <label className="input-label">Phone</label>
                        <Input
                          placeholder="Phone"
                          value={rep.phone}
                          onChange={(e) => updateRepresentative(index, 'phone', e.target.value)}
                        />
                      </div>
                    </div>
                    <div>
                      <label className="input-label">Work Title</label>
                      <Input
                        placeholder="Work Title"
                        value={rep.work_title}
                        onChange={(e) => updateRepresentative(index, 'work_title', e.target.value)}
                      />
                    </div>
                    
                    {/* Login Credentials */}
                    <div className="pt-2 border-t border-border/50">
                      <p className="text-xs font-medium text-muted-foreground mb-2">Login Credentials</p>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="input-label">Username</label>
                          <Input
                            value={rep.login_username}
                            onChange={(e) => updateRepresentative(index, 'login_username', e.target.value)}
                            placeholder="username"
                            className="font-mono text-sm"
                          />
                        </div>
                        <div>
                          <label className="input-label">Password</label>
                          <div className="flex gap-1">
                            <Input
                              value={rep.login_password}
                              onChange={(e) => updateRepresentative(index, 'login_password', e.target.value)}
                              placeholder="password"
                              className="font-mono text-sm"
                            />
                            <Button
                              type="button"
                              variant="outline"
                              size="icon"
                              onClick={() => regeneratePassword(index)}
                              title="Generate new password"
                            >
                              <RefreshCw className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={addRepresentative}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Another Representative
                </Button>
              </div>
            </div>

            <div>
              <label className="input-label">Notes</label>
              <Textarea
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                placeholder="Additional notes about the client..."
                rows={2}
              />
            </div>

            {/* Extended Fields Toggle */}
            <Button
              type="button"
              variant="outline"
              className="w-full"
              onClick={() => setShowExtended(!showExtended)}
            >
              {showExtended ? (
                <>
                  <ChevronUp className="w-4 h-4 mr-2" />
                  Hide Extended Information
                </>
              ) : (
                <>
                  <ChevronDown className="w-4 h-4 mr-2" />
                  Show Extended Information
                </>
              )}
            </Button>

            {showExtended && (
              <div className="space-y-4 pt-4 border-t border-border">
                <h4 className="text-sm font-semibold text-muted-foreground">Business Details</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="input-label">Website</label>
                    <Input
                      value={form.website}
                      onChange={(e) => setForm({ ...form, website: e.target.value })}
                      placeholder="https://example.com"
                    />
                  </div>
                  <div>
                    <label className="input-label">Tax ID (OIB)</label>
                    <Input
                      value={form.tax_id}
                      onChange={(e) => setForm({ ...form, tax_id: e.target.value })}
                      placeholder="12345678901"
                    />
                  </div>
                </div>
                <div>
                  <label className="input-label">Founders / Members</label>
                  <Textarea
                    value={form.founders_members}
                    onChange={(e) => setForm({ ...form, founders_members: e.target.value })}
                    placeholder="List founders and members..."
                    rows={2}
                  />
                </div>

                <h4 className="text-sm font-semibold text-muted-foreground pt-2">Address</h4>
                <div>
                  <label className="input-label">Address Line</label>
                  <Input
                    value={form.address_line}
                    onChange={(e) => setForm({ ...form, address_line: e.target.value })}
                    placeholder="Ilica 123"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="input-label">City</label>
                    <Input
                      value={form.city}
                      onChange={(e) => setForm({ ...form, city: e.target.value })}
                      placeholder="Zagreb"
                    />
                  </div>
                  <div>
                    <label className="input-label">Postal Code</label>
                    <Input
                      value={form.postal_code}
                      onChange={(e) => setForm({ ...form, postal_code: e.target.value })}
                      placeholder="10000"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="input-label">State</label>
                    <Input
                      value={form.state}
                      onChange={(e) => setForm({ ...form, state: e.target.value })}
                      placeholder="Grad Zagreb"
                    />
                  </div>
                  <div>
                    <label className="input-label">Country</label>
                    <Input
                      value={form.country}
                      onChange={(e) => setForm({ ...form, country: e.target.value })}
                      placeholder="Hrvatska"
                    />
                  </div>
                </div>
              </div>
            )}

            <div className="flex justify-end gap-3 pt-4 border-t border-border">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="btn-primary-gradient" 
                disabled={createClient.isPending || !hasValidRepresentative}
              >
                {createClient.isPending ? 'Creating...' : 'Create Client'}
              </Button>
            </div>
          </form>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};
