import { useState, useRef, useEffect, forwardRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Upload, X, Loader2, Image as ImageIcon, Palette, Clock } from 'lucide-react';
import { extractColorsFromImage, getMostVibrantColor, makePastel } from '@/lib/colorUtils';

interface LogoUploaderProps {
  currentLogoUrl?: string | null;
  currentAccentColor?: string | null;
  pendingLogoUrl?: string | null;
  onLogoChange: (logoUrl: string | null) => void;
  onAccentColorChange?: (color: string | null) => void;
  onPendingLogoChange?: (logoUrl: string | null) => void;
  clientId: string;
  /** If true, directly save to database instead of just updating form state */
  saveDirectly?: boolean;
  /** If true, changes go through approval workflow (for clients) */
  requiresApproval?: boolean;
}

export const LogoUploader = forwardRef<HTMLDivElement, LogoUploaderProps>(({
  currentLogoUrl,
  currentAccentColor,
  pendingLogoUrl,
  onLogoChange,
  onAccentColorChange,
  onPendingLogoChange,
  clientId,
  saveDirectly = false,
  requiresApproval = false,
}, ref) => {
  const [isUploading, setIsUploading] = useState(false);
  const [isExtracting, setIsExtracting] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(currentLogoUrl || null);
  const [extractedColors, setExtractedColors] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Sync previewUrl with currentLogoUrl prop changes
  useEffect(() => {
    setPreviewUrl(currentLogoUrl || null);
  }, [currentLogoUrl]);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: 'Invalid file type',
        description: 'Please select an image file (PNG, JPG, SVG, etc.)',
        variant: 'destructive',
      });
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: 'File too large',
        description: 'Please select an image under 5MB',
        variant: 'destructive',
      });
      return;
    }

    setIsUploading(true);

    try {
      // Generate unique filename
      const fileExt = file.name.split('.').pop();
      const fileName = `${clientId}/${Date.now()}.${fileExt}`;

      // Determine which bucket to use
      const bucketName = requiresApproval ? 'pending-logos' : 'client-logos';

      // Upload to Supabase Storage
      const { error: uploadError } = await supabase.storage
        .from(bucketName)
        .upload(fileName, file, { upsert: true });

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from(bucketName)
        .getPublicUrl(fileName);

      // Extract colors from the uploaded image
      setIsExtracting(true);
      let pastelColor: string | null = null;
      try {
        const colors = await extractColorsFromImage(publicUrl);
        setExtractedColors(colors);

        // Auto-select the most vibrant color and make it pastel
        const vibrant = getMostVibrantColor(colors);
        if (vibrant) {
          pastelColor = makePastel(vibrant);
          onAccentColorChange?.(pastelColor);
        }
      } catch (colorError) {
        console.error('Error extracting colors:', colorError);
        // Non-critical, continue without colors
      }
      setIsExtracting(false);

      if (requiresApproval) {
        // For clients: store as pending, don't update the main logo
        if (onPendingLogoChange) {
          onPendingLogoChange(publicUrl);
        }
        
        // Update the pending_logo_url in the client record
        const { error: updateError } = await supabase
          .from('clients')
          .update({ pending_logo_url: publicUrl })
          .eq('id', clientId);

        if (updateError) {
          console.error('Error saving pending logo:', updateError);
        }

        toast({
          title: 'Logo uploaded',
          description: 'Your logo has been submitted for approval.',
        });
      } else {
        // For superusers: direct update
        setPreviewUrl(publicUrl);
        onLogoChange(publicUrl);

        if (saveDirectly && clientId) {
          const { error: updateError } = await supabase
            .from('clients')
            .update({ 
              logo_url: publicUrl,
              accent_color: pastelColor || currentAccentColor
            })
            .eq('id', clientId);

          if (updateError) {
            console.error('Error saving logo to database:', updateError);
            toast({
              title: 'Warning',
              description: 'Logo uploaded but failed to save to profile.',
              variant: 'destructive',
            });
          }
        }

        toast({
          title: 'Logo uploaded',
          description: 'Your company logo has been uploaded successfully.',
        });
      }
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: 'Upload failed',
        description: 'Failed to upload logo. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleRemoveLogo = async () => {
    setPreviewUrl(null);
    setExtractedColors([]);
    onLogoChange(null);
    onAccentColorChange?.(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }

    // If saveDirectly is true, update the client record immediately
    if (saveDirectly && clientId && !requiresApproval) {
      const { error: updateError } = await supabase
        .from('clients')
        .update({ 
          logo_url: null,
          accent_color: null
        })
        .eq('id', clientId);

      if (updateError) {
        console.error('Error removing logo from database:', updateError);
      }
    }
  };

  const selectColor = async (color: string) => {
    const pastelColor = makePastel(color);
    onAccentColorChange?.(pastelColor);

    // If saveDirectly is true and not requiring approval, update the client record immediately
    if (saveDirectly && clientId && !requiresApproval) {
      const { error: updateError } = await supabase
        .from('clients')
        .update({ accent_color: pastelColor })
        .eq('id', clientId);

      if (updateError) {
        console.error('Error saving accent color to database:', updateError);
      }
    }
  };

  return (
    <div ref={ref} className="space-y-4">
      {/* Pending Logo Notice */}
      {pendingLogoUrl && (
        <div className="flex items-center gap-3 p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg">
          <Clock className="w-5 h-5 text-amber-500 shrink-0" />
          <div className="flex-1">
            <p className="text-sm font-medium text-amber-600 dark:text-amber-400">Logo Pending Approval</p>
            <p className="text-xs text-muted-foreground">Your new logo is waiting for administrator approval.</p>
          </div>
          <img
            src={pendingLogoUrl}
            alt="Pending logo"
            className="w-12 h-12 object-contain rounded border"
          />
        </div>
      )}

      {/* Logo Preview / Upload Area */}
      <div className="flex items-start gap-4">
        <div className="relative">
          {previewUrl ? (
            <div className="w-24 h-24 rounded-xl border-2 border-border bg-muted overflow-hidden relative group">
              <img
                src={previewUrl}
                alt="Company logo"
                className="w-full h-full object-contain p-2"
              />
              {!requiresApproval && (
                <button
                  onClick={handleRemoveLogo}
                  className="absolute top-1 right-1 w-6 h-6 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          ) : (
            <label className="w-24 h-24 rounded-xl border-2 border-dashed border-border bg-muted/50 flex flex-col items-center justify-center cursor-pointer hover:border-primary/50 hover:bg-muted transition-colors">
              {isUploading ? (
                <Loader2 className="w-6 h-6 text-muted-foreground animate-spin" />
              ) : (
                <>
                  <ImageIcon className="w-6 h-6 text-muted-foreground mb-1" />
                  <span className="text-xs text-muted-foreground">Upload</span>
                </>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileSelect}
                className="hidden"
                disabled={isUploading}
              />
            </label>
          )}
        </div>

        <div className="flex-1 space-y-2">
          <p className="text-sm text-muted-foreground">
            Upload your company logo. Recommended size: 400x400px or larger.
            {requiresApproval && ' Changes require administrator approval.'}
          </p>
          {!previewUrl && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
            >
              <Upload className="w-4 h-4 mr-2" />
              Choose File
            </Button>
          )}
          {previewUrl && !requiresApproval && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
            >
              <Upload className="w-4 h-4 mr-2" />
              Replace Logo
            </Button>
          )}
          {previewUrl && requiresApproval && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
            >
              <Upload className="w-4 h-4 mr-2" />
              Upload New Logo (Requires Approval)
            </Button>
          )}
        </div>
      </div>

      {/* Color Extraction - Only show for superusers (not requiring approval) */}
      {previewUrl && !requiresApproval && (
        <div className="p-4 rounded-lg bg-muted/50 border space-y-3">
          <div className="flex items-center gap-2">
            <Palette className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm font-medium">Accent Color</span>
            {isExtracting && <Loader2 className="w-3 h-3 animate-spin text-muted-foreground" />}
          </div>

          {extractedColors.length > 0 && (
            <div className="space-y-2">
              <p className="text-xs text-muted-foreground">
                Colors extracted from your logo (click to select):
              </p>
              <div className="flex gap-2 flex-wrap">
                {extractedColors.map((color, idx) => (
                  <button
                    key={idx}
                    onClick={() => selectColor(color)}
                    className="w-8 h-8 rounded-lg border-2 border-transparent hover:border-primary transition-colors shadow-sm"
                    style={{ backgroundColor: color }}
                    title={color}
                  />
                ))}
              </div>
            </div>
          )}

          {currentAccentColor && (
            <div className="flex items-center gap-3 pt-2 border-t">
              <span className="text-xs text-muted-foreground">Selected (pastel):</span>
              <div className="flex items-center gap-2">
                <div
                  className="w-8 h-8 rounded-lg border shadow-sm"
                  style={{ backgroundColor: currentAccentColor }}
                />
                <code className="text-xs bg-background px-2 py-1 rounded border">
                  {currentAccentColor}
                </code>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
});

LogoUploader.displayName = 'LogoUploader';

export default LogoUploader;
