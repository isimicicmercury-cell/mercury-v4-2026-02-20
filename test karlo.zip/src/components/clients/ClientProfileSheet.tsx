import { useState } from 'react';
import { Client, useUpdateClient, Representative } from '@/hooks/useClients';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { Separator } from '@/components/ui/separator';
import { Plus, Trash2, Building2, Globe, MapPin, FileText, Users, Briefcase, Pencil, Save, X } from 'lucide-react';

interface ClientProfileSheetProps {
  client: Client | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

/** Helper to get display name from representative (supports legacy full_name) */
const getRepName = (rep: any): string => {
  if (rep.first_name || rep.last_name) {
    return `${rep.first_name || ''} ${rep.last_name || ''}`.trim();
  }
  return rep.full_name || '—';
};

export const ClientProfileSheet = ({ client, open, onOpenChange }: ClientProfileSheetProps) => {
  const updateClient = useUpdateClient();
  const [isEditing, setIsEditing] = useState(false);
  const [form, setForm] = useState<Partial<Client>>({});

  const handleOpenChange = (newOpen: boolean) => {
    if (!newOpen) {
      setIsEditing(false);
    }
    onOpenChange(newOpen);
  };

  const startEditing = () => {
    if (client) {
      setForm({
        company_name: client.company_name,
        contact_name: client.contact_name,
        contact_email: client.contact_email,
        phone: client.phone,
        notes: client.notes,
        login_username: client.login_username,
        login_password: client.login_password,
        founders_members: client.founders_members,
        representatives: client.representatives || [],
        website: client.website,
        tax_id: client.tax_id,
        country: client.country,
        state: client.state,
        city: client.city,
        postal_code: client.postal_code,
        address_line: client.address_line,
      });
      setIsEditing(true);
    }
  };

  const cancelEditing = () => {
    setIsEditing(false);
    setForm({});
  };

  const handleSave = async () => {
    if (!client) return;
    await updateClient.mutateAsync({ id: client.id, ...form });
    setIsEditing(false);
  };

  const addRepresentative = () => {
    const reps = (form.representatives || []) as Representative[];
    setForm({
      ...form,
      representatives: [...reps, { first_name: '', last_name: '', email: '', phone: '', work_title: '' }],
    });
  };

  const updateRepresentative = (index: number, field: keyof Representative, value: string) => {
    const reps = [...((form.representatives || []) as Representative[])];
    reps[index] = { ...reps[index], [field]: value };
    setForm({ ...form, representatives: reps });
  };

  const removeRepresentative = (index: number) => {
    const reps = [...((form.representatives || []) as Representative[])];
    reps.splice(index, 1);
    setForm({ ...form, representatives: reps });
  };

  if (!client) return null;

  const displayData = isEditing ? form : client;
  const representatives = (displayData.representatives || []) as Representative[];

  return (
    <Sheet open={open} onOpenChange={handleOpenChange}>
      <SheetContent className="w-full sm:max-w-xl overflow-y-auto">
        <SheetHeader className="pb-4">
          <div className="flex items-center justify-between">
            <SheetTitle className="flex items-center gap-2">
              <Building2 className="w-5 h-5" />
              {isEditing ? 'Edit Client' : 'Client Profile'}
            </SheetTitle>
            {!isEditing ? (
              <Button variant="outline" size="sm" onClick={startEditing}>
                <Pencil className="w-4 h-4 mr-2" />
                Edit
              </Button>
            ) : (
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={cancelEditing}>
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
                <Button size="sm" onClick={handleSave} disabled={updateClient.isPending}>
                  <Save className="w-4 h-4 mr-2" />
                  {updateClient.isPending ? 'Saving...' : 'Save'}
                </Button>
              </div>
            )}
          </div>
        </SheetHeader>

        <div className="space-y-6">
          {/* Basic Information */}
          <section>
            <h3 className="text-sm font-semibold text-muted-foreground mb-3 flex items-center gap-2">
              <Building2 className="w-4 h-4" />
              Basic Information
            </h3>
            <div className="space-y-3">
              <div>
                <label className="input-label">Company Name</label>
                {isEditing ? (
                  <Input value={form.company_name || ''} onChange={(e) => setForm({ ...form, company_name: e.target.value })} />
                ) : (
                  <p className="text-foreground">{client.company_name}</p>
                )}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="input-label">Contact Name</label>
                  {isEditing ? (
                    <Input value={form.contact_name || ''} onChange={(e) => setForm({ ...form, contact_name: e.target.value })} />
                  ) : (
                    <p className="text-foreground">{client.contact_name || '—'}</p>
                  )}
                </div>
                <div>
                  <label className="input-label">Contact Email</label>
                  {isEditing ? (
                    <Input type="email" value={form.contact_email || ''} onChange={(e) => setForm({ ...form, contact_email: e.target.value })} />
                  ) : (
                    <p className="text-foreground">{client.contact_email || '—'}</p>
                  )}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="input-label">Phone</label>
                  {isEditing ? (
                    <Input value={form.phone || ''} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                  ) : (
                    <p className="text-foreground">{client.phone || '—'}</p>
                  )}
                </div>
                <div>
                  <label className="input-label flex items-center gap-1"><Globe className="w-3 h-3" />Website</label>
                  {isEditing ? (
                    <Input value={form.website || ''} onChange={(e) => setForm({ ...form, website: e.target.value })} placeholder="https://example.com" />
                  ) : (
                    <p className="text-foreground">{client.website ? <a href={client.website} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">{client.website}</a> : '—'}</p>
                  )}
                </div>
              </div>
              <div>
                <label className="input-label flex items-center gap-1"><FileText className="w-3 h-3" />Tax ID (OIB)</label>
                {isEditing ? (
                  <Input value={form.tax_id || ''} onChange={(e) => setForm({ ...form, tax_id: e.target.value })} />
                ) : (
                  <p className="text-foreground">{client.tax_id || '—'}</p>
                )}
              </div>
            </div>
          </section>

          <Separator />

          {/* Founders/Members */}
          <section>
            <h3 className="text-sm font-semibold text-muted-foreground mb-3 flex items-center gap-2"><Users className="w-4 h-4" />Osnivači / Članovi</h3>
            {isEditing ? (
              <Textarea value={form.founders_members || ''} onChange={(e) => setForm({ ...form, founders_members: e.target.value })} placeholder="List founders and members..." rows={3} />
            ) : (
              <p className="text-foreground whitespace-pre-wrap">{client.founders_members || '—'}</p>
            )}
          </section>

          <Separator />

          {/* Representatives */}
          <section>
            <h3 className="text-sm font-semibold text-muted-foreground mb-3 flex items-center gap-2"><Briefcase className="w-4 h-4" />Zastupnici</h3>
            {representatives.length === 0 && !isEditing ? (
              <p className="text-muted-foreground text-sm">No representatives added</p>
            ) : (
              <div className="space-y-3">
                {representatives.map((rep, index) => (
                  <div key={index} className="p-3 border border-border rounded-lg bg-muted/30">
                    {isEditing ? (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-medium text-muted-foreground">Representative {index + 1}</span>
                          <Button type="button" variant="ghost" size="icon" className="h-6 w-6 text-destructive hover:text-destructive" onClick={() => removeRepresentative(index)}>
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <Input placeholder="First Name" value={rep.first_name || (rep as any).full_name || ''} onChange={(e) => updateRepresentative(index, 'first_name', e.target.value)} />
                          <Input placeholder="Last Name" value={rep.last_name || ''} onChange={(e) => updateRepresentative(index, 'last_name', e.target.value)} />
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <Input placeholder="Email" type="email" value={rep.email} onChange={(e) => updateRepresentative(index, 'email', e.target.value)} />
                          <Input placeholder="Phone" value={rep.phone} onChange={(e) => updateRepresentative(index, 'phone', e.target.value)} />
                        </div>
                        <Input placeholder="Work Title" value={rep.work_title} onChange={(e) => updateRepresentative(index, 'work_title', e.target.value)} />
                      </div>
                    ) : (
                      <div>
                        <p className="font-medium">{getRepName(rep)}</p>
                        <p className="text-sm text-muted-foreground">{rep.work_title || '—'}</p>
                        <div className="flex gap-4 mt-1 text-sm">
                          <span>{rep.email || '—'}</span>
                          <span>{rep.phone || '—'}</span>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
                {isEditing && (
                  <Button type="button" variant="outline" size="sm" onClick={addRepresentative} className="w-full">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Representative
                  </Button>
                )}
              </div>
            )}
          </section>

          <Separator />

          {/* Address */}
          <section>
            <h3 className="text-sm font-semibold text-muted-foreground mb-3 flex items-center gap-2"><MapPin className="w-4 h-4" />Address</h3>
            <div className="space-y-3">
              <div>
                <label className="input-label">Address Line</label>
                {isEditing ? <Input value={form.address_line || ''} onChange={(e) => setForm({ ...form, address_line: e.target.value })} /> : <p className="text-foreground">{client.address_line || '—'}</p>}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="input-label">City</label>{isEditing ? <Input value={form.city || ''} onChange={(e) => setForm({ ...form, city: e.target.value })} /> : <p className="text-foreground">{client.city || '—'}</p>}</div>
                <div><label className="input-label">Postal Code</label>{isEditing ? <Input value={form.postal_code || ''} onChange={(e) => setForm({ ...form, postal_code: e.target.value })} /> : <p className="text-foreground">{client.postal_code || '—'}</p>}</div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="input-label">State</label>{isEditing ? <Input value={form.state || ''} onChange={(e) => setForm({ ...form, state: e.target.value })} /> : <p className="text-foreground">{client.state || '—'}</p>}</div>
                <div><label className="input-label">Country</label>{isEditing ? <Input value={form.country || ''} onChange={(e) => setForm({ ...form, country: e.target.value })} /> : <p className="text-foreground">{client.country || '—'}</p>}</div>
              </div>
            </div>
          </section>

          <Separator />

          {/* Login Credentials */}
          <section>
            <h3 className="text-sm font-semibold text-muted-foreground mb-3">Login Credentials</h3>
            <div className="grid grid-cols-2 gap-4">
              <div><label className="input-label">Username</label>{isEditing ? <Input value={form.login_username || ''} onChange={(e) => setForm({ ...form, login_username: e.target.value })} /> : <code className="px-2 py-1 bg-muted rounded text-sm font-mono">{client.login_username}</code>}</div>
              <div><label className="input-label">Password</label>{isEditing ? <Input value={form.login_password || ''} onChange={(e) => setForm({ ...form, login_password: e.target.value })} /> : <code className="px-2 py-1 bg-muted rounded text-sm font-mono">{client.login_password}</code>}</div>
            </div>
          </section>

          <Separator />

          {/* Notes */}
          <section>
            <h3 className="text-sm font-semibold text-muted-foreground mb-3">Notes</h3>
            {isEditing ? <Textarea value={form.notes || ''} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={3} /> : <p className="text-foreground whitespace-pre-wrap">{client.notes || '—'}</p>}
          </section>
        </div>
      </SheetContent>
    </Sheet>
  );
};
