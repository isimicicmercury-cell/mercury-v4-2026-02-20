import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface PipelineTemplate {
  id: string;
  name: string;
  description: string | null;
  is_active: boolean;
  created_at: string;
}

export interface PipelineStage {
  id: string;
  pipeline_template_id: string;
  name: string;
  stage_type: string;
  position: number;
  is_required: boolean;
  can_client_advance: boolean;
  created_at: string;
}

export interface ClientPipelineAssignment {
  id: string;
  client_id: string;
  pipeline_template_id: string;
  created_at: string;
  pipeline_template?: PipelineTemplate;
}

export interface CandidatePipelineState {
  id: string;
  candidate_id: string;
  pipeline_template_id: string;
  current_stage_id: string;
  status: string;
  entered_stage_at: string;
  updated_at: string;
}

export interface CandidateStageHistory {
  id: string;
  candidate_id: string;
  from_stage_id: string | null;
  to_stage_id: string;
  changed_by_user_id: string | null;
  note: string | null;
  changed_at: string;
}

// ─── Pipeline Templates ───

export const usePipelineTemplates = () => {
  return useQuery({
    queryKey: ['pipeline-templates'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('pipeline_templates')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data as PipelineTemplate[];
    },
  });
};

export const useCreatePipelineTemplate = () => {
  const qc = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (template: { name: string; description?: string }) => {
      const { data, error } = await supabase
        .from('pipeline_templates')
        .insert(template)
        .select()
        .single();
      if (error) throw error;
      return data as PipelineTemplate;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['pipeline-templates'] });
      toast({ title: 'Pipeline created', description: 'New pipeline template has been created.' });
    },
    onError: (e) => toast({ title: 'Error', description: e.message, variant: 'destructive' }),
  });
};

export const useUpdatePipelineTemplate = () => {
  const qc = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<PipelineTemplate> & { id: string }) => {
      const { data, error } = await supabase
        .from('pipeline_templates')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['pipeline-templates'] });
      toast({ title: 'Pipeline updated' });
    },
    onError: (e) => toast({ title: 'Error', description: e.message, variant: 'destructive' }),
  });
};

export const useDeletePipelineTemplate = () => {
  const qc = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('pipeline_templates').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['pipeline-templates'] });
      toast({ title: 'Pipeline deleted' });
    },
    onError: (e) => toast({ title: 'Error', description: e.message, variant: 'destructive' }),
  });
};

// ─── Pipeline Stages ───

export const usePipelineStages = (templateId: string | null) => {
  return useQuery({
    queryKey: ['pipeline-stages', templateId],
    queryFn: async () => {
      if (!templateId) return [];
      const { data, error } = await supabase
        .from('pipeline_stages')
        .select('*')
        .eq('pipeline_template_id', templateId)
        .order('position', { ascending: true });
      if (error) throw error;
      return data as PipelineStage[];
    },
    enabled: !!templateId,
  });
};

export const useSavePipelineStages = () => {
  const qc = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async ({ templateId, stages }: { templateId: string; stages: Omit<PipelineStage, 'id' | 'created_at' | 'pipeline_template_id'>[] }) => {
      // Delete all existing stages and re-insert
      const { error: delErr } = await supabase
        .from('pipeline_stages')
        .delete()
        .eq('pipeline_template_id', templateId);
      if (delErr) throw delErr;

      if (stages.length === 0) return [];

      const rows = stages.map((s, i) => ({
        pipeline_template_id: templateId,
        name: s.name,
        stage_type: s.stage_type,
        position: i + 1,
        is_required: s.is_required,
        can_client_advance: s.can_client_advance,
      }));

      const { data, error } = await supabase
        .from('pipeline_stages')
        .insert(rows)
        .select();
      if (error) throw error;
      return data;
    },
    onSuccess: (_, vars) => {
      qc.invalidateQueries({ queryKey: ['pipeline-stages', vars.templateId] });
      toast({ title: 'Stages saved', description: 'Pipeline stages have been updated.' });
    },
    onError: (e) => toast({ title: 'Error', description: e.message, variant: 'destructive' }),
  });
};

// ─── Client Pipeline Assignment ───

export const useClientPipelineAssignment = (clientId: string | null) => {
  return useQuery({
    queryKey: ['client-pipeline-assignment', clientId],
    queryFn: async () => {
      if (!clientId) return null;
      // Return first one for backward compatibility
      const { data, error } = await supabase
        .from('client_pipeline_assignment')
        .select('*, pipeline_template:pipeline_templates(*)')
        .eq('client_id', clientId)
        .order('created_at', { ascending: true })
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      return data as (ClientPipelineAssignment & { pipeline_template: PipelineTemplate }) | null;
    },
    enabled: !!clientId,
  });
};

// Returns ALL pipeline assignments for a company (multiple pipelines)
export const useCompanyPipelineAssignments = (companyName: string | null) => {
  return useQuery({
    queryKey: ['company-pipeline-assignments', companyName],
    queryFn: async () => {
      if (!companyName) return [];

      // Get all client IDs for this company
      const { data: companyClients, error: companyError } = await supabase
        .from('clients')
        .select('id')
        .eq('company_name', companyName);

      if (companyError || !companyClients) return [];
      const companyClientIds = companyClients.map(c => c.id);

      // Get all pipeline assignments for all reps in this company
      const { data, error } = await supabase
        .from('client_pipeline_assignment')
        .select('*, pipeline_template:pipeline_templates(*)')
        .in('client_id', companyClientIds)
        .order('created_at', { ascending: true });

      if (error) throw error;

      // Deduplicate by pipeline_template_id (same pipeline may be assigned to multiple reps)
      const seen = new Set<string>();
      const deduplicated = (data || []).filter(a => {
        if (seen.has(a.pipeline_template_id)) return false;
        seen.add(a.pipeline_template_id);
        return true;
      });

      return deduplicated as (ClientPipelineAssignment & { pipeline_template: PipelineTemplate })[];
    },
    enabled: !!companyName,
  });
};

export const useAssignClientPipeline = () => {
  const qc = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async ({ clientId, pipelineTemplateId, companyName }: { clientId: string; pipelineTemplateId: string; companyName?: string }) => {
      // If companyName provided, assign to ALL reps in the company
      let clientIds = [clientId];
      if (companyName) {
        const { data: companyClients } = await supabase
          .from('clients')
          .select('id')
          .eq('company_name', companyName);
        if (companyClients) {
          clientIds = companyClients.map(c => c.id);
        }
      }

      for (const cid of clientIds) {
        // Check if this specific pipeline is already assigned to this client
        const { data: existing } = await supabase
          .from('client_pipeline_assignment')
          .select('id')
          .eq('client_id', cid)
          .eq('pipeline_template_id', pipelineTemplateId)
          .maybeSingle();

        if (!existing) {
          const { error } = await supabase
            .from('client_pipeline_assignment')
            .insert({ client_id: cid, pipeline_template_id: pipelineTemplateId });
          if (error) throw error;
        }
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['client-pipeline-assignment'] });
      qc.invalidateQueries({ queryKey: ['company-pipeline-assignments'] });
      toast({ title: 'Pipeline assigned', description: 'Company pipeline has been updated.' });
    },
    onError: (e) => toast({ title: 'Error', description: e.message, variant: 'destructive' }),
  });
};

export const useRemoveClientPipeline = () => {
  const qc = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async ({ clientId, pipelineTemplateId, companyName }: { clientId: string; pipelineTemplateId?: string; companyName?: string }) => {
      // If companyName provided, remove from ALL reps in the company
      let clientIds = [clientId];
      if (companyName) {
        const { data: companyClients } = await supabase
          .from('clients')
          .select('id')
          .eq('company_name', companyName);
        if (companyClients) {
          clientIds = companyClients.map(c => c.id);
        }
      }

      for (const cid of clientIds) {
        let query = supabase
          .from('client_pipeline_assignment')
          .delete()
          .eq('client_id', cid);
        if (pipelineTemplateId) {
          query = query.eq('pipeline_template_id', pipelineTemplateId);
        }
        const { error } = await query;
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['client-pipeline-assignment'] });
      qc.invalidateQueries({ queryKey: ['company-pipeline-assignments'] });
      toast({ title: 'Pipeline removed' });
    },
    onError: (e) => toast({ title: 'Error', description: e.message, variant: 'destructive' }),
  });
};

// ─── Candidate Pipeline State ───

export const useCandidatePipelineState = (candidateId: string | null) => {
  return useQuery({
    queryKey: ['candidate-pipeline-state', candidateId],
    queryFn: async () => {
      if (!candidateId) return null;
      const { data, error } = await supabase
        .from('candidate_pipeline_state')
        .select('*')
        .eq('candidate_id', candidateId)
        .maybeSingle();
      if (error) throw error;
      return data as CandidatePipelineState | null;
    },
    enabled: !!candidateId,
  });
};

export const useCandidateStageHistory = (candidateId: string | null) => {
  return useQuery({
    queryKey: ['candidate-stage-history', candidateId],
    queryFn: async () => {
      if (!candidateId) return [];
      const { data, error } = await supabase
        .from('candidate_stage_history')
        .select('*')
        .eq('candidate_id', candidateId)
        .order('changed_at', { ascending: true });
      if (error) throw error;
      return data as CandidateStageHistory[];
    },
    enabled: !!candidateId,
  });
};

export const useAdvanceCandidateStage = () => {
  const qc = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async ({ candidateId, note, skip }: { candidateId: string; note?: string; skip?: boolean }) => {
      const { data, error } = await supabase.rpc('advance_candidate_stage', {
        p_candidate_id: candidateId,
        p_note: note || null,
        p_skip: skip || false,
      });
      if (error) throw error;
      const result = data as unknown as { success: boolean; error?: string; to_stage?: string };
      if (!result.success) throw new Error(result.error || 'Failed to advance stage');
      return result;
    },
    onSuccess: (data, vars) => {
      qc.invalidateQueries({ queryKey: ['candidate-pipeline-state', vars.candidateId] });
      qc.invalidateQueries({ queryKey: ['candidate-stage-history', vars.candidateId] });
      qc.invalidateQueries({ queryKey: ['pipeline-kanban'] });
      toast({ title: 'Stage advanced', description: `Moved to ${(data as any).to_stage}` });
    },
    onError: (e) => toast({ title: 'Cannot advance', description: e.message, variant: 'destructive' }),
  });
};

export const useUpdateCandidatePipelineStatus = () => {
  const qc = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async ({ candidateId, status, note }: { candidateId: string; status: string; note?: string }) => {
      const { data, error } = await supabase.rpc('update_candidate_pipeline_status', {
        p_candidate_id: candidateId,
        p_status: status,
        p_note: note || null,
      });
      if (error) throw error;
      if (!data) throw new Error('Failed to update status');
    },
    onSuccess: (_, vars) => {
      qc.invalidateQueries({ queryKey: ['candidate-pipeline-state', vars.candidateId] });
      qc.invalidateQueries({ queryKey: ['candidate-stage-history', vars.candidateId] });
      qc.invalidateQueries({ queryKey: ['pipeline-kanban'] });
      toast({ title: 'Status updated', description: `Candidate status set to ${vars.status}` });
    },
    onError: (e) => toast({ title: 'Error', description: e.message, variant: 'destructive' }),
  });
};

// ─── Kanban Data ───

export const usePipelineKanban = (templateId: string | null, clientId?: string | null) => {
  return useQuery({
    queryKey: ['pipeline-kanban', templateId, clientId],
    queryFn: async () => {
      if (!templateId) return { stages: [], candidates: [] };

      const { data: stages, error: stagesErr } = await supabase
        .from('pipeline_stages')
        .select('*')
        .eq('pipeline_template_id', templateId)
        .order('position', { ascending: true });
      if (stagesErr) throw stagesErr;

      let query = supabase
        .from('candidate_pipeline_state')
        .select('*, candidate:candidates(id, full_name, candidate_code, profile_picture_url, email, status)')
        .eq('pipeline_template_id', templateId)
        .eq('status', 'active');

      const { data: states, error: statesErr } = await query;
      if (statesErr) throw statesErr;

      return {
        stages: stages as PipelineStage[],
        candidates: states as (CandidatePipelineState & { candidate: { id: string; full_name: string; candidate_code: string; profile_picture_url: string | null; email: string | null; status: string } })[],
      };
    },
    enabled: !!templateId,
  });
};
