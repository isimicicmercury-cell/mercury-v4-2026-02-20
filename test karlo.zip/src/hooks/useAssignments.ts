import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useEffect } from 'react';

import { Candidate } from './useCandidates';

export interface Assignment {
  id: string;
  candidate_id: string;
  client_id: string;
  assigned_at: string;
  status: string;
  candidate?: Candidate;
  client?: {
    id: string;
    company_name: string;
    contact_name: string | null;
  };
}

export const useAssignments = () => {
  return useQuery({
    queryKey: ['assignments'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('candidate_assignments')
        .select(`
          *,
          candidate:candidates(*),
          client:clients(id, company_name, contact_name)
        `)
        .order('assigned_at', { ascending: false });

      if (error) throw error;
      return data as unknown as Assignment[];
    },
  });
};

// Fetches assignments for ALL reps in the same company (not just the individual client_id)
export const useClientAssignments = (clientId: string | null) => {
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!clientId) return;

    const channel = supabase
      .channel('client-assignments')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'candidate_assignments',
        },
        () => {
          queryClient.invalidateQueries({ queryKey: ['client-assignments', clientId] });
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'candidates',
        },
        () => {
          queryClient.invalidateQueries({ queryKey: ['client-assignments', clientId] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [clientId, queryClient]);

  return useQuery({
    queryKey: ['client-assignments', clientId],
    queryFn: async () => {
      if (!clientId) return [];

      // First get the company_name for this client
      const { data: clientData, error: clientError } = await supabase
        .from('clients')
        .select('company_name')
        .eq('id', clientId)
        .single();

      if (clientError || !clientData) return [];

      // Get all client IDs for this company
      const { data: companyClients, error: companyError } = await supabase
        .from('clients')
        .select('id')
        .eq('company_name', clientData.company_name);

      if (companyError || !companyClients) return [];

      const companyClientIds = companyClients.map(c => c.id);

      // Get assignments for ALL reps in this company, deduplicated by candidate_id
      const { data, error } = await supabase
        .from('candidate_assignments')
        .select(`
          *,
          candidate:candidates(*)
        `)
        .in('client_id', companyClientIds)
        .eq('status', 'pending')
        .order('assigned_at', { ascending: false });

      if (error) throw error;

      // Deduplicate by candidate_id (since same candidate may be assigned to multiple reps in same company)
      const seen = new Set<string>();
      const deduplicated = (data || []).filter(a => {
        if (seen.has(a.candidate_id)) return false;
        seen.add(a.candidate_id);
        return true;
      });

      return deduplicated as unknown as Assignment[];
    },
    enabled: !!clientId,
  });
};

export const useClientClaimedCandidates = (clientId: string | null) => {
  return useQuery({
    queryKey: ['client-claimed', clientId],
    queryFn: async () => {
      if (!clientId) return [];

      // First get the company_name for this client
      const { data: clientData, error: clientError } = await supabase
        .from('clients')
        .select('company_name')
        .eq('id', clientId)
        .single();

      if (clientError || !clientData) return [];

      // Get all client IDs for this company
      const { data: companyClients, error: companyError } = await supabase
        .from('clients')
        .select('id')
        .eq('company_name', clientData.company_name);

      if (companyError || !companyClients) return [];

      const companyClientIds = companyClients.map(c => c.id);

      // Get all candidates claimed by any rep in this company
      const { data, error } = await supabase
        .from('candidates')
        .select('*')
        .in('claimed_by_client_id', companyClientIds)
        .order('claimed_at', { ascending: false });

      if (error) throw error;
      return data;
    },
    enabled: !!clientId,
  });
};

export const useAssignCandidate = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ candidateId, clientIds }: { candidateId: string; clientIds: string[] }) => {
      const assignments = clientIds.map((clientId) => ({
        candidate_id: candidateId,
        client_id: clientId,
      }));

      const { data, error } = await supabase
        .from('candidate_assignments')
        .insert(assignments)
        .select();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['assignments'] });
      queryClient.invalidateQueries({ queryKey: ['candidates'] });
      toast({
        title: 'Candidate assigned',
        description: 'The candidate has been assigned to the selected clients.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
};

export const useClaimCandidate = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ candidateId, clientId, pipelineTemplateId }: { candidateId: string; clientId: string; pipelineTemplateId?: string }) => {
      // Claim the candidate via RPC
      const { data, error } = await supabase
        .rpc('claim_candidate', {
          p_candidate_id: candidateId,
          p_client_id: clientId,
        });

      if (error) throw error;
      if (!data) {
        throw new Error('This candidate has already been claimed by another client.');
      }

      // Get the company_name for this client
      const { data: clientData } = await supabase
        .from('clients')
        .select('company_name')
        .eq('id', clientId)
        .single();

      if (clientData) {
        // Get all client IDs for this company
        const { data: companyClients } = await supabase
          .from('clients')
          .select('id')
          .eq('company_name', clientData.company_name);

        if (companyClients) {
          const companyClientIds = companyClients.map(c => c.id);

          // Update ALL assignments for this candidate across the company to 'claimed'
          await supabase
            .from('candidate_assignments')
            .update({ status: 'claimed' })
            .eq('candidate_id', candidateId)
            .in('client_id', companyClientIds);
        }
      }

      // If a pipeline was selected, set up the candidate pipeline state
      if (pipelineTemplateId) {
        // Get the first stage of this pipeline
        const { data: stages } = await supabase
          .from('pipeline_stages')
          .select('id')
          .eq('pipeline_template_id', pipelineTemplateId)
          .order('position', { ascending: true })
          .limit(1);

        if (stages && stages.length > 0) {
          // Check if a pipeline state already exists
          const { data: existingState } = await supabase
            .from('candidate_pipeline_state')
            .select('id')
            .eq('candidate_id', candidateId)
            .maybeSingle();

          if (existingState) {
            await supabase
              .from('candidate_pipeline_state')
              .update({
                pipeline_template_id: pipelineTemplateId,
                current_stage_id: stages[0].id,
                status: 'active',
              })
              .eq('candidate_id', candidateId);
          } else {
            await supabase
              .from('candidate_pipeline_state')
              .insert({
                candidate_id: candidateId,
                pipeline_template_id: pipelineTemplateId,
                current_stage_id: stages[0].id,
                status: 'active',
              });
          }
        }
      }

      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['client-assignments'] });
      queryClient.invalidateQueries({ queryKey: ['client-claimed'] });
      queryClient.invalidateQueries({ queryKey: ['candidates'] });
      queryClient.invalidateQueries({ queryKey: ['pipeline-kanban'] });
      queryClient.invalidateQueries({ queryKey: ['candidate-pipeline-state'] });
      toast({
        title: 'Candidate claimed!',
        description: 'The candidate has been added to your hiring pipeline.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Unable to claim',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
};

export const useRejectCandidate = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ assignmentId }: { assignmentId: string }) => {
      // First, get the assignment details to find candidate_id and client_id
      const { data: assignment, error: fetchError } = await supabase
        .from('candidate_assignments')
        .select('candidate_id, client_id')
        .eq('id', assignmentId)
        .single();

      if (fetchError || !assignment) throw fetchError || new Error('Assignment not found');

      // Get the company_name for this client
      const { data: clientData } = await supabase
        .from('clients')
        .select('company_name')
        .eq('id', assignment.client_id)
        .single();

      if (clientData) {
        // Get all client IDs for this company
        const { data: companyClients } = await supabase
          .from('clients')
          .select('id')
          .eq('company_name', clientData.company_name);

        if (companyClients) {
          const companyClientIds = companyClients.map(c => c.id);

          // Update ALL assignments for this candidate across the entire company to 'rejected'
          await supabase
            .from('candidate_assignments')
            .update({ status: 'rejected' })
            .eq('candidate_id', assignment.candidate_id)
            .in('client_id', companyClientIds);
        }
      } else {
        // Fallback: just update the single assignment
        const { error } = await supabase
          .from('candidate_assignments')
          .update({ status: 'rejected' })
          .eq('id', assignmentId);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['client-assignments'] });
      toast({
        title: 'Candidate passed',
        description: 'The candidate has been removed from your company\'s pool.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
};

// Hook to get candidates assigned to a specific company (for superuser view)
export const useCompanyAssignments = (companyName: string | null) => {
  return useQuery({
    queryKey: ['company-assignments', companyName],
    queryFn: async () => {
      if (!companyName) return [];

      // Get all client IDs for this company
      const { data: companyClients, error: companyError } = await supabase
        .from('clients')
        .select('id')
        .eq('company_name', companyName);

      if (companyError || !companyClients) return [];

      const companyClientIds = companyClients.map(c => c.id);

      // Get all assignments for this company
      const { data, error } = await supabase
        .from('candidate_assignments')
        .select(`
          *,
          candidate:candidates(*)
        `)
        .in('client_id', companyClientIds)
        .order('assigned_at', { ascending: false });

      if (error) throw error;

      // Deduplicate by candidate_id
      const seen = new Set<string>();
      const deduplicated = (data || []).filter(a => {
        if (seen.has(a.candidate_id)) return false;
        seen.add(a.candidate_id);
        return true;
      });

      return deduplicated as unknown as Assignment[];
    },
    enabled: !!companyName,
  });
};
