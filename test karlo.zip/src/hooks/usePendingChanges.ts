import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import type { Json } from '@/integrations/supabase/types';
import { generateUsername, generatePassword } from '@/lib/croatianUtils';
import type { Representative } from '@/hooks/useClients';

export interface PendingChange {
  id: string;
  client_id: string;
  proposed_changes: Json;
  status: string;
  submitted_at: string;
  reviewed_at: string | null;
  reviewed_by: string | null;
  reviewer_notes: string | null;
  created_at: string;
  updated_at: string;
  client?: {
    id: string;
    company_name: string;
    contact_name: string | null;
    contact_email: string | null;
  };
}

export const usePendingChanges = () => {
  return useQuery({
    queryKey: ['pending-changes'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('client_pending_changes')
        .select(`
          *,
          client:clients(id, company_name, contact_name, contact_email)
        `)
        .eq('status', 'pending')
        .order('submitted_at', { ascending: false });

      if (error) throw error;
      return data as PendingChange[];
    },
  });
};

export const useClientPendingChanges = (clientId: string | null) => {
  return useQuery({
    queryKey: ['client-pending-changes', clientId],
    queryFn: async () => {
      if (!clientId) return [];
      const { data, error } = await supabase
        .from('client_pending_changes')
        .select('*')
        .eq('client_id', clientId)
        .order('submitted_at', { ascending: false });

      if (error) throw error;
      return data as PendingChange[];
    },
    enabled: !!clientId,
  });
};

export const useSubmitProfileChanges = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ clientId, proposedChanges }: { clientId: string; proposedChanges: Record<string, unknown> }) => {
      const { data, error } = await supabase
        .from('client_pending_changes')
        .insert({
          client_id: clientId,
          proposed_changes: proposedChanges as Json,
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['client-pending-changes'] });
      queryClient.invalidateQueries({ queryKey: ['pending-changes'] });
      toast({
        title: 'Changes submitted',
        description: 'Your profile changes have been submitted for approval.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
};

export const useApproveChanges = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ changeId, clientId, proposedChanges, clientEmail, companyName }: { 
      changeId: string; 
      clientId: string; 
      proposedChanges: Record<string, unknown>;
      clientEmail?: string | null;
      companyName?: string;
    }) => {
      // Handle logo approval if logo_url is in proposed changes
      if (proposedChanges.logo_url && typeof proposedChanges.logo_url === 'string') {
        // If it's a pending logo, we need to handle it specially
        const logoUrl = proposedChanges.logo_url as string;
        if (logoUrl.includes('pending-logos')) {
          // The logo is already uploaded, just update the URL
          // The pending_logo_url will be cleared below
        }
      }

      // Check if representatives were added - auto-create credentials for new ones
      if (proposedChanges.representatives && Array.isArray(proposedChanges.representatives)) {
        // Get current client data to compare
        const { data: currentClient } = await supabase
          .from('clients')
          .select('company_name, representatives')
          .eq('id', clientId)
          .single();

        if (currentClient) {
          const currentReps = (currentClient.representatives as unknown as Representative[]) || [];
          const proposedReps = proposedChanges.representatives as Representative[];
          
          // Find new representatives (ones not in current list by email)
          const currentEmails = new Set(currentReps.map(r => r.email?.toLowerCase()));
          const newReps = proposedReps.filter(r => r.email && !currentEmails.has(r.email.toLowerCase()));

          // Create auth users for new representatives
          for (const rep of newReps) {
            const repName = `${rep.first_name || ''} ${rep.last_name || ''}`.trim();
            const username = generateUsername(currentClient.company_name, repName, 0);
            const password = generatePassword();

            try {
              await supabase.functions.invoke('create-client', {
                body: {
                  company_name: currentClient.company_name,
                  contact_name: repName,
                  contact_email: rep.email,
                  phone: rep.phone || undefined,
                  login_username: username,
                  login_password: password,
                },
              });
            } catch (repError) {
              console.error('Failed to create credentials for new representative:', repError);
            }
          }
        }
      }

      // First update the client with the approved changes
      // Also clear the pending_logo_url if we're approving a logo change
      const updatePayload = {
        ...proposedChanges,
        pending_logo_url: null,
      };
      
      const { error: updateError } = await supabase
        .from('clients')
        .update(updatePayload)
        .eq('id', clientId);

      if (updateError) throw updateError;

      // Get current user for reviewed_by
      const { data: { user } } = await supabase.auth.getUser();

      // Then mark the change request as approved
      const { error: approveError } = await supabase
        .from('client_pending_changes')
        .update({
          status: 'approved',
          reviewed_at: new Date().toISOString(),
          reviewed_by: user?.id || null,
        })
        .eq('id', changeId);

      if (approveError) throw approveError;

      // Send email notification
      if (clientEmail) {
        try {
          await supabase.functions.invoke('send-approval-notification', {
            body: {
              email: clientEmail,
              companyName: companyName || 'Client',
              status: 'approved',
              changedFields: Object.keys(proposedChanges),
            },
          });
        } catch (emailError) {
          console.error('Failed to send notification email:', emailError);
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pending-changes'] });
      queryClient.invalidateQueries({ queryKey: ['client-pending-changes'] });
      queryClient.invalidateQueries({ queryKey: ['clients'] });
      toast({
        title: 'Changes approved',
        description: 'The client profile has been updated.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
};

export const useRejectChanges = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ changeId, notes, clientEmail, companyName, changedFields }: { 
      changeId: string; 
      notes?: string;
      clientEmail?: string | null;
      companyName?: string;
      changedFields?: string[];
    }) => {
      // Get current user for reviewed_by
      const { data: { user } } = await supabase.auth.getUser();

      const { error } = await supabase
        .from('client_pending_changes')
        .update({
          status: 'rejected',
          reviewed_at: new Date().toISOString(),
          reviewed_by: user?.id || null,
          reviewer_notes: notes || null,
        })
        .eq('id', changeId);

      if (error) throw error;

      // Send email notification
      if (clientEmail) {
        try {
          await supabase.functions.invoke('send-approval-notification', {
            body: {
              email: clientEmail,
              companyName: companyName || 'Client',
              status: 'rejected',
              reviewerNotes: notes,
              changedFields: changedFields || [],
            },
          });
        } catch (emailError) {
          console.error('Failed to send notification email:', emailError);
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pending-changes'] });
      queryClient.invalidateQueries({ queryKey: ['client-pending-changes'] });
      toast({
        title: 'Changes rejected',
        description: 'The change request has been rejected.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
};

export const useCancelPendingChange = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (changeId: string) => {
      const { error } = await supabase
        .from('client_pending_changes')
        .delete()
        .eq('id', changeId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pending-changes'] });
      queryClient.invalidateQueries({ queryKey: ['client-pending-changes'] });
      toast({
        title: 'Request cancelled',
        description: 'Your change request has been cancelled.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
};
