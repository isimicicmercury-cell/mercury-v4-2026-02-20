import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface CandidateDocument {
  id: string;
  candidate_id: string;
  file_name: string;
  file_path: string;
  file_type: string | null;
  file_size: number | null;
  uploaded_at: string;
  uploaded_by: string | null;
}

export const useCandidateDocuments = (candidateId: string | null) => {
  return useQuery({
    queryKey: ['candidate-documents', candidateId],
    queryFn: async () => {
      if (!candidateId) return [];
      const { data, error } = await supabase
        .from('candidate_documents')
        .select('*')
        .eq('candidate_id', candidateId)
        .order('uploaded_at', { ascending: false });

      if (error) throw error;
      return data as CandidateDocument[];
    },
    enabled: !!candidateId,
  });
};

export const useUploadCandidateDocument = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ candidateId, file }: { candidateId: string; file: File }) => {
      // Generate unique filename
      const fileExt = file.name.split('.').pop();
      const fileName = `${candidateId}/${Date.now()}_${file.name}`;

      // Upload to storage
      const { error: uploadError } = await supabase.storage
        .from('candidate-documents')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      // Create document record
      const { data, error } = await supabase
        .from('candidate_documents')
        .insert({
          candidate_id: candidateId,
          file_name: file.name,
          file_path: fileName,
          file_type: file.type,
          file_size: file.size,
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: (_, { candidateId }) => {
      queryClient.invalidateQueries({ queryKey: ['candidate-documents', candidateId] });
      toast({
        title: 'Document uploaded',
        description: 'The document has been uploaded successfully.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Upload failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
};

export const useDeleteCandidateDocument = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ documentId, filePath, candidateId }: { documentId: string; filePath: string; candidateId: string }) => {
      // Delete from storage
      const { error: storageError } = await supabase.storage
        .from('candidate-documents')
        .remove([filePath]);

      if (storageError) throw storageError;

      // Delete record
      const { error } = await supabase
        .from('candidate_documents')
        .delete()
        .eq('id', documentId);

      if (error) throw error;
      return candidateId;
    },
    onSuccess: (candidateId) => {
      queryClient.invalidateQueries({ queryKey: ['candidate-documents', candidateId] });
      toast({
        title: 'Document deleted',
        description: 'The document has been removed.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Delete failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
};

export const getDocumentDownloadUrl = async (filePath: string): Promise<string | null> => {
  const { data, error } = await supabase.storage
    .from('candidate-documents')
    .createSignedUrl(filePath, 3600); // 1 hour expiry

  if (error) {
    console.error('Error getting download URL:', error);
    return null;
  }
  return data.signedUrl;
};
