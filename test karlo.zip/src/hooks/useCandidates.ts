import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface GsmEntry {
  type: string;
  number: string;
}

export interface Candidate {
  id: string;
  candidate_code: string;
  full_name: string;
  email: string | null;
  phone: string | null;
  skills: string[] | null;
  experience_years: number | null;
  resume_url: string | null;
  notes: string | null;
  status: string;
  claimed_by_client_id: string | null;
  claimed_at: string | null;
  created_at: string;
  updated_at: string;
  profile_picture_url: string | null;
  // Profile fields
  prezime: string | null;
  ime: string | null;
  prijava_drb: string | null;
  viza_d_form_ref_no: string | null;
  viza_d_status: string | null;
  plane_ticket: string | null;
  mjesto_i_drzava_rodenja: string | null;
  datum_rodenja: string | null;
  drzavljanstvo: string | null;
  vrsta_i_broj_putovnice: string | null;
  mjesto_izdavanja_putovnice: string | null;
  vrijedi_od_do: string | null;
  vrsta_i_broj_vize_mjesto_izdavanja: string | null;
  rok_vazenja_vize: string | null;
  datum_i_mjesto_ulaska_u_rh: string | null;
  rok_odobrenja_boravka: string | null;
  novi_smjestaj_boraviste: string | null;
  prethodni_smjestaj: string | null;
  datum_prijave_16a: string | null;
  datum_odjave_16a: string | null;
  oib: string | null;
  ime_oca: string | null;
  ime_majke: string | null;
  zanimanje: string | null;
  skolska_sprema: string | null;
  radno_mjesto: string | null;
  termin_lijecnickog: string | null;
  gsm: GsmEntry[] | null;
  iban: string | null;
  prijava_hzmo: string | null;
  odjava_hzmo: string | null;
  ordinacija_opce_medicine: string | null;
  ginekolog: string | null;
  zubar: string | null;
  terapija_komentar: string | null;
}

export const useCandidates = () => {
  return useQuery({
    queryKey: ['candidates'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('candidates')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as unknown as Candidate[];
    },
  });
};

export const useAvailableCandidates = () => {
  return useQuery({
    queryKey: ['candidates', 'available'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('candidates')
        .select('*')
        .eq('status', 'available')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as unknown as Candidate[];
    },
  });
};

export const useCreateCandidate = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (candidate: Omit<Candidate, 'id' | 'candidate_code' | 'created_at' | 'updated_at' | 'status' | 'claimed_by_client_id' | 'claimed_at' | 'profile_picture_url'>) => {
      const { data, error } = await supabase
        .from('candidates')
        .insert(candidate as any)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['candidates'] });
      toast({
        title: 'Candidate added',
        description: 'The candidate has been added to the master pool.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
};

export const useUpdateCandidate = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, ...candidate }: Partial<Candidate> & { id: string }) => {
      const { data, error } = await supabase
        .from('candidates')
        .update(candidate as any)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['candidates'] });
      toast({
        title: 'Candidate updated',
        description: 'The candidate information has been updated.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
};

export const useDeleteCandidate = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('candidates')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['candidates'] });
      toast({
        title: 'Candidate removed',
        description: 'The candidate has been removed from the system.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
};
