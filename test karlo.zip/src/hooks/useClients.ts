import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import type { Json } from '@/integrations/supabase/types';

export interface Representative {
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  work_title: string;
}

export interface FraudMatchData {
  matched_client_id: string;
  matched_company_name: string;
  matched_fields: string[];
}

export interface Client {
  id: string;
  user_id: string;
  company_name: string;
  contact_name: string | null;
  contact_email: string | null;
  phone: string | null;
  notes: string | null;
  login_username: string;
  login_password: string;
  founders_members: string | null;
  representatives: Representative[] | null;
  website: string | null;
  tax_id: string | null;
  country: string | null;
  state: string | null;
  city: string | null;
  postal_code: string | null;
  address_line: string | null;
  logo_url: string | null;
  accent_color: string | null;
  is_banned: boolean | null;
  fraud_match_data: FraudMatchData | null;
  fraud_review_status: string | null;
  created_at: string;
  updated_at: string;
}

export const useClients = () => {
  return useQuery({
    queryKey: ['clients'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('clients')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data.map(client => ({
        ...client,
        representatives: Array.isArray(client.representatives) 
          ? (client.representatives as unknown as Representative[])
          : null,
        fraud_match_data: client.fraud_match_data as unknown as FraudMatchData | null,
      })) as Client[];
    },
  });
};

export const useCreateClient = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (client: {
      company_name: string;
      contact_name?: string;
      contact_email: string;
      phone?: string;
      notes?: string;
      login_username: string;
      login_password: string;
      website?: string;
      tax_id?: string;
      founders_members?: string;
      address_line?: string;
      city?: string;
      postal_code?: string;
      state?: string;
      country?: string;
      fraud_match_data?: FraudMatchData;
      fraud_review_status?: string;
    }) => {
      const { data, error } = await supabase.functions.invoke('create-client', {
        body: client,
      });

      if (error) throw error;
      if (data.error) throw new Error(data.error);
      
      return data.client;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clients'] });
      toast({
        title: 'Client created',
        description: 'The client account has been created successfully.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
};

export const useUpdateClient = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, ...client }: Partial<Client> & { id: string }) => {
      const updateData = {
        ...client,
        representatives: client.representatives as unknown as Json,
        fraud_match_data: client.fraud_match_data as unknown as Json,
      };
      
      const { data, error } = await supabase
        .from('clients')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clients'] });
      toast({
        title: 'Client updated',
        description: 'The client information has been updated.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
};

export const useBanClient = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, is_banned }: { id: string; is_banned: boolean }) => {
      const { data, error } = await supabase
        .from('clients')
        .update({ is_banned })
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: (_, { is_banned }) => {
      queryClient.invalidateQueries({ queryKey: ['clients'] });
      toast({
        title: is_banned ? 'Client banned' : 'Client unbanned',
        description: is_banned 
          ? 'The client has been marked as fraudulent.'
          : 'The client ban has been removed.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
};

export const useDeleteClient = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('clients')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clients'] });
      toast({
        title: 'Client removed',
        description: 'The client has been removed from the system.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
};

export const useDeleteCompany = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (companyName: string) => {
      const { error } = await supabase
        .from('clients')
        .delete()
        .eq('company_name', companyName);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clients'] });
      toast({
        title: 'Company removed',
        description: 'The company and all its users have been removed from the system.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
};

// Function to check for fraud matches
export const checkFraudMatches = (
  newClient: { 
    company_name: string; 
    contact_email?: string; 
    phone?: string; 
    tax_id?: string; 
    address_line?: string;
  },
  bannedClients: Client[]
): FraudMatchData | null => {
  for (const banned of bannedClients) {
    if (!banned.is_banned) continue;
    
    const matchedFields: string[] = [];
    
    if (newClient.company_name && banned.company_name) {
      if (newClient.company_name.toLowerCase() === banned.company_name.toLowerCase()) {
        matchedFields.push('company_name');
      }
    }
    
    if (newClient.contact_email && banned.contact_email) {
      if (newClient.contact_email.toLowerCase() === banned.contact_email.toLowerCase()) {
        matchedFields.push('contact_email');
      }
    }
    
    if (newClient.phone && banned.phone) {
      const normalizedNew = newClient.phone.replace(/\D/g, '');
      const normalizedBanned = banned.phone.replace(/\D/g, '');
      if (normalizedNew === normalizedBanned && normalizedNew.length > 0) {
        matchedFields.push('phone');
      }
    }
    
    if (newClient.tax_id && banned.tax_id) {
      if (newClient.tax_id === banned.tax_id) {
        matchedFields.push('tax_id');
      }
    }
    
    if (newClient.address_line && banned.address_line) {
      if (newClient.address_line.toLowerCase() === banned.address_line.toLowerCase()) {
        matchedFields.push('address_line');
      }
    }
    
    if (matchedFields.length > 0) {
      return {
        matched_client_id: banned.id,
        matched_company_name: banned.company_name,
        matched_fields: matchedFields,
      };
    }
  }
  
  return null;
};

// Hook to update a representative's login credentials
export const useUpdateClientCredentials = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ clientId, login_username, login_password }: {
      clientId: string;
      login_username?: string;
      login_password?: string;
    }) => {
      const updateData: Record<string, string> = {};
      if (login_username !== undefined) updateData.login_username = login_username;
      if (login_password !== undefined) updateData.login_password = login_password;

      // Update the clients table
      const { data, error } = await supabase
        .from('clients')
        .update(updateData)
        .eq('id', clientId)
        .select()
        .single();

      if (error) throw error;

      // Try to update the Supabase Auth password via edge function if password changed
      if (login_password && data.user_id) {
        try {
          await supabase.functions.invoke('update-client-credentials', {
            body: {
              user_id: data.user_id,
              password: login_password,
              username: login_username,
            },
          });
        } catch (e) {
          // Edge function might not exist yet - password updated in display table only
          console.warn('Could not update auth password - edge function may not exist:', e);
        }
      }

      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clients'] });
      toast({
        title: 'Credentials updated',
        description: 'Login credentials have been updated successfully.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
};

// Hook to add a representative to an existing company (creates new auth user + client record)
export const useAddRepresentative = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (params: {
      company_name: string;
      contact_name: string;
      contact_email: string;
      phone?: string;
      login_username: string;
      login_password: string;
      // Copy company-level fields from existing client
      website?: string;
      tax_id?: string;
      founders_members?: string;
      address_line?: string;
      city?: string;
      postal_code?: string;
      state?: string;
      country?: string;
    }) => {
      const { data, error } = await supabase.functions.invoke('create-client', {
        body: params,
      });

      if (error) throw error;
      if (data.error) throw new Error(data.error);
      return data.client;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clients'] });
      toast({
        title: 'Representative added',
        description: 'New representative has been created with login credentials.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
};
