/**
 * Converts Croatian special characters to their standard English equivalents.
 */
export const convertCroatianChars = (str: string): string => {
  const charMap: Record<string, string> = {
    'č': 'c', 'Č': 'C',
    'ć': 'c', 'Ć': 'C',
    'đ': 'd', 'Đ': 'D',
    'š': 's', 'Š': 'S',
    'ž': 'z', 'Ž': 'Z',
  };
  return str.replace(/[čČćĆđĐšŠžŽ]/g, (match) => charMap[match] || match);
};

/**
 * Generates a username from company name and representative name,
 * converting Croatian characters to ASCII equivalents.
 */
export const generateUsername = (companyName: string, repName: string, index: number): string => {
  const cleanCompany = convertCroatianChars(companyName).toLowerCase().replace(/[^a-z0-9]/g, '');
  const cleanName = convertCroatianChars(repName).toLowerCase().replace(/[^a-z0-9]/g, '');
  return `${cleanCompany}_${cleanName || `rep${index + 1}`}`;
};

/**
 * Generates a secure random password.
 */
export const generatePassword = (): string => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%';
  let password = '';
  for (let i = 0; i < 12; i++) {
    password += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return password;
};
