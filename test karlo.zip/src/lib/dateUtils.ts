import { format } from 'date-fns';

/**
 * Format a date string or Date object to DD.MM.YYYY format
 */
export const formatDate = (date: string | Date): string => {
  const d = typeof date === 'string' ? new Date(date) : date;
  return format(d, 'dd.MM.yyyy');
};

/**
 * Format a date string or Date object to DD.MM.YYYY at HH:mm format
 */
export const formatDateTime = (date: string | Date): string => {
  const d = typeof date === 'string' ? new Date(date) : date;
  return format(d, 'dd.MM.yyyy') + ' at ' + format(d, 'HH:mm');
};

/**
 * Format a date string or Date object to HH:mm format
 */
export const formatTime = (date: string | Date): string => {
  const d = typeof date === 'string' ? new Date(date) : date;
  return format(d, 'HH:mm');
};
