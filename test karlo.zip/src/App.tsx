import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { HashRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { Users } from "lucide-react";

import Login from "./pages/Login";
import Setup from "./pages/Setup";
import NotFound from "./pages/NotFound";
import DashboardLayout from "./components/layout/DashboardLayout";

// Superuser pages
import Dashboard from "./pages/superuser/Dashboard";
import Candidates from "./pages/superuser/Candidates";
import CandidateProfile from "./pages/superuser/CandidateProfile";
import Clients from "./pages/superuser/Clients";
import ClientProfile from "./pages/superuser/ClientProfile";
import Assignments from "./pages/superuser/Assignments";
import PendingApprovals from "./pages/superuser/PendingApprovals";
import Pipelines from "./pages/superuser/Pipelines";
import PipelineBuilder from "./pages/superuser/PipelineBuilder";
import PipelineKanban from "./pages/superuser/PipelineKanban";

// Client pages
import MyCandidates from "./pages/client/MyCandidates";
import MyHires from "./pages/client/MyHires";
import MyProfile from "./pages/client/MyProfile";
import EditProfile from "./pages/client/EditProfile";

const queryClient = new QueryClient();

const LoadingScreen = () => (
  <div className="min-h-screen flex items-center justify-center bg-background">
    <div className="flex flex-col items-center gap-4 animate-fade-in">
      <div className="w-12 h-12 rounded-2xl bg-primary flex items-center justify-center shadow-lg shadow-primary/20">
        <Users className="w-6 h-6 text-primary-foreground" />
      </div>
      <div className="flex flex-col items-center gap-2">
        <h1 className="text-lg font-bold text-foreground">MercuryWerks</h1>
        <div className="flex items-center gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0ms' }} />
          <div className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '150ms' }} />
          <div className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '300ms' }} />
        </div>
      </div>
    </div>
  </div>
);

const ProtectedRoutes = () => {
  const { role, loading } = useAuth();

  if (loading) return <LoadingScreen />;

  if (role === "superuser") {
    return (
      <DashboardLayout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/candidates" element={<Candidates />} />
          <Route path="/candidates/:id" element={<CandidateProfile />} />
          <Route path="/clients" element={<Clients />} />
          <Route path="/clients/:id" element={<ClientProfile />} />
          <Route path="/pipelines" element={<Pipelines />} />
          <Route path="/pipelines/:id" element={<PipelineBuilder />} />
          <Route path="/pipelines/:id/kanban" element={<PipelineKanban />} />
          <Route path="/assignments" element={<Assignments />} />
          <Route path="/approvals" element={<PendingApprovals />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </DashboardLayout>
    );
  }

  if (role === "client") {
    return (
      <DashboardLayout>
        <Routes>
          <Route path="/" element={<MyCandidates />} />
          <Route path="/my-hires" element={<MyHires />} />
          <Route path="/my-profile" element={<MyProfile />} />
          <Route path="/my-profile/edit" element={<EditProfile />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </DashboardLayout>
    );
  }

  // No role assigned yet
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center max-w-md px-6 animate-fade-in">
        <div className="w-14 h-14 rounded-2xl bg-amber-500/10 flex items-center justify-center mx-auto mb-4">
          <Users className="w-7 h-7 text-amber-500" />
        </div>
        <h1 className="text-xl font-bold text-foreground mb-2">Account Setup Pending</h1>
        <p className="text-muted-foreground text-sm">
          Your account has been created but hasn't been assigned a role yet. Please contact your administrator to complete the setup.
        </p>
      </div>
    </div>
  );
};

const AppRoutes = () => {
  const { user, loading } = useAuth();

  if (loading) return <LoadingScreen />;

  return (
    <Routes>
      <Route path="/setup" element={<Setup />} />
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <Login />} />
      <Route path="/*" element={user ? <ProtectedRoutes /> : <Navigate to="/login" replace />} />
    </Routes>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <HashRouter>
        <AuthProvider>
          <AppRoutes />
        </AuthProvider>
      </HashRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
