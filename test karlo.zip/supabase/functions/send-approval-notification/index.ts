import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface ApprovalNotificationRequest {
  email: string;
  companyName: string;
  status: "approved" | "rejected";
  reviewerNotes?: string;
  changedFields: string[];
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // --- Authentication & Authorization ---
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    const userId = claimsData.claims.sub;

    // Verify caller is a superuser
    const adminClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );
    const { data: role } = await adminClient
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .eq("role", "superuser")
      .maybeSingle();

    if (!role) {
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    // --- Input validation ---
    const { email, companyName, status, reviewerNotes, changedFields }: ApprovalNotificationRequest = await req.json();

    if (!email || !companyName || !status) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      return new Response(JSON.stringify({ error: "Invalid email format" }), {
        status: 400,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    if (status !== "approved" && status !== "rejected") {
      return new Response(JSON.stringify({ error: "Invalid status" }), {
        status: 400,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    // Sanitize inputs for HTML injection
    const escapeHtml = (str: string) =>
      str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

    const safeCompanyName = escapeHtml(companyName);
    const safeReviewerNotes = reviewerNotes ? escapeHtml(reviewerNotes) : "";
    const safeChangedFields = Array.isArray(changedFields) ? changedFields.map(escapeHtml) : [];

    const isApproved = status === "approved";
    const statusText = isApproved ? "Approved" : "Rejected";
    const statusColor = isApproved ? "#22c55e" : "#ef4444";

    const fieldsHtml = safeChangedFields.length > 0
      ? `<p><strong>Fields changed:</strong> ${safeChangedFields.join(", ")}</p>`
      : "";

    const notesHtml = safeReviewerNotes
      ? `<p><strong>Reviewer notes:</strong> ${safeReviewerNotes}</p>`
      : "";

    const emailResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: "TalentBridge <onboarding@resend.dev>",
        to: [email.trim()],
        subject: `Profile Change Request ${statusText} - ${safeCompanyName}`,
        html: `
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
          </head>
          <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; border-radius: 12px 12px 0 0; text-align: center;">
              <h1 style="color: white; margin: 0; font-size: 24px;">TalentBridge</h1>
            </div>
            <div style="background: #ffffff; padding: 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 12px 12px;">
              <div style="text-align: center; margin-bottom: 24px;">
                <span style="display: inline-block; background: ${statusColor}; color: white; padding: 8px 24px; border-radius: 20px; font-weight: 600; font-size: 14px;">
                  ${statusText.toUpperCase()}
                </span>
              </div>
              <h2 style="color: #1f2937; margin-top: 0;">Hello ${safeCompanyName},</h2>
              <p style="color: #4b5563;">
                Your profile change request has been <strong style="color: ${statusColor};">${status}</strong>.
              </p>
              ${fieldsHtml}
              ${notesHtml}
              <p style="color: #4b5563;">
                ${isApproved
                  ? "Your profile has been updated with the requested changes."
                  : "Please review the feedback and submit a new request if needed."}
              </p>
              <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 24px 0;">
              <p style="color: #9ca3af; font-size: 12px; text-align: center;">
                This is an automated message from TalentBridge. Please do not reply to this email.
              </p>
            </div>
          </body>
          </html>
        `,
      }),
    });

    const data = await emailResponse.json();

    console.log("Approval notification sent by user:", userId);

    return new Response(JSON.stringify(data), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Error in send-approval-notification:", errorMessage);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
