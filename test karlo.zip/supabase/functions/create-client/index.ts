import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { 
      company_name, 
      contact_name, 
      contact_email, 
      phone, 
      notes, 
      login_username, 
      login_password,
      // Extended fields
      website,
      tax_id,
      founders_members,
      address_line,
      city,
      postal_code,
      state,
      country,
      // Fraud detection fields
      fraud_match_data,
      fraud_review_status,
    } = await req.json();

    if (!contact_email || !login_password || !company_name || !login_username) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(contact_email.trim())) {
      return new Response(
        JSON.stringify({ error: "Invalid email format. Please enter a valid email address (e.g. user@example.com)." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create admin client with service role
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      }
    );

    // Normalize username to lowercase for case-insensitive comparison
    const normalizedUsername = login_username.toLowerCase().trim();

    // Check for duplicate username (case-insensitive)
    const { data: existingUsername } = await supabaseAdmin
      .from("clients")
      .select("id, login_username")
      .ilike("login_username", normalizedUsername)
      .maybeSingle();

    if (existingUsername) {
      return new Response(
        JSON.stringify({ error: "This username is already taken. Please choose a different username." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check for duplicate password
    const { data: existingPassword } = await supabaseAdmin
      .from("clients")
      .select("id, company_name")
      .eq("login_password", login_password)
      .maybeSingle();

    if (existingPassword) {
      return new Response(
        JSON.stringify({ error: "This password is already in use by another client. Please choose a different password." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check if user already exists
    const { data: existingUsers } = await supabaseAdmin.auth.admin.listUsers();
    const existingUser = existingUsers?.users?.find(u => u.email?.toLowerCase() === contact_email.toLowerCase());

    let userId: string;

    if (existingUser) {
      // User exists - check if they already have a client role
      const { data: existingRole } = await supabaseAdmin
        .from("user_roles")
        .select("id")
        .eq("user_id", existingUser.id)
        .eq("role", "client")
        .maybeSingle();

      if (existingRole) {
        // Check if client record exists
        const { data: existingClient } = await supabaseAdmin
          .from("clients")
          .select("id")
          .eq("user_id", existingUser.id)
          .maybeSingle();

        if (existingClient) {
          return new Response(
            JSON.stringify({ error: "This user is already a client" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      }

      userId = existingUser.id;

      // Update password if user exists
      await supabaseAdmin.auth.admin.updateUserById(userId, {
        password: login_password,
      });
    } else {
      // Create new user
      const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
        email: contact_email,
        password: login_password,
        email_confirm: true,
      });

      if (authError) throw authError;
      if (!authData.user) throw new Error("Failed to create user");

      userId = authData.user.id;

      // Create profile for new user
      const { error: profileError } = await supabaseAdmin.from("profiles").insert({
        user_id: userId,
        email: contact_email,
        full_name: contact_name || company_name,
        company_name: company_name,
      });

      if (profileError) throw profileError;
    }

    // Check if role already exists
    const { data: existingRole } = await supabaseAdmin
      .from("user_roles")
      .select("id")
      .eq("user_id", userId)
      .eq("role", "client")
      .maybeSingle();

    if (!existingRole) {
      // Assign client role
      const { error: roleError } = await supabaseAdmin.from("user_roles").insert({
        user_id: userId,
        role: "client",
      });

      if (roleError) throw roleError;
    }

    // Create client record with all fields - store username in lowercase
    const { data: clientData, error: clientError } = await supabaseAdmin
      .from("clients")
      .insert({
        user_id: userId,
        company_name,
        contact_name,
        contact_email,
        phone,
        notes,
        login_username: normalizedUsername,
        login_password,
        // Extended fields
        website,
        tax_id,
        founders_members,
        address_line,
        city,
        postal_code,
        state,
        country,
        // Fraud detection fields
        fraud_match_data: fraud_match_data || null,
        fraud_review_status: fraud_review_status || null,
      })
      .select()
      .single();

    if (clientError) throw clientError;

    return new Response(
      JSON.stringify({ success: true, client: clientData }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});