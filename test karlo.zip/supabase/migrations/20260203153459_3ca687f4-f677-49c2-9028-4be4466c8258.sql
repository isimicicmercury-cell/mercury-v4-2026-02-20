-- Add is_banned and fraud_match_data columns to clients table
ALTER TABLE public.clients 
ADD COLUMN IF NOT EXISTS is_banned boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS fraud_match_data jsonb DEFAULT NULL;

-- Add fraud_review_status for manual review workflow
ALTER TABLE public.clients 
ADD COLUMN IF NOT EXISTS fraud_review_status text DEFAULT NULL;