-- Create storage bucket for candidate documents
INSERT INTO storage.buckets (id, name, public) VALUES ('candidate-documents', 'candidate-documents', false);

-- Create policies for candidate document uploads (superusers only can upload/manage)
CREATE POLICY "Superusers can upload candidate documents"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'candidate-documents' AND public.has_role(auth.uid(), 'superuser'));

CREATE POLICY "Superusers can view all candidate documents"
ON storage.objects FOR SELECT
USING (bucket_id = 'candidate-documents' AND public.has_role(auth.uid(), 'superuser'));

CREATE POLICY "Superusers can update candidate documents"
ON storage.objects FOR UPDATE
USING (bucket_id = 'candidate-documents' AND public.has_role(auth.uid(), 'superuser'));

CREATE POLICY "Superusers can delete candidate documents"
ON storage.objects FOR DELETE
USING (bucket_id = 'candidate-documents' AND public.has_role(auth.uid(), 'superuser'));

-- Clients can view documents of assigned candidates
CREATE POLICY "Clients can view assigned candidate documents"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'candidate-documents' 
  AND EXISTS (
    SELECT 1 
    FROM public.candidate_assignments ca
    WHERE ca.client_id = public.get_client_id(auth.uid())
    AND ca.candidate_id::text = (storage.foldername(name))[1]
  )
);

-- Create a table to track candidate documents
CREATE TABLE public.candidate_documents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  candidate_id UUID NOT NULL REFERENCES public.candidates(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_type TEXT,
  file_size INTEGER,
  uploaded_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  uploaded_by UUID
);

-- Enable RLS
ALTER TABLE public.candidate_documents ENABLE ROW LEVEL SECURITY;

-- Superusers can manage all documents
CREATE POLICY "Superusers can manage candidate documents"
ON public.candidate_documents FOR ALL
USING (public.has_role(auth.uid(), 'superuser'));

-- Clients can view documents of assigned candidates
CREATE POLICY "Clients can view assigned candidate documents"
ON public.candidate_documents FOR SELECT
USING (
  EXISTS (
    SELECT 1 
    FROM public.candidate_assignments ca
    WHERE ca.client_id = public.get_client_id(auth.uid())
    AND ca.candidate_id = candidate_documents.candidate_id
  )
);

-- Create storage bucket for pending logo uploads
INSERT INTO storage.buckets (id, name, public) VALUES ('pending-logos', 'pending-logos', true);

-- Anyone authenticated can upload to pending-logos
CREATE POLICY "Authenticated users can upload pending logos"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'pending-logos' AND auth.uid() IS NOT NULL);

-- Anyone can view pending logos
CREATE POLICY "Anyone can view pending logos"
ON storage.objects FOR SELECT
USING (bucket_id = 'pending-logos');

-- Add pending_logo_url column to clients for tracking pending logo uploads
ALTER TABLE public.clients ADD COLUMN pending_logo_url TEXT DEFAULT NULL;