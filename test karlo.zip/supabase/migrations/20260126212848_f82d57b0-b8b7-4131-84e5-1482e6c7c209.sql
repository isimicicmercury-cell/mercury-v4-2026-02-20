-- Create a table for client pending change requests
CREATE TABLE public.client_pending_changes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  proposed_changes JSONB NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  submitted_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  reviewed_at TIMESTAMP WITH TIME ZONE,
  reviewed_by UUID,
  reviewer_notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.client_pending_changes ENABLE ROW LEVEL SECURITY;

-- Clients can view and create their own pending changes
CREATE POLICY "Clients can view own pending changes"
ON public.client_pending_changes
FOR SELECT
USING (client_id = get_client_id(auth.uid()));

CREATE POLICY "Clients can create own pending changes"
ON public.client_pending_changes
FOR INSERT
WITH CHECK (client_id = get_client_id(auth.uid()));

-- Superusers can manage all pending changes
CREATE POLICY "Superusers can manage all pending changes"
ON public.client_pending_changes
FOR ALL
USING (has_role(auth.uid(), 'superuser'));

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_client_pending_changes_updated_at
BEFORE UPDATE ON public.client_pending_changes
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();