
-- 1) Pipeline Templates
CREATE TABLE public.pipeline_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.pipeline_templates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Superusers can manage pipeline templates"
  ON public.pipeline_templates FOR ALL
  USING (has_role(auth.uid(), 'superuser'::app_role));

CREATE POLICY "Clients can view active pipeline templates"
  ON public.pipeline_templates FOR SELECT
  USING (is_active = true AND has_role(auth.uid(), 'client'::app_role));

-- 2) Pipeline Stages
CREATE TABLE public.pipeline_stages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pipeline_template_id uuid NOT NULL REFERENCES public.pipeline_templates(id) ON DELETE CASCADE,
  name text NOT NULL,
  stage_type text NOT NULL DEFAULT 'other',
  position integer NOT NULL,
  is_required boolean NOT NULL DEFAULT true,
  can_client_advance boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.pipeline_stages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Superusers can manage pipeline stages"
  ON public.pipeline_stages FOR ALL
  USING (has_role(auth.uid(), 'superuser'::app_role));

CREATE POLICY "Clients can view pipeline stages"
  ON public.pipeline_stages FOR SELECT
  USING (has_role(auth.uid(), 'client'::app_role));

CREATE INDEX idx_pipeline_stages_template_position ON public.pipeline_stages(pipeline_template_id, position);

-- 3) Client Pipeline Assignment (one pipeline per client company)
CREATE TABLE public.client_pipeline_assignment (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  pipeline_template_id uuid NOT NULL REFERENCES public.pipeline_templates(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(client_id)
);
ALTER TABLE public.client_pipeline_assignment ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Superusers can manage client pipeline assignments"
  ON public.client_pipeline_assignment FOR ALL
  USING (has_role(auth.uid(), 'superuser'::app_role));

CREATE POLICY "Clients can view own pipeline assignment"
  ON public.client_pipeline_assignment FOR SELECT
  USING (client_id = get_client_id(auth.uid()));

CREATE INDEX idx_client_pipeline_client ON public.client_pipeline_assignment(client_id);

-- 4) Candidate Pipeline State
CREATE TABLE public.candidate_pipeline_state (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_id uuid NOT NULL REFERENCES public.candidates(id) ON DELETE CASCADE,
  pipeline_template_id uuid NOT NULL REFERENCES public.pipeline_templates(id),
  current_stage_id uuid NOT NULL REFERENCES public.pipeline_stages(id),
  status text NOT NULL DEFAULT 'active',
  entered_stage_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(candidate_id)
);
ALTER TABLE public.candidate_pipeline_state ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Superusers can manage candidate pipeline state"
  ON public.candidate_pipeline_state FOR ALL
  USING (has_role(auth.uid(), 'superuser'::app_role));

CREATE POLICY "Clients can view assigned candidate pipeline state"
  ON public.candidate_pipeline_state FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM candidate_assignments ca
    WHERE ca.candidate_id = candidate_pipeline_state.candidate_id
    AND ca.client_id = get_client_id(auth.uid())
  ));

CREATE POLICY "Clients can update assigned candidate pipeline state"
  ON public.candidate_pipeline_state FOR UPDATE
  USING (EXISTS (
    SELECT 1 FROM candidate_assignments ca
    WHERE ca.candidate_id = candidate_pipeline_state.candidate_id
    AND ca.client_id = get_client_id(auth.uid())
  ));

CREATE INDEX idx_candidate_pipeline_current_stage ON public.candidate_pipeline_state(current_stage_id);
CREATE INDEX idx_candidate_pipeline_template ON public.candidate_pipeline_state(pipeline_template_id);

-- Trigger for updated_at
CREATE TRIGGER update_candidate_pipeline_state_updated_at
  BEFORE UPDATE ON public.candidate_pipeline_state
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 5) Candidate Stage History
CREATE TABLE public.candidate_stage_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_id uuid NOT NULL REFERENCES public.candidates(id) ON DELETE CASCADE,
  from_stage_id uuid REFERENCES public.pipeline_stages(id),
  to_stage_id uuid NOT NULL REFERENCES public.pipeline_stages(id),
  changed_by_user_id uuid,
  note text,
  changed_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.candidate_stage_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Superusers can manage stage history"
  ON public.candidate_stage_history FOR ALL
  USING (has_role(auth.uid(), 'superuser'::app_role));

CREATE POLICY "Clients can view assigned candidate stage history"
  ON public.candidate_stage_history FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM candidate_assignments ca
    WHERE ca.candidate_id = candidate_stage_history.candidate_id
    AND ca.client_id = get_client_id(auth.uid())
  ));

CREATE POLICY "Clients can insert stage history for assigned candidates"
  ON public.candidate_stage_history FOR INSERT
  WITH CHECK (EXISTS (
    SELECT 1 FROM candidate_assignments ca
    WHERE ca.candidate_id = candidate_stage_history.candidate_id
    AND ca.client_id = get_client_id(auth.uid())
  ));

-- 6) Update claim_candidate function to also initialize pipeline state
CREATE OR REPLACE FUNCTION public.claim_candidate(p_candidate_id uuid, p_client_id uuid)
  RETURNS boolean
  LANGUAGE plpgsql
  SECURITY DEFINER
  SET search_path TO 'public'
AS $function$
DECLARE
  v_current_status TEXT;
  v_pipeline_template_id UUID;
  v_first_stage_id UUID;
BEGIN
  -- Lock the row to prevent concurrent claims
  SELECT status INTO v_current_status
  FROM public.candidates
  WHERE id = p_candidate_id
  FOR UPDATE;
  
  -- Check if candidate is still available
  IF v_current_status != 'available' THEN
    RETURN FALSE;
  END IF;
  
  -- Verify the client has this candidate assigned
  IF NOT EXISTS (
    SELECT 1 FROM public.candidate_assignments
    WHERE candidate_id = p_candidate_id
    AND client_id = p_client_id
    AND status = 'pending'
  ) THEN
    RETURN FALSE;
  END IF;
  
  -- Claim the candidate
  UPDATE public.candidates
  SET status = 'claimed',
      claimed_by_client_id = p_client_id,
      claimed_at = now()
  WHERE id = p_candidate_id;
  
  -- Update the assignment status for the claiming client
  UPDATE public.candidate_assignments
  SET status = 'claimed'
  WHERE candidate_id = p_candidate_id
  AND client_id = p_client_id;
  
  -- Remove assignments for all other clients
  DELETE FROM public.candidate_assignments
  WHERE candidate_id = p_candidate_id
  AND client_id != p_client_id;

  -- Initialize pipeline state if client has a pipeline assigned
  SELECT cpa.pipeline_template_id INTO v_pipeline_template_id
  FROM public.client_pipeline_assignment cpa
  WHERE cpa.client_id = p_client_id;

  IF v_pipeline_template_id IS NOT NULL THEN
    -- Get the first stage (lowest position)
    SELECT id INTO v_first_stage_id
    FROM public.pipeline_stages
    WHERE pipeline_template_id = v_pipeline_template_id
    ORDER BY position ASC
    LIMIT 1;

    IF v_first_stage_id IS NOT NULL THEN
      -- Create pipeline state
      INSERT INTO public.candidate_pipeline_state (candidate_id, pipeline_template_id, current_stage_id)
      VALUES (p_candidate_id, v_pipeline_template_id, v_first_stage_id)
      ON CONFLICT (candidate_id) DO UPDATE
      SET pipeline_template_id = v_pipeline_template_id,
          current_stage_id = v_first_stage_id,
          status = 'active',
          entered_stage_at = now();

      -- Write initial history record
      INSERT INTO public.candidate_stage_history (candidate_id, from_stage_id, to_stage_id, note)
      VALUES (p_candidate_id, NULL, v_first_stage_id, 'Candidate claimed – entered pipeline');
    END IF;
  END IF;
  
  RETURN TRUE;
END;
$function$;

-- 7) Function to advance candidate to next stage
CREATE OR REPLACE FUNCTION public.advance_candidate_stage(
  p_candidate_id uuid,
  p_note text DEFAULT NULL,
  p_skip boolean DEFAULT false
)
  RETURNS jsonb
  LANGUAGE plpgsql
  SECURITY DEFINER
  SET search_path TO 'public'
AS $function$
DECLARE
  v_current_state RECORD;
  v_current_stage RECORD;
  v_next_stage RECORD;
  v_user_role TEXT;
  v_can_advance BOOLEAN;
BEGIN
  -- Get current pipeline state
  SELECT * INTO v_current_state
  FROM public.candidate_pipeline_state
  WHERE candidate_id = p_candidate_id;

  IF v_current_state IS NULL THEN
    RETURN jsonb_build_object('success', false, 'error', 'Candidate is not in any pipeline');
  END IF;

  IF v_current_state.status != 'active' THEN
    RETURN jsonb_build_object('success', false, 'error', 'Candidate pipeline is not active (status: ' || v_current_state.status || ')');
  END IF;

  -- Get current stage info
  SELECT * INTO v_current_stage
  FROM public.pipeline_stages
  WHERE id = v_current_state.current_stage_id;

  -- Check permissions: superusers can always advance, clients only if can_client_advance
  SELECT role INTO v_user_role
  FROM public.user_roles
  WHERE user_id = auth.uid()
  LIMIT 1;

  IF v_user_role = 'client' THEN
    IF NOT v_current_stage.can_client_advance THEN
      RETURN jsonb_build_object('success', false, 'error', 'You do not have permission to advance this stage');
    END IF;
  END IF;

  -- Get next stage
  SELECT * INTO v_next_stage
  FROM public.pipeline_stages
  WHERE pipeline_template_id = v_current_state.pipeline_template_id
  AND position > v_current_stage.position
  ORDER BY position ASC
  LIMIT 1;

  IF v_next_stage IS NULL THEN
    RETURN jsonb_build_object('success', false, 'error', 'Already at the last stage');
  END IF;

  -- If skipping, check the current stage is not required (or we skip the next optional one)
  -- Actually, skip means we skip the CURRENT stage which must be optional
  IF p_skip AND v_current_stage.is_required THEN
    RETURN jsonb_build_object('success', false, 'error', 'Cannot skip a required stage');
  END IF;

  -- Update state
  UPDATE public.candidate_pipeline_state
  SET current_stage_id = v_next_stage.id,
      entered_stage_at = now()
  WHERE candidate_id = p_candidate_id;

  -- Write history
  INSERT INTO public.candidate_stage_history (candidate_id, from_stage_id, to_stage_id, changed_by_user_id, note)
  VALUES (
    p_candidate_id,
    v_current_stage.id,
    v_next_stage.id,
    auth.uid(),
    COALESCE(p_note, CASE WHEN p_skip THEN 'Stage skipped' ELSE 'Advanced to next stage' END)
  );

  RETURN jsonb_build_object(
    'success', true,
    'from_stage', v_current_stage.name,
    'to_stage', v_next_stage.name,
    'new_stage_id', v_next_stage.id
  );
END;
$function$;

-- 8) Function to update candidate pipeline status (hired, rejected, on_hold)
CREATE OR REPLACE FUNCTION public.update_candidate_pipeline_status(
  p_candidate_id uuid,
  p_status text,
  p_note text DEFAULT NULL
)
  RETURNS boolean
  LANGUAGE plpgsql
  SECURITY DEFINER
  SET search_path TO 'public'
AS $function$
BEGIN
  IF p_status NOT IN ('active', 'hired', 'rejected', 'on_hold') THEN
    RETURN FALSE;
  END IF;

  UPDATE public.candidate_pipeline_state
  SET status = p_status
  WHERE candidate_id = p_candidate_id;

  IF NOT FOUND THEN
    RETURN FALSE;
  END IF;

  -- Write history note
  INSERT INTO public.candidate_stage_history (candidate_id, from_stage_id, to_stage_id, changed_by_user_id, note)
  SELECT p_candidate_id, current_stage_id, current_stage_id, auth.uid(),
         'Status changed to ' || p_status || COALESCE(': ' || p_note, '')
  FROM public.candidate_pipeline_state
  WHERE candidate_id = p_candidate_id;

  RETURN TRUE;
END;
$function$;
