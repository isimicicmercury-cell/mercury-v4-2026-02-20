-- Update get_email_by_username function to be case-insensitive
CREATE OR REPLACE FUNCTION public.get_email_by_username(p_username text)
 RETURNS text
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_email text;
BEGIN
  -- Case-insensitive lookup using LOWER()
  SELECT contact_email INTO v_email
  FROM public.clients
  WHERE LOWER(login_username) = LOWER(p_username)
  LIMIT 1;
  
  RETURN v_email;
END;
$function$;