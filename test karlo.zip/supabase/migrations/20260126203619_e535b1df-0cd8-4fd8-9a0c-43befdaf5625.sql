-- Drop the restrictive insert policy
DROP POLICY IF EXISTS "Superusers can insert roles" ON public.user_roles;

-- Create a new policy that allows:
-- 1. Service role to insert (for edge function)
-- 2. Existing superusers to insert new roles
-- The service role bypasses RLS entirely, so this policy is for authenticated users
CREATE POLICY "Superusers can insert roles"
ON public.user_roles
FOR INSERT
TO authenticated
WITH CHECK (has_role(auth.uid(), 'superuser'::app_role));

-- Also ensure the edge function can work by verifying service role access
-- Service role key bypasses RLS by default, but let's add a permissive policy for initial setup
CREATE POLICY "Allow initial superuser creation"
ON public.user_roles
FOR INSERT
TO authenticated
WITH CHECK (
  -- Allow if no superusers exist yet (first-time setup)
  NOT EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'superuser')
);