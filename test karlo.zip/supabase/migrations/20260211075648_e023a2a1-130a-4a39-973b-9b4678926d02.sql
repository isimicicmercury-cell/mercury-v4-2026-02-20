
-- Add candidate_code column with unique constraint
ALTER TABLE public.candidates ADD COLUMN IF NOT EXISTS candidate_code text UNIQUE;

-- Add profile_picture_url column
ALTER TABLE public.candidates ADD COLUMN IF NOT EXISTS profile_picture_url text;

-- Create a function to generate unique candidate codes (4 uppercase letters + 2 digits)
CREATE OR REPLACE FUNCTION public.generate_candidate_code()
RETURNS text
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
  new_code text;
  code_exists boolean;
BEGIN
  LOOP
    -- Generate 4 random uppercase letters + 2 random digits
    new_code := chr(65 + floor(random() * 26)::int) ||
                chr(65 + floor(random() * 26)::int) ||
                chr(65 + floor(random() * 26)::int) ||
                chr(65 + floor(random() * 26)::int) ||
                lpad(floor(random() * 100)::text, 2, '0');
    
    -- Check uniqueness
    SELECT EXISTS(SELECT 1 FROM public.candidates WHERE candidate_code = new_code) INTO code_exists;
    
    IF NOT code_exists THEN
      RETURN new_code;
    END IF;
  END LOOP;
END;
$$;

-- Create trigger to auto-generate candidate_code on insert
CREATE OR REPLACE FUNCTION public.set_candidate_code()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF NEW.candidate_code IS NULL OR NEW.candidate_code = '' THEN
    NEW.candidate_code := generate_candidate_code();
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trigger_set_candidate_code
  BEFORE INSERT ON public.candidates
  FOR EACH ROW
  EXECUTE FUNCTION public.set_candidate_code();

-- Backfill existing candidates that don't have a code
UPDATE public.candidates 
SET candidate_code = generate_candidate_code() 
WHERE candidate_code IS NULL;

-- Make candidate_code NOT NULL after backfill
ALTER TABLE public.candidates ALTER COLUMN candidate_code SET NOT NULL;

-- Create storage bucket for candidate profile photos
INSERT INTO storage.buckets (id, name, public) VALUES ('candidate-photos', 'candidate-photos', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for candidate photos
CREATE POLICY "Candidate photos are publicly readable"
ON storage.objects FOR SELECT
USING (bucket_id = 'candidate-photos');

CREATE POLICY "Superusers can upload candidate photos"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'candidate-photos' AND public.has_role(auth.uid(), 'superuser'));

CREATE POLICY "Superusers can update candidate photos"
ON storage.objects FOR UPDATE
USING (bucket_id = 'candidate-photos' AND public.has_role(auth.uid(), 'superuser'));

CREATE POLICY "Superusers can delete candidate photos"
ON storage.objects FOR DELETE
USING (bucket_id = 'candidate-photos' AND public.has_role(auth.uid(), 'superuser'));
