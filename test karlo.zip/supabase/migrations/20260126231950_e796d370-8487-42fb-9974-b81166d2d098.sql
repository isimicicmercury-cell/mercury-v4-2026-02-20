-- Create a security definer function to look up email by username for login purposes
-- This allows unauthenticated users to resolve username to email during login
CREATE OR REPLACE FUNCTION public.get_email_by_username(p_username text)
RETURNS text
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_email text;
BEGIN
  SELECT contact_email INTO v_email
  FROM public.clients
  WHERE login_username = p_username
  LIMIT 1;
  
  RETURN v_email;
END;
$$;