-- Add INSERT policy for profiles (needed during client creation)
CREATE POLICY "Users can insert own profile" ON public.profiles
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Add INSERT policy for user_roles (needed during client creation by superusers)
CREATE POLICY "Superusers can insert roles" ON public.user_roles
  FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'superuser'));

-- Add INSERT policy for clients (needed during client creation by superusers)  
CREATE POLICY "Superusers can insert clients" ON public.clients
  FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'superuser'));