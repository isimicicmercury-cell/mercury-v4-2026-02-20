-- Create app_role enum for user types
CREATE TYPE public.app_role AS ENUM ('superuser', 'client');

-- Create profiles table for user information
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  email TEXT NOT NULL,
  full_name TEXT,
  company_name TEXT,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- Create user_roles table (security best practice - roles separate from profiles)
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  UNIQUE (user_id, role)
);

-- Create clients table
CREATE TABLE public.clients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  company_name TEXT NOT NULL,
  contact_name TEXT,
  contact_email TEXT,
  phone TEXT,
  notes TEXT,
  login_username TEXT NOT NULL UNIQUE,
  login_password TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- Create candidates table (master pool)
CREATE TABLE public.candidates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  skills TEXT[],
  experience_years INTEGER,
  resume_url TEXT,
  notes TEXT,
  status TEXT DEFAULT 'available' CHECK (status IN ('available', 'claimed', 'hired')),
  claimed_by_client_id UUID REFERENCES public.clients(id) ON DELETE SET NULL,
  claimed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- Create candidate_assignments table (junction table for assigning candidates to clients)
CREATE TABLE public.candidate_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_id UUID REFERENCES public.candidates(id) ON DELETE CASCADE NOT NULL,
  client_id UUID REFERENCES public.clients(id) ON DELETE CASCADE NOT NULL,
  assigned_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'interested', 'rejected', 'claimed')),
  UNIQUE (candidate_id, client_id)
);

-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.candidates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.candidate_assignments ENABLE ROW LEVEL SECURITY;

-- Security definer function to check roles (prevents infinite recursion)
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- Function to get client_id for a user
CREATE OR REPLACE FUNCTION public.get_client_id(_user_id UUID)
RETURNS UUID
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id FROM public.clients WHERE user_id = _user_id LIMIT 1
$$;

-- Profiles RLS policies
CREATE POLICY "Users can view own profile" ON public.profiles
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Superusers can view all profiles" ON public.profiles
  FOR SELECT USING (public.has_role(auth.uid(), 'superuser'));

CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Superusers can manage all profiles" ON public.profiles
  FOR ALL USING (public.has_role(auth.uid(), 'superuser'));

-- User roles RLS policies
CREATE POLICY "Superusers can manage roles" ON public.user_roles
  FOR ALL USING (public.has_role(auth.uid(), 'superuser'));

CREATE POLICY "Users can view own roles" ON public.user_roles
  FOR SELECT USING (auth.uid() = user_id);

-- Clients RLS policies (only superusers can see client credentials)
CREATE POLICY "Superusers can manage all clients" ON public.clients
  FOR ALL USING (public.has_role(auth.uid(), 'superuser'));

CREATE POLICY "Clients can view own record" ON public.clients
  FOR SELECT USING (auth.uid() = user_id);

-- Candidates RLS policies
CREATE POLICY "Superusers can manage all candidates" ON public.candidates
  FOR ALL USING (public.has_role(auth.uid(), 'superuser'));

CREATE POLICY "Clients can view assigned candidates" ON public.candidates
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.candidate_assignments
      WHERE candidate_id = candidates.id
      AND client_id = public.get_client_id(auth.uid())
    )
  );

-- Candidate assignments RLS policies
CREATE POLICY "Superusers can manage all assignments" ON public.candidate_assignments
  FOR ALL USING (public.has_role(auth.uid(), 'superuser'));

CREATE POLICY "Clients can view own assignments" ON public.candidate_assignments
  FOR SELECT USING (client_id = public.get_client_id(auth.uid()));

CREATE POLICY "Clients can update own assignments" ON public.candidate_assignments
  FOR UPDATE USING (client_id = public.get_client_id(auth.uid()));

-- Enable realtime for candidate_assignments and candidates (for real-time claiming)
ALTER PUBLICATION supabase_realtime ADD TABLE public.candidates;
ALTER PUBLICATION supabase_realtime ADD TABLE public.candidate_assignments;

-- Trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_clients_updated_at
  BEFORE UPDATE ON public.clients
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_candidates_updated_at
  BEFORE UPDATE ON public.candidates
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Function to claim a candidate (atomic operation to prevent race conditions)
CREATE OR REPLACE FUNCTION public.claim_candidate(
  p_candidate_id UUID,
  p_client_id UUID
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_current_status TEXT;
BEGIN
  -- Lock the row to prevent concurrent claims
  SELECT status INTO v_current_status
  FROM public.candidates
  WHERE id = p_candidate_id
  FOR UPDATE;
  
  -- Check if candidate is still available
  IF v_current_status != 'available' THEN
    RETURN FALSE;
  END IF;
  
  -- Verify the client has this candidate assigned
  IF NOT EXISTS (
    SELECT 1 FROM public.candidate_assignments
    WHERE candidate_id = p_candidate_id
    AND client_id = p_client_id
    AND status = 'pending'
  ) THEN
    RETURN FALSE;
  END IF;
  
  -- Claim the candidate
  UPDATE public.candidates
  SET status = 'claimed',
      claimed_by_client_id = p_client_id,
      claimed_at = now()
  WHERE id = p_candidate_id;
  
  -- Update the assignment status for the claiming client
  UPDATE public.candidate_assignments
  SET status = 'claimed'
  WHERE candidate_id = p_candidate_id
  AND client_id = p_client_id;
  
  -- Remove assignments for all other clients
  DELETE FROM public.candidate_assignments
  WHERE candidate_id = p_candidate_id
  AND client_id != p_client_id;
  
  RETURN TRUE;
END;
$$;